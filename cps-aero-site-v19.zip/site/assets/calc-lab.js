/* CPS Aero — Laboratoire des calculs
   Chaque formule suit la « boîte transparente » :
   1. la formule · 2. chaque variable en clair · 3. une application sur un avion réel · 4. un simulateur avec les étapes.
   Pour ajouter une formule : ajouter un objet dans FORMULES (même structure). */
(function(){
const fr=(x,d=2)=>Number(x).toLocaleString('fr-FR',{minimumFractionDigits:d,maximumFractionDigits:d});
const C=299792458, G=9.80665, FT=0.3048, NM=1852, KT=NM/3600;

/* Atmosphère standard : densité relative σ = ρ/ρ0 et température à une altitude en pieds */
function isa(hft){
  const h=hft*FT;
  if(h<=11000){const T=288.15-0.0065*h;return {T,sigma:Math.pow(T/288.15,4.2559),delta:Math.pow(T/288.15,5.2559)};}
  const T=216.65,e=Math.exp(-(h-11000)/6341.6);return {T,sigma:0.2971*e,delta:0.22336*e};
}

const FORMULES=[
{id:'dme',titre:'Distance DME',domaine:'Radionavigation',lien:['dme.html','Chapitre DME'],
 formule:'d = c × (t − t<sub>r</sub>) / 2',
 idee:'L’avion envoie une impulsion radio, la balise au sol répond après un retard fixe. En mesurant le temps total de l’aller-retour, on déduit la distance, car les ondes radio vont à la vitesse de la lumière.',
 vars:[['d','Distance oblique entre l’avion et la balise','m, puis NM'],['c','Vitesse de la lumière : les ondes radio vont aussi vite','299 792 458 m/s'],
       ['t','Temps total mesuré par l’avion, de l’envoi à la réception','µs (millionième de seconde)'],
       ['t<sub>r</sub>','Retard volontaire de la balise avant de répondre : 50 µs en canal X, 56 µs en canal Y','µs'],
       ['÷ 2','Le signal fait l’aller ET le retour : on divise par deux pour n’en garder qu’un','–']],
 exemple:{contexte:'Un A320 interroge une balise DME en canal X et reçoit la réponse 223 µs après l’envoi.',
   etapes:['temps de vol des ondes = 223 − 50 = 173 µs = 0,000 173 s','aller-retour = 299 792 458 × 0,000 173 = 51 864 m','d = 51 864 / 2 = 25 932 m','d = 25 932 / 1 852 = 14,0 NM'],
   resultat:'14,0 NM, soit 25,9 km'},
 inputs:[{id:'t',label:'Temps mesuré t',u:'µs',v:223,min:50,max:2600,step:1},{id:'canal',label:'Canal',type:'select',opts:[['50','X (50 µs)'],['56','Y (56 µs)']],v:'50'}],
 calc(v){const tr=+v.canal,dt=v.t-tr;if(dt<=0)return {err:'Le temps mesuré doit être plus long que le retard de la balise ('+tr+' µs).'};
   const ar=C*dt*1e-6,d=ar/2;
   return {etapes:[`temps de vol des ondes = ${fr(v.t,0)} − ${tr} = ${fr(dt,0)} µs`,`aller-retour = 299 792 458 × ${fr(dt*1e-6,6)} = ${fr(ar,0)} m`,`d = ${fr(ar,0)} / 2 = ${fr(d,0)} m`,`d = ${fr(d,0)} / 1 852 = ${fr(d/NM,2)} NM`],
     res:`${fr(d/NM,2)} NM`,sub:`${fr(d/1000,2)} km · 1 NM ≈ 12,36 µs d’aller-retour`,raw:{dt,tr}};}},

{id:'sol',titre:'Distance sol à partir du DME',domaine:'Radionavigation',lien:['dme.html','Chapitre DME'],
 formule:'D<sub>sol</sub> = √( d² − h² )',
 idee:'Le DME mesure la distance en ligne droite vers la balise, en diagonale. Avec l’altitude, on forme un triangle rectangle : Pythagore donne la distance réellement parcourue au sol.',
 vars:[['D<sub>sol</sub>','Distance au sol entre la balise et le point sous l’avion','NM'],['d','Distance oblique lue sur l’instrument DME','NM'],
       ['h','Hauteur de l’avion au-dessus de la balise, convertie en NM (1 NM = 6 076 ft)','NM']],
 exemple:{contexte:'Un Rafale à 15 000 ft lit 14,0 NM sur son DME.',
   etapes:['h = 15 000 / 6 076 = 2,47 NM','d² = 14,0² = 196,0','h² = 2,47² = 6,10','D<sub>sol</sub> = √(196,0 − 6,10) = √189,9 = 13,78 NM'],
   resultat:'13,8 NM au sol : l’écart est de 0,2 NM'},
 inputs:[{id:'d',label:'Distance DME d',u:'NM',v:14,min:0.5,max:200,step:0.1},{id:'h',label:'Altitude',u:'ft',v:15000,min:0,max:60000,step:500}],
 calc(v){const h=v.h/6076.12;if(v.d<=h)return {err:'L’avion est quasiment à la verticale : la distance DME ne peut pas être plus petite que la hauteur ('+fr(h,2)+' NM).'};
   const ds=Math.sqrt(v.d*v.d-h*h);
   return {etapes:[`h = ${fr(v.h,0)} / 6 076 = ${fr(h,2)} NM`,`d² = ${fr(v.d,1)}² = ${fr(v.d*v.d,1)}`,`h² = ${fr(h,2)}² = ${fr(h*h,2)}`,`D<sub>sol</sub> = √(${fr(v.d*v.d,1)} − ${fr(h*h,2)}) = ${fr(ds,2)} NM`],
     res:`${fr(ds,2)} NM`,sub:`écart avec la lecture DME : ${fr(v.d-ds,2)} NM`,raw:{d:v.d,h,ds}};}},

];


/* ---------- Visuels dynamiques ---------- */
const sv=(w,h,inner,aria)=>`<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${aria}">${inner}</svg>`;
const tx=(x,y,t,cls='',anchor='middle')=>`<text x="${x}" y="${y}" text-anchor="${anchor}" class="${cls}">${t}</text>`;
const VIZ={
  dme(r){const tot=r.dt+r.tr,W=560,L=10,k=(W-2*L)/tot,a=r.dt/2*k,b=r.tr*k;
    return sv(W,90,`<rect x="${L}" y="30" width="${a}" height="20" class="v-c"/><rect x="${L+a}" y="30" width="${b}" height="20" class="v-a"/><rect x="${L+a+b}" y="30" width="${a}" height="20" class="v-m"/>
      ${tx(L+a/2,22,'aller '+fr(r.dt/2,0)+' µs')}${tx(L+a+b/2,70,'balise '+r.tr+' µs','v-ta')}${tx(L+a+b+a/2,22,'retour '+fr(r.dt/2,0)+' µs')}${tx(W/2,88,'temps total '+fr(tot,0)+' µs','v-dim')}`,'Découpage du temps mesuré');},
  sol(r){const W=420,H=170,m=Math.max(r.d,0.1),k=Math.min((W-80)/m,(H-50)/Math.max(r.h,0.01),60),x0=40,y0=H-30,x1=x0+r.ds*k,y1=y0-r.h*k;
    return sv(W,H,`<line x1="${x0}" y1="${y0}" x2="${x1}" y2="${y0}" class="v-lc"/><line x1="${x1}" y1="${y0}" x2="${x1}" y2="${y1}" class="v-la"/><line x1="${x0}" y1="${y0}" x2="${x1}" y2="${y1}" class="v-lg"/>
      <circle cx="${x0}" cy="${y0}" r="5" class="v-dot"/><circle cx="${x1}" cy="${y1}" r="5" class="v-dot"/>
      ${tx((x0+x1)/2,y0+18,'sol '+fr(r.ds,2)+' NM','v-tc')}${tx(x1+6,(y0+y1)/2,'h '+fr(r.h,2)+' NM','v-ta','start')}${tx((x0+x1)/2-10,(y0+y1)/2-8,'DME '+fr(r.d,2)+' NM','v-tg','end')}`,'Triangle distance DME, hauteur, distance sol');},
};

/* ---------- Équations (KaTeX, rendu MathML natif) ---------- */
const nx=(x,d)=>fr(x,d).replace(',','{,}').replace(/[\u202f\u00a0 ]/g,'\\,');
const MAC={'\\vv':'\\textcolor{##06B6D4}{#1}','\\kk':'\\textcolor{##F59E0B}{#1}','\\rr':'\\textcolor{##22C55E}{#1}'};
function tex(s,disp){if(window.katex){try{return window.katex.renderToString(s,{output:'mathml',throwOnError:false,displayMode:!!disp,macros:Object.assign({},MAC),strict:false});}catch(e){}}
  return '<span class="tex-fb">'+s.replace(/\\(vv|kk|rr)\{/g,'{').replace(/\\dfrac\{([^}]*)\}\{([^}]*)\}/g,'($1)/($2)').replace(/\\[a-z]+/g,' ').replace(/[{}]/g,'')+'</span>';}
const TEX={
dme:{main:'\\vv{d} = \\dfrac{\\kk{c}\\,(\\vv{t}-\\vv{t_r})}{2}',vars:['\\vv{d}','\\kk{c}','\\vv{t}','\\vv{t_r}','\\div 2'],
 steps(v){const tr=+v.canal,dt=v.t-tr;if(dt<=0)return null;const ar=C*dt*1e-6,d=ar/2;return [
  `\\Delta t = \\vv{t}-\\vv{t_r} = ${nx(v.t,0)}-${tr} = ${nx(dt,0)}\\ \\mu\\text{s}`,
  `2d = \\kk{c}\\,\\Delta t = 299\\,792\\,458 \\times ${nx(dt,0)}\\times10^{-6} = ${nx(ar,0)}\\ \\text{m}`,
  `\\vv{d} = \\dfrac{${nx(ar,0)}}{2} = ${nx(d,0)}\\ \\text{m}`,
  `\\vv{d} = \\dfrac{${nx(d,0)}}{1\\,852} = \\rr{${nx(d/NM,2)}\\ \\text{NM}}`];}},
sol:{main:'D_{\\text{sol}} = \\sqrt{\\vv{d}^{2}-\\vv{h}^{2}}',vars:['D_{\\text{sol}}','\\vv{d}','\\vv{h}'],
 steps(v){const h=v.h/6076.12;if(v.d<=h)return null;const ds=Math.sqrt(v.d*v.d-h*h);return [
  `\\vv{h} = \\dfrac{${nx(v.h,0)}\\ \\text{ft}}{6\\,076} = ${nx(h,2)}\\ \\text{NM}`,
  `\\vv{d}^2 = ${nx(v.d,1)}^2 = ${nx(v.d*v.d,1)} \\qquad \\vv{h}^2 = ${nx(h,2)}^2 = ${nx(h*h,2)}`,
  `D_{\\text{sol}} = \\sqrt{${nx(v.d*v.d,1)}-${nx(h*h,2)}} = \\rr{${nx(ds,2)}\\ \\text{NM}}`];}},
};

/* Calculateurs de dimensionnement : fournis par assets/premium/cpl/calc-avance.js (servi par le serveur
   aux seuls grades autorisés quand les grades sont ouverts). Sans ce fichier, la page garde la radionavigation. */
let tasCalc=null;
if(typeof window.CPS_CALC_AVANCE==='function'){const P=window.CPS_CALC_AVANCE({fr,nx,isa,G,KT,FT,NM,sv,tx});
  FORMULES.push(...P.formules);Object.assign(TEX,P.tex);Object.assign(VIZ,P.viz);tasCalc=P.tasCalc;}
window.CPS_LAB={FORMULES,isa,tasCalc};
const ADV=['Mécanique du vol','Propulsion'];
const isAdv=f=>ADV.includes(f.domaine);
const root=document.getElementById('lab');
if(!root)return;
const filt=document.getElementById('lab-filtre');
const toc=document.getElementById('lab-toc');
const domaines=[...new Set(FORMULES.map(f=>f.domaine))];
if(filt){
  filt.innerHTML=['Toutes',...domaines].map((d,i)=>`<button type="button" class="chip" aria-pressed="${i===0}" data-d="${d}">${d}</button>`).join('');
  filt.addEventListener('click',e=>{const b=e.target.closest('.chip');if(!b)return;
    filt.querySelectorAll('.chip').forEach(c=>c.setAttribute('aria-pressed',String(c===b)));
    root.querySelectorAll('[data-dom]').forEach(c=>{c.hidden=!(b.dataset.d==='Toutes'||c.dataset.dom===b.dataset.d);});
    if(toc)toc.querySelectorAll('a').forEach(a=>{const f=FORMULES.find(x=>x.id===a.getAttribute('href').slice(1));a.hidden=!(b.dataset.d==='Toutes'||f.domaine===b.dataset.d);});
  });
}
if(toc)toc.innerHTML='<span class="eyebrow">Formules</span>'+FORMULES.map(f=>`<a href="#${f.id}"${isAdv(f)?' class="adv"':''}>${f.titre}</a>`).join('');

/* ---------- Mode Ingénieur : calculateurs de dimensionnement masqués en mode Débutant ----------
   Les cartes avancées existent dans la page mais sont cachées (display:none) tant que le niveau n'est pas « ingenieur ».
   Le passage en mode Ingénieur demande le badge (assets/habilitation.js, chargé en pied de page). */
const lvl=()=>document.documentElement.getAttribute('data-level')||'debutant';
function habStatus(){
  const st=document.getElementById('hab-status');if(!st)return;
  const HAB=window.CPS_HAB,n=FORMULES.filter(isAdv).length,eng=lvl()==='ingenieur',info=HAB&&HAB.read?HAB.read():null;
  const modes=HAB?HAB.MODES:'';
  st.className='hab-status'+(eng?' on':'');
  st.innerHTML=eng
    ?`<div class="hab-row"><span class="hab-chip on"><img src="assets/brand/logo-cpsaero-mark.svg" alt="" width="22" height="22">Ingénieur Certifié CPSAero${info&&info.date?' · '+info.date.split('-').reverse().join('/'):''}</span><span class="hab-txt">Mode Ingénieur actif : les ${n} outils de dimensionnement sont affichés.</span><button type="button" class="linkbtn" data-deb>Repasser en Débutant</button><button type="button" class="linkbtn" data-reset>Retirer le badge</button></div>`
    :`<div class="hab-off"><b>Mode Ingénieur désactivé</b> — Débloquez l’accès complet aux outils de dimensionnement.</div>${modes}
      <div class="hab-row"><span class="hab-txt">${n?`${n} calculateurs (mécanique du vol, propulsion) sont masqués ; leur théorie reste résumée plus bas.`:'Les calculateurs de mécanique du vol et de propulsion font partie du grade CPL.'} La radionavigation reste en accès libre.</span>
      <button type="button" class="btn small primary" data-eng>${HAB&&HAB.ok()?'Passer en mode Ingénieur':'Passer le test d’habilitation Ingénieur'}</button></div>`;
  const q=sel=>st.querySelector(sel);
  if(q('[data-reset]'))q('[data-reset]').onclick=()=>HAB&&HAB.reset();
  if(q('[data-deb]'))q('[data-deb]').onclick=()=>window.CPS_LEVEL&&CPS_LEVEL.set('debutant');
  if(q('[data-eng]'))q('[data-eng]').onclick=()=>window.CPS_LEVEL&&CPS_LEVEL.want();
}
function fitTheory(){if(window.CPS_TEX)root.querySelectorAll('.theory').forEach(c=>{CPS_TEX.fit(c);CPS_TEX.tips(c);});}
function onLevel(){
  habStatus();fitTheory();
  if(lvl()==='ingenieur'){root.querySelectorAll('.formula.adv').forEach((c,i)=>{c.classList.remove('unlock');void c.offsetWidth;c.classList.add('unlock');c.style.animationDelay=(i*70)+'ms';
    if(window.CPS_TEX){CPS_TEX.fit(c);CPS_TEX.tips(c);}});}
}
document.addEventListener('cps:level',onLevel);
document.addEventListener('cps:badge',habStatus);

root.innerHTML=FORMULES.map(f=>{const X=TEX[f.id];return `
${isAdv(f)?`<article class="panel theory" data-dom="${f.domaine}" aria-label="Théorie : ${f.titre}"><header class="f-head"><div><span class="pill">${f.domaine} · théorie</span><h2>${f.titre}</h2></div><span class="th-lock">Outil réservé au mode Ingénieur</span></header>
  <div class="th-body"><div class="f-formula">${X&&window.katex?tex(X.main,true):f.formule}</div><p class="f-idea">${f.idee}</p>${f.lien?`<a class="btn small" href="${f.lien[0]}">${f.lien[1]}</a>`:''}</div></article>`:''}
<article class="panel formula${isAdv(f)?' adv':''}" id="${f.id}" data-dom="${f.domaine}">
  <header class="f-head"><div><span class="pill next">${f.domaine}</span><h2>${f.titre}</h2></div>${f.lien?`<a class="btn small" href="${f.lien[0]}">${f.lien[1]}</a>`:''}</header>
  <div class="f-body">
    <section><h3><span class="n">1</span>La formule générale</h3><div class="f-formula">${X&&window.katex?tex(X.main,true):f.formule}</div><p class="f-idea">${f.idee}</p>
      <p class="f-key"><span class="kv-c">■ variable</span> <span class="kv-a">■ constante</span> <span class="kv-g">■ résultat</span></p></section>
    <section><h3><span class="n">2</span>Le dictionnaire des variables</h3><div class="dict">${f.vars.map((x,i)=>`<div class="dict-i"><div class="dict-s">${X&&window.katex&&X.vars[i]?tex(X.vars[i]):x[0]}</div><div><p>${x[1]}</p><span class="dict-u">${x[2]}</span></div></div>`).join('')}</div></section>
    <section class="f-sim"><h3><span class="n">3</span>L’application numérique</h3><p class="f-ctx"><b>Point de départ :</b> ${f.exemple.contexte} Change les valeurs pour voir le calcul se refaire.</p>
      <div class="fields">${f.inputs.map(i=>i.type==='select'
        ?`<div class="field"><label for="${f.id}-${i.id}">${i.label}</label><select id="${f.id}-${i.id}" data-k="${i.id}">${i.opts.map(o=>`<option value="${o[0]}"${o[0]===i.v?' selected':''}>${o[1]}</option>`).join('')}</select></div>`
        :`<div class="field"><label for="${f.id}-${i.id}">${i.label} <span class="u">${i.u}</span></label><div class="pair"><input type="range" aria-label="${i.label.replace(/<[^>]+>/g,'')} (curseur)" data-r="${i.id}" min="${i.min}" max="${i.max}" step="${i.step}" value="${i.v}"><input id="${f.id}-${i.id}" data-k="${i.id}" type="number" inputmode="decimal" value="${i.v}" min="${i.min}" max="${i.max}" step="${i.step}"></div></div>`).join('')}</div>
      ${f.note?`<p class="f-note">${f.note}</p>`:''}</section>
    <section class="f-steps"><h3><span class="n">4</span>La décomposition du calcul</h3><div class="f-out" aria-live="polite"></div><div class="f-viz"></div></section>
  </div>
</article>`;}).join('');

FORMULES.forEach(f=>{
  const card=document.getElementById(f.id), out=card.querySelector('.f-out'), viz=card.querySelector('.f-viz');
  function run(){
    const v={};let bad=false;
    card.querySelectorAll('[data-k]').forEach(el=>{
      if(el.tagName==='SELECT'){v[el.dataset.k]=el.value;return;}
      const x=parseFloat(String(el.value).replace(',','.'));if(!isFinite(x)){bad='Entre des nombres dans chaque case.';return;}
      const mn=parseFloat(el.min),mx=parseFloat(el.max);
      if((isFinite(mn)&&x<mn)||(isFinite(mx)&&x>mx)){const lab=card.querySelector(`label[for="${el.id}"]`);bad=`${lab?lab.textContent.trim():el.dataset.k} : valeur hors du domaine de validité de ce calculateur (entre ${fr(mn,0)} et ${fr(mx,0)}).`;el.setAttribute('aria-invalid','true');}
      else el.removeAttribute('aria-invalid');
      v[el.dataset.k]=x;});
    if(bad){out.innerHTML=`<p class="fb bad" role="alert">${bad}</p>`;viz.innerHTML='';return;}
    const r=f.calc(v);
    if(r.err){out.innerHTML=`<p class="fb bad">${r.err}</p>`;viz.innerHTML='';return;}
    const lines=TEX[f.id]&&window.katex?TEX[f.id].steps(v):null;
    const body=lines?lines.map((l,i)=>`<div class="step-l${i===lines.length-1?' last':''}"><span class="step-n">${i+1}</span><div>${tex(l,false)}</div></div>`).join(''):`<div class="eq">${r.etapes.join('<br>')}</div>`;
    out.innerHTML=`<div class="steps-tex">${body}</div><div class="final"><span>Résultat</span><b>${r.res}</b><em>${r.sub||''}</em><button type="button" class="btn small f-copy">Copier le calcul</button>${f.jumeau?`<a class="btn small primary f-twin" href="jumeau.html?${new URLSearchParams(f.jumeau(v,r))}">Voir ce point dans le jumeau numérique →</a>`:''}</div>`;
    const plain=h=>h.replace(/<sup>/g,'^').replace(/<sub>/g,'').replace(/<[^>]+>/g,'');
    out.querySelector('.f-copy').addEventListener('click',e=>{
      const txt=`${f.titre} (CPSAero)\n`+f.inputs.map(i=>`${plain(i.label)} = ${v[i.id]}${i.u?' '+i.u:''}`).join('\n')+'\n\n'+r.etapes.map((l,i)=>`${i+1}. ${plain(l)}`).join('\n')+`\n\nRésultat : ${plain(r.res)}`;
      const ok=()=>{e.target.textContent='Copié ✓';setTimeout(()=>e.target.textContent='Copier le calcul',1600);};
      if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(txt).then(ok,()=>{e.target.textContent='Copie impossible';});
      else{const ta=document.createElement('textarea');ta.value=txt;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');ok();}catch(err){}ta.remove();}
    });
    viz.innerHTML=VIZ[f.id]&&r.raw?VIZ[f.id](r.raw):'';
    const svv=viz.querySelector('svg');if(svv&&svv.viewBox&&svv.viewBox.baseVal&&svv.clientWidth){const k=svv.viewBox.baseVal.width/svv.clientWidth;svv.style.fontSize=Math.min(13*k,16).toFixed(1)+'px';}
    if(window.CPS_TEX&&window.CPS_TEX.fit)window.CPS_TEX.fit(card);
    if(window.CPS_TEX&&window.CPS_TEX.tips)window.CPS_TEX.tips(card);
  }
  card.querySelectorAll('[data-r]').forEach(rg=>{const num=card.querySelector(`[data-k="${rg.dataset.r}"]`);
    rg.addEventListener('input',()=>{num.value=rg.value;run();});
    num.addEventListener('input',()=>{const x=parseFloat(String(num.value).replace(',','.'));if(isFinite(x))rg.value=x;});});
  card.querySelectorAll('[data-k]').forEach(el=>el.addEventListener('input',run));
  run();
});
// le script du badge est chargé en pied de page : statut affiché une fois la page prête
fitTheory();
if(document.readyState==='complete')habStatus();else addEventListener('load',habStatus);
})();
