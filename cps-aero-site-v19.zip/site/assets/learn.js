/* CPS Aero — révisions et progression
   Une page déclare window.CPS_PAGE = {id, titre, exos:[], quiz:[], fiches:[]} avant ce script.
   Tout est gardé dans le navigateur de l'élève (localStorage), sans compte. */
(function(){
  const KEY='cps-aero-v1';
  function load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{};}catch(e){return {};}}
  function save(d){try{localStorage.setItem(KEY,JSON.stringify(d));}catch(e){}}
  function pageData(id){const d=load();d.pages=d.pages||{};d.pages[id]=d.pages[id]||{};return d;}
  const Progress={
    get(){const d=load();return d.pages||{};},
    mark(id,field,value){const d=pageData(id);d.pages[id][field]=value;save(d);},
    markIn(id,field,key){const d=pageData(id);const o=d.pages[id][field]||{};o[key]=1;d.pages[id][field]=o;save(d);},
    reset(){save({});}
  };
  window.CPS=window.CPS||{};window.CPS.progress=Progress;

  const P=window.CPS_PAGE;
  const $=s=>document.querySelector(s);
  const num=s=>{const v=parseFloat(String(s).replace(/\s/g,'').replace(',','.'));return isFinite(v)?v:null;};
  const fr=(x,d)=>x.toLocaleString('fr-FR',{maximumFractionDigits:d});
  if(!P)return;
  Progress.mark(P.id,'visited',Date.now());

  /* Lu jusqu'au bout */
  const end=document.getElementById('fin');
  if(end&&'IntersectionObserver' in window){
    new IntersectionObserver((es,o)=>{if(es[0].isIntersecting){Progress.mark(P.id,'read',true);o.disconnect();}}).observe(end);
  }

  /* Exercices « à toi de calculer » */
  const exBox=$('#exos');
  if(exBox&&P.exos){
    const done=(Progress.get()[P.id]||{}).exos||{};
    exBox.innerHTML=P.exos.map((x,i)=>`
      <div class="panel exo" data-i="${i}">
        <div class="top"><h3>${x.titre}</h3><span class="pill ${done[x.id]?'ok':'goal'}" data-st>${done[x.id]?'Réussi':'À faire'}</span></div>
        <p>${x.q}</p>
        <form class="ans" novalidate>
          <label class="sr" for="ex-${x.id}" style="position:absolute;left:-9999px">Ta réponse</label>
          <input id="ex-${x.id}" inputmode="decimal" autocomplete="off" placeholder="Ta réponse">
          <span class="unit">${x.unite||''}</span>
          <button class="btn small primary" type="submit">Vérifier</button>
          <button class="btn small" type="button" data-sol>Voir la correction</button>
        </form>
        <div class="fb" aria-live="polite"></div>
        <div class="eq" data-steps hidden>${x.correction}</div>
      </div>`).join('');
    exBox.querySelectorAll('.exo').forEach(el=>{
      const x=P.exos[+el.dataset.i], fb=el.querySelector('.fb'), st=el.querySelector('[data-steps]');
      el.querySelector('form').addEventListener('submit',e=>{
        e.preventDefault();
        const v=num(el.querySelector('input').value);
        if(v===null){fb.className='fb bad';fb.textContent='Entre un nombre, avec une virgule ou un point.';return;}
        const dec=(String(x.reponse).split('.')[1]||'').length;
        const tol=Math.max((x.tol||0.03)*Math.abs(x.reponse),0.5*Math.pow(10,-dec));
        if(Math.abs(v-x.reponse)<=tol){
          fb.className='fb good';fb.innerHTML='Exact. '+(x.bravo||'');st.hidden=false;
          Progress.markIn(P.id,'exos',x.id);const p=el.querySelector('[data-st]');p.className='pill ok';p.textContent='Réussi';
        }else{
          const ratio=v/x.reponse, units=Math.abs(ratio/1000-1)<0.03||Math.abs(ratio*1000-1)<0.03||Math.abs(ratio/100-1)<0.03||Math.abs(ratio*100-1)<0.03;
          fb.className='fb bad';fb.innerHTML=units?'Presque : le chiffre est bon mais pas l’unité. Vérifie N ou kN, % ou fraction.':(x.indice?'Pas encore. Indice : '+x.indice:'Pas encore, réessaie.');
        }
      });
      el.querySelector('[data-sol]').addEventListener('click',()=>{st.hidden=!st.hidden;});
    });
  }

  /* Quiz : une question à la fois */
  const qBox=$('#quiz');
  if(qBox&&P.quiz){
    let i=0,score=0;
    function show(){
      if(i>=P.quiz.length){
        const prev=((Progress.get()[P.id]||{}).quiz||{}).best||0;
        if(score>prev)Progress.mark(P.id,'quiz',{best:score,total:P.quiz.length});
        qBox.innerHTML=`<div class="bar"><span>Terminé</span><span>${score} / ${P.quiz.length}</span></div>
          <p class="q">${score===P.quiz.length?'Sans faute. Tu peux passer à la suite.':score>=P.quiz.length/2?'Bien joué. Relis les parties où tu as hésité.':'Relis la page, puis retente : ça rentre vite.'}</p>
          <div><button class="btn small" type="button" data-again>Recommencer</button></div>`;
        qBox.querySelector('[data-again]').addEventListener('click',()=>{i=0;score=0;show();});
        return;
      }
      const q=P.quiz[i];
      qBox.innerHTML=`<div class="bar"><span>Question ${i+1} / ${P.quiz.length}</span><span>Score ${score}</span></div>
        <p class="q">${q.q}</p><div class="opts">${q.choix.map((c,k)=>`<button type="button" class="opt" data-k="${k}">${c}</button>`).join('')}</div>
        <p class="why" hidden></p><div hidden data-next><button class="btn small primary" type="button">${i+1<P.quiz.length?'Question suivante':'Voir mon score'}</button></div>`;
      qBox.querySelectorAll('.opt').forEach(b=>b.addEventListener('click',()=>{
        const k=+b.dataset.k;
        qBox.querySelectorAll('.opt').forEach(o=>{o.disabled=true;if(+o.dataset.k===q.bonne)o.classList.add('right');});
        if(k===q.bonne)score++;else b.classList.add('wrong');
        const w=qBox.querySelector('.why');w.hidden=false;w.innerHTML=(k===q.bonne?'Bonne réponse. ':'Pas tout à fait. ')+q.pourquoi;
        const n=qBox.querySelector('[data-next]');n.hidden=false;n.querySelector('button').addEventListener('click',()=>{i++;show();});
        n.querySelector('button').focus();
      }));
    }
    show();
  }

  /* Fiches à retourner */
  const cBox=$('#fiches');
  if(cBox&&P.fiches){
    cBox.innerHTML=P.fiches.map(f=>`<button type="button" class="card" aria-label="Fiche : ${f.recto.replace(/<[^>]+>/g,'')}. Clique pour retourner."><span class="inner">
      <span class="face front"><small>${f.tag||'Fiche'}</small><b>${f.recto}</b><small>Clique pour retourner</small></span>
      <span class="face back"><small>${f.tag||'Fiche'}</small><span>${f.verso}</span><small></small></span></span></button>`).join('');
    cBox.querySelectorAll('.card').forEach(c=>c.addEventListener('click',()=>c.classList.toggle('flip')));
  }

  /* Sommaire flottant : section en cours surlignée, barre de lecture, sommaire mobile */
  function tocInit(){
    const toc=[...document.querySelectorAll('.toc a[href^="#"]')];
    if(!toc.length||document.querySelector('.readbar'))return;
    const secs=toc.map(a=>document.getElementById(a.getAttribute('href').slice(1))).filter(Boolean);
    const bar=document.createElement('div');bar.className='readbar';bar.innerHTML='<i></i>';document.body.appendChild(bar);
    const tocEl=document.querySelector('.toc');
    const pct=document.createElement('span');pct.className='toc-pct';tocEl.appendChild(pct);
    const fab=document.createElement('button');fab.type='button';fab.className='toc-fab';fab.setAttribute('aria-expanded','false');
    fab.innerHTML='<span class="t">Sommaire</span><span class="p"></span>';
    const sheet=document.createElement('nav');sheet.className='toc-sheet';sheet.hidden=true;sheet.setAttribute('aria-label','Sommaire de la page');
    sheet.innerHTML=toc.map(a=>`<a href="${a.getAttribute('href')}">${a.textContent}</a>`).join('');
    document.body.appendChild(sheet);document.body.appendChild(fab);
    fab.addEventListener('click',e=>{e.stopPropagation();sheet.hidden=!sheet.hidden;fab.setAttribute('aria-expanded',String(!sheet.hidden));});
    sheet.addEventListener('click',()=>{sheet.hidden=true;fab.setAttribute('aria-expanded','false');});
    document.addEventListener('click',e=>{if(!sheet.hidden&&!sheet.contains(e.target)){sheet.hidden=true;fab.setAttribute('aria-expanded','false');}});
    let tick=false;
    function upd(){tick=false;
      const h=document.documentElement,max=h.scrollHeight-innerHeight,p=max>0?Math.min(1,Math.max(0,scrollY/max)):0;
      bar.firstChild.style.width=(p*100).toFixed(1)+'%';pct.textContent='Lu à '+Math.round(p*100)+' %';
      let cur=secs[0];secs.forEach(s=>{if(s.getBoundingClientRect().top<140)cur=s;});
      const id=cur?cur.id:'';
      toc.forEach(a=>a.classList.toggle('on',a.getAttribute('href')==='#'+id));
      sheet.querySelectorAll('a').forEach(a=>a.classList.toggle('on',a.getAttribute('href')==='#'+id));
      const on=toc.find(a=>a.classList.contains('on'));fab.querySelector('.t').textContent=on?on.textContent:'Sommaire';fab.querySelector('.p').textContent=Math.round(p*100)+' %';
    }
    addEventListener('scroll',()=>{if(!tick){tick=true;requestAnimationFrame(upd);}},{passive:true});addEventListener('resize',upd);upd();
  }
  if(document.readyState==='complete')tocInit();else addEventListener('load',tocInit);
})();
/* Fiche express : impression de la fiche seule */
(function(){
  document.addEventListener('click',function(e){
    const b=e.target.closest&&e.target.closest('.sheet-print');if(!b)return;
    const H=document.documentElement;H.classList.add('print-sheet');
    const done=()=>{H.classList.remove('print-sheet');window.removeEventListener('afterprint',done);};
    window.addEventListener('afterprint',done);
    try{window.print();}catch(err){}
    setTimeout(done,1500);
  });
})();
