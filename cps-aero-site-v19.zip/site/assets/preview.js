/* CPSAero — aperçu Bureau / Mobile.
   Sur grand écran, le bouton « Aperçu mobile » ouvre la page courante dans un cadre de smartphone.
   Le cadre est une iframe à la vraie largeur du téléphone : les règles responsives (media queries) s'y appliquent
   exactement comme sur l'appareil, ce que ne permettrait pas un simple rétrécissement du conteneur.
   « Bureau » ou Échap referme l'aperçu. L'état est gardé pour la session (sessionStorage « cps-preview »). */
(function(){
  if(window.self!==window.top)return; // pas de bouton dans l'aperçu lui-même
  const SS='cps-preview';
  const DEV={iphone:{w:390,h:844,l:'iPhone (390 × 844)'},android:{w:412,h:915,l:'Android (412 × 915)'},petit:{w:360,h:740,l:'Petit écran (360 × 740)'}};
  const ICON_PC='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8M12 16v4"/></svg>';
  const ICON_PH='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="2.5" width="10" height="19" rx="2.2"/><path d="M11 18.5h2"/></svg>';
  const big=()=>matchMedia('(min-width: 900px)').matches;
  let ov=null,dev='iphone';
  const get=()=>{try{return JSON.parse(sessionStorage.getItem(SS)||'null');}catch(e){return null;}};
  const set=v=>{try{v?sessionStorage.setItem(SS,JSON.stringify(v)):sessionStorage.removeItem(SS);}catch(e){}};

  function fit(){
    if(!ov)return;const d=DEV[dev],ph=ov.querySelector('.pv-phone'),padW=28,padH=52;
    const availH=innerHeight-ov.querySelector('.pv-bar').offsetHeight-40,availW=innerWidth-40;
    const k=Math.min(1,availH/(d.h+padH),availW/(d.w+padW));
    ph.style.width=(d.w+padW)+'px';ph.style.height=(d.h+padH)+'px';ph.style.transform=`scale(${k})`;
    ov.querySelector('.pv-stage').style.height=((d.h+padH)*k)+'px';
    ov.querySelector('.pv-scale').textContent=k<1?`affiché à ${Math.round(k*100)} %`:'taille réelle';
  }
  function open(src){
    if(ov)return;const s=get();dev=(s&&DEV[s.dev])?s.dev:dev;
    ov=document.createElement('div');ov.className='pv-ov';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');ov.setAttribute('aria-label','Aperçu du site sur smartphone');
    ov.innerHTML=`<div class="pv-bar">
        <div class="pv-seg" role="group" aria-label="Mode d’affichage"><button type="button" data-m="pc" aria-pressed="false">${ICON_PC}Mode Bureau</button><button type="button" data-m="mob" aria-pressed="true">${ICON_PH}Mode Mobile</button></div>
        <label class="pv-dev">Appareil <select>${Object.entries(DEV).map(([k,v])=>`<option value="${k}"${k===dev?' selected':''}>${v.l}</option>`).join('')}</select></label>
        <span class="pv-scale"></span>
        <a class="pv-open" href="#" target="_blank" rel="noopener">Ouvrir la page dans un onglet</a>
      </div>
      <div class="pv-stage"><div class="pv-phone"><i class="pv-notch" aria-hidden="true"></i><iframe title="Aperçu mobile de CPSAero"></iframe></div></div>
      <p class="pv-hint">Aperçu fidèle de la mise en page mobile (largeur réelle de l’écran). Le tactile, lui, se teste sur un vrai téléphone. Échap ou « Mode Bureau » pour revenir.</p>`;
    document.body.appendChild(ov);document.documentElement.classList.add('pv-on');
    const fr=ov.querySelector('iframe');fr.src=src||location.href;
    fr.addEventListener('load',()=>{try{const u=fr.contentWindow.location.href;ov.querySelector('.pv-open').href=u;set({dev,url:u});}catch(e){}});
    ov.querySelector('[data-m="pc"]').onclick=close;
    ov.querySelector('select').onchange=e=>{dev=e.target.value;fit();const s=get()||{};set(Object.assign(s,{dev}));};
    set({dev,url:fr.src});fit();ov.querySelector('[data-m="mob"]').focus();
    syncBtn();
  }
  function close(){
    if(!ov)return;let u=null;try{u=ov.querySelector('iframe').contentWindow.location.href;}catch(e){}
    ov.remove();ov=null;document.documentElement.classList.remove('pv-on');set(null);syncBtn();
    // si on a navigué dans l'aperçu, on rejoint la même page en mode bureau
    if(u&&u.split('#')[0]!==location.href.split('#')[0])location.href=u;
  }
  function syncBtn(){document.querySelectorAll('.pv-btn').forEach(b=>{b.setAttribute('aria-pressed',String(!!ov));b.title=ov?'Revenir au mode Bureau':'Voir la page en Mode Mobile';});}
  function inject(){
    const host=document.querySelector('.nav-right');
    if(host&&!host.querySelector('.pv-btn')){const b=document.createElement('button');b.type='button';b.className='icon-btn pv-btn';b.setAttribute('aria-label','Aperçu Bureau / Mobile');b.innerHTML=ICON_PH;b.onclick=()=>ov?close():open();
      const th=host.querySelector('#theme-btn');host.insertBefore(b,th||null);}
    const fn=document.querySelector('.site-foot nav');
    if(fn&&!fn.querySelector('.pv-link')){const a=document.createElement('button');a.type='button';a.className='linkbtn pv-link';a.textContent='Aperçu mobile';a.onclick=()=>open();fn.appendChild(a);}
    syncBtn();
  }
  addEventListener('keydown',e=>{if(e.key==='Escape'&&ov)close();});
  addEventListener('resize',()=>{if(ov){if(!big())close();else fit();}});
  inject();
  const s=get();if(s&&big())open(s.url&&s.url.split('#')[0]===location.href.split('#')[0]?s.url:null);
  window.CPS_PREVIEW={open,close};
})();
