/* CPS Aero — Mission « Extinction et rallumage du M88 en vol » + sélecteur de missions
   Tout est simulé avec un modèle simplifié et des exigences fictives. Les ordres de grandeur restent plausibles. */
(function(){
const fr=(x,d=0)=>Number(x).toLocaleString('fr-FR',{minimumFractionDigits:d,maximumFractionDigits:d});

/* Téléchargement d'un rapport texte */
window.CPS_downloadReport=function(name,text){
  try{const blob=new Blob([text],{type:'text/plain;charset=utf-8'});const url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);}
  catch(e){}
};

window.CPS_MISSIONS=window.CPS_MISSIONS||{};
window.CPS_MISSIONS.rallumage=function(){
const root=document.getElementById('game'), stepper=document.getElementById('game-steps');
const ALTS=[10000,20000,30000,40000], MACHS=[0.4,0.5,0.6,0.8];
const ETAPES=['Briefing','Configuration','Vol et télémesure','Analyse et décision','Rapport'];
const S={step:0,max:0,pts:[],checks:{},runs:null,decision:null};
const inDomain=p=>p.alt<=30000&&p.mach>=0.6;
const REQUIRED=[{alt:30000,mach:0.6},{alt:10000,mach:0.6}];
const key=p=>p.alt+'-'+p.mach;
/* Modèle de rallumage : il faut assez de vitesse pour que l'air fasse tourner le moteur (autorotation)
   et assez de pression pour que la flamme tienne. Plus on est haut, plus il faut aller vite. */
const machMin=alt=>0.25+0.011*alt/1000;
const tRallumage=p=>8+18*Math.pow(machMin(p.alt)/p.mach,4);
const n2Auto=m=>6+30*m;

function renderStepper(){
  stepper.innerHTML=ETAPES.map((e,i)=>`<button type="button" ${i===S.step?'aria-current="step"':''} class="${i<S.max?'done':''}" ${i>S.max?'disabled':''} data-i="${i}">${e}<small>${["Pourquoi on vole","Ce qu’on prépare","Ce qu’on mesure","Ce qu’on conclut","Ce qu’on transmet"][i]||""}</small></button>`).join('');
  stepper.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>go(+b.dataset.i)));
}
function go(i){S.step=i;S.max=Math.max(S.max,i);render();try{root.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});}catch(e){}}
function nav(label,ok=true){return `<div class="g-nav">${S.step>0?'<button type="button" class="btn small" data-back>Étape précédente</button>':'<span></span>'}<button type="button" class="btn primary" data-next ${ok?'':'disabled'}>${label}</button></div>`;}
function bindNav(){const n=root.querySelector('[data-next]');if(n)n.addEventListener('click',()=>go(S.step+1));const b=root.querySelector('[data-back]');if(b)b.addEventListener('click',()=>go(S.step-1));}
function render(){renderStepper();[briefing,config,vol,analyse,rapport][S.step]();}

/* 1. Briefing */
const CHECK=[['zone','Zone d’essai réservée, terrain de dégagement choisi',true],['chasse','Avion d’accompagnement (chase) prévu',true],['carbu','Carburant suffisant pour tous les points et le retour',true],
  ['tlm','Chaîne de télémesure testée de bout en bout avant le vol',false]];
function briefing(){
  const ok=CHECK.filter(c=>c[2]).every(c=>S.checks[c[0]]);
  root.innerHTML=`<div class="g-grid"><div class="g-main">
    <span class="pill goal">Mission</span><h2>Extinction et rallumage du M88 en vol</h2>
    <p>Si un moteur s’éteint en vol (ingestion, givrage, panne d’alimentation), le pilote doit pouvoir le rallumer. Le vent relatif fait tourner le moteur tout seul, c’est l’<b>autorotation</b> ; il suffit alors de rouvrir le carburant et d’allumer. Mais cela ne marche que si l’avion va assez vite et pas trop haut.</p>
    <div class="g-req"><b>EXIGENCE</b><span>Le moteur doit se rallumer en autorotation <b>en moins de 30 s</b> dans tout le domaine déclaré : <b>de 10 000 à 30 000 ft, à partir de Mach 0,6</b>. Exigence fictive, pour l’exercice.</span></div>
    <p>Sur le Rafale, l’essai se fait moteur par moteur : l’autre M88 garde l’avion en vol. Ton rôle : choisir les points d’essai, suivre la télémesure, puis décider si l’essai est validé.</p>
    <h3>Check-list avant vol</h3>
    <div class="g-checks">${CHECK.map(c=>`<label><input type="checkbox" data-c="${c[0]}" ${S.checks[c[0]]?'checked':''}> ${c[1]}${c[2]?'':' <span class="pill">conseillé</span>'}</label>`).join('')}</div>
    ${nav('Préparer les points d’essai',ok)}
  </div><aside class="panel g-side"><h3>Ce qu’on surveille</h3><ul><li><b>N2</b> : régime du corps HP, en %.</li><li><b>EGT</b> : température des gaz en sortie de turbine. Elle remonte d’un coup quand le moteur se rallume.</li><li><b>Pression carburant</b> : nulle pendant l’extinction commandée.</li></ul></aside></div>`;
  root.querySelectorAll('[data-c]').forEach(b=>b.addEventListener('change',()=>{S.checks[b.dataset.c]=b.checked;briefing();}));
  bindNav();
}

/* 2. Configuration : grille altitude × Mach */
function config(){
  const n=S.pts.length;
  root.innerHTML=`<div class="g-grid"><div class="g-main">
    <h2>Choisir les points d’essai</h2>
    <p>Chaque case est un point de vol (altitude, Mach) où l’on coupera puis rallumera le moteur. Le domaine à démontrer est surligné. Un vol permet <b>5 points au maximum</b> (environ 6 minutes chacun).</p>
    <div class="tbl-scroll"><table class="rl-grid"><thead><tr><th>Altitude</th>${MACHS.map(m=>`<th>Mach ${fr(m,1)}</th>`).join('')}</tr></thead><tbody>
      ${ALTS.slice().reverse().map(a=>`<tr><th>${fr(a)} ft</th>${MACHS.map(m=>{const p={alt:a,mach:m},on=S.pts.some(x=>key(x)===key(p));
        return `<td><button type="button" class="rl-cell ${inDomain(p)?'dom':''}" aria-pressed="${on}" data-a="${a}" data-m="${m}">${on?'✓ choisi':'—'}</button></td>`;}).join('')}</tr>`).join('')}
    </tbody></table></div>
    <div class="g-calc panel"><div><span>Points choisis</span><b>${n} / 5</b></div><div><span>Dans le domaine</span><b>${S.pts.filter(inDomain).length}</b></div><div><span>Durée estimée</span><b>${n*6} min</b></div></div>
    ${n>5?'<ul class="g-warn"><li>Trop de points pour un seul vol : 5 au maximum.</li></ul>':''}
    ${nav('Décoller',n>=1&&n<=5)}
  </div><aside class="panel g-side"><h3>Comment choisir ?</h3><p>Un ingénieur d’essais cherche les points <b>les plus difficiles</b> du domaine : si le moteur se rallume là, il se rallumera ailleurs. Haut et lent, l’air est rare et fait mal tourner le moteur.</p><p>Tester hors du domaine est permis : ça renseigne, mais ça ne prouve rien pour l’exigence.</p></aside></div>`;
  root.querySelectorAll('.rl-cell').forEach(b=>b.addEventListener('click',()=>{const p={alt:+b.dataset.a,mach:+b.dataset.m};
    const i=S.pts.findIndex(x=>key(x)===key(p));if(i>=0)S.pts.splice(i,1);else S.pts.push(p);S.pts.sort((x,y)=>y.alt-x.alt||x.mach-y.mach);S.runs=null;S.decision=null;config();}));
  bindNav();
}

/* Simulation d'un point : séries temporelles N2, EGT, pression carburant, altitude */
function simuler(p,i){
  const ok=p.mach>=machMin(p.alt), tr=ok?tRallumage(p):null, lost=!S.checks.tlm&&i===1;
  const N2a=n2Auto(p.mach), serie=[];
  for(let t=0;t<=60;t+=0.5){
    let n2,egt,pf,alt=p.alt;
    if(t<5){n2=92;egt=650;pf=3.2;}
    else if(t<20){const k=(t-5);n2=N2a+(92-N2a)*Math.exp(-k/3);egt=140+(650-140)*Math.exp(-k/2.5);pf=0;alt=p.alt-k*30;}
    else{alt=p.alt-450-(t-20)*(ok?10:30);pf=2.2;
      if(ok&&t>=20+tr){const k=t-20-tr;n2=N2a+(72-N2a)*(1-Math.exp(-k/4));egt=600+260*Math.exp(-k/3)*(k<1.5?k/1.5:1);}
      else if(ok){n2=N2a+1.5*(t-20)/tr;egt=140+60*(t-20)/tr;}
      else{n2=N2a;egt=140+(t<26?40*(t-20)/6:40)-(t>=50?40:0);pf=t>=50?0:2.2;}}
    serie.push({t,n2,egt:lost?null:egt,pf,alt});
  }
  return {p,ok,tr,lost,serie,dom:inDomain(p)};
}

/* Jauges SVG */
function gauge(label,unit,v,min,max,warn,dec=0){
  const R=46,cx=60,cy=60,a0=Math.PI*0.75,a1=Math.PI*2.25,f=v===null?0:Math.max(0,Math.min(1,(v-min)/(max-min))),a=a0+(a1-a0)*f;
  const P=(ang,r)=>`${cx+r*Math.cos(ang)},${cy+r*Math.sin(ang)}`;
  const arc=(s,e,cls)=>`<path d="M${P(s,R)} A${R},${R} 0 ${e-s>Math.PI?1:0} 1 ${P(e,R)}" class="${cls}"/>`;
  const wa=warn!=null?a0+(a1-a0)*Math.max(0,Math.min(1,(warn-min)/(max-min))):null;
  return `<div class="tm-g"><svg viewBox="0 0 120 104" aria-hidden="true">${arc(a0,a1,'tm-bg')}${wa?arc(wa,a1,'tm-warn'):''}${v===null?'':arc(a0,a,'tm-val')}
    <line x1="${cx}" y1="${cy}" x2="${P(a,R-10).split(',')[0]}" y2="${P(a,R-10).split(',')[1]}" class="tm-needle"/></svg>
    <b class="${v===null?'lost':''}">${v===null?'---':fr(v,dec)}</b><span>${label}${unit?' · '+unit:''}</span></div>`;
}

/* 3. Vol et télémesure */
function vol(){
  if(!S.runs)S.runs=S.pts.map((p,i)=>simuler(p,i));
  root.innerHTML=`<div class="g-main">
    <h2>Vol d’essai : salle de télémesure</h2>
    <p>Tu suis le vol depuis le sol, comme l’équipe d’essais. Pour chaque point : stabilisation, coupure du carburant (extinction commandée), autorotation, puis allumage. Le temps est accéléré.</p>
    <div class="panel tm"><div class="tm-head mono"><span id="tm-pt">En attente</span><span id="tm-ph"></span><span id="tm-t"></span></div><div class="tm-gauges" id="tm-gauges"></div><div class="g-log mono" id="tm-log" aria-live="polite"></div></div>
    <div class="g-run"><button type="button" class="btn primary" id="tm-go">Démarrer la télémesure</button><span class="c" id="tm-st">${S.runs.length} point(s) au programme</span></div>
    ${nav('Analyser les données',false)}
  </div>`;
  bindNav();
  const G=root.querySelector('#tm-gauges'),log=root.querySelector('#tm-log');
  const draw=(r,s)=>{G.innerHTML=gauge('Altitude','ft',s.alt,0,45000,null)+gauge('Mach','',r.p.mach,0,1,null,2)+gauge('N2','%',s.n2,0,110,104)+gauge('EGT','°C',s.egt,0,1000,900)+gauge('Carburant','bar',s.pf,0,4,null,1);};
  const r0=S.runs[0];draw(r0,r0.serie[0]);
  const finish=()=>{root.querySelector('[data-next]').disabled=false;root.querySelector('#tm-st').textContent='Vol terminé, données enregistrées';root.querySelector('#tm-go').disabled=true;};
  const phase=(r,t)=>t<5?'Stabilisé':t<20?'Carburant coupé · autorotation':r.ok&&t>=20+r.tr?'Rallumé':'Allumage en cours';
  root.querySelector('#tm-go').addEventListener('click',e=>{
    e.target.disabled=true;
    const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
    if(reduce){S.runs.forEach(r=>{log.innerHTML+=bilan(r)+'<br>';});const r=S.runs[S.runs.length-1];draw(r,r.serie[r.serie.length-1]);finish();return;}
    let i=0,k=0;
    const tick=()=>{if(!document.body.contains(G))return;
      const r=S.runs[i],s=r.serie[k];draw(r,s);
      root.querySelector('#tm-pt').textContent=`Point ${i+1}/${S.runs.length} · ${fr(r.p.alt)} ft · Mach ${fr(r.p.mach,1)}`;
      root.querySelector('#tm-ph').textContent=phase(r,s.t);root.querySelector('#tm-t').textContent=`t = ${fr(s.t,1)} s`;
      if(k===10)log.innerHTML+=`Point ${i+1} : coupure carburant<br>`;
      if(k===40)log.innerHTML+=`Point ${i+1} : allumage et réouverture carburant<br>`;
      if(r.lost&&k===30)log.innerHTML+=`<span class="bad">Point ${i+1} : perte du signal EGT en télémesure</span><br>`;
      k+=1;
      if(k>=r.serie.length){log.innerHTML+=bilan(r)+'<br>';i++;k=0;if(i>=S.runs.length){finish();return;}}
      log.scrollTop=log.scrollHeight;setTimeout(tick,45);
    };tick();
  });
}
function bilan(r){return `Point ${fr(r.p.alt)} ft / M${fr(r.p.mach,1)} : `+(r.lost?'<span class="bad">données EGT perdues</span>':r.ok?`<b>rallumé en ${fr(r.tr,1)} s</b>`:'<span class="bad">pas de rallumage en 30 s, tentative arrêtée</span>');}

/* 4. Analyse et décision */
function bonneDecision(){
  const has=q=>S.runs.find(r=>r.p.alt===q.alt&&r.p.mach===q.mach);
  if(REQUIRED.some(q=>!has(q)))return 2;
  if(S.runs.some(r=>r.dom&&(r.lost||!r.ok||r.tr>30)))return 1;
  return 0;
}
const DEC=['VALIDÉ','À REFAIRE','INCOMPLET'];
function pourquoi(b){
  if(b===2)return 'Il manque au moins un point clé du domaine : le coin le plus difficile (30 000 ft, Mach 0,6) et le bas du domaine (10 000 ft, Mach 0,6). Sans eux, on ne peut pas affirmer que tout le domaine est couvert.';
  if(b===1)return 'Un point du domaine n’a pas donné de mesure exploitable (perte de télémesure) : il faut le refaire. Tester la chaîne de télémesure avant le vol aurait évité ce vol supplémentaire.';
  return 'Les points clés du domaine ont été testés et le moteur s’est rallumé en moins de 30 s partout dans le domaine.';
}
let sel=0;
function analyse(){
  const r=S.runs[sel],b=bonneDecision();
  const W=620,H=220,L=44,R=40,T=12,B=30,X=t=>L+t/60*(W-L-R),Y1=v=>T+(1-v/110)*(H-T-B),Y2=v=>T+(1-v/1000)*(H-T-B);
  const path=(f,Y)=>{let d='',pen=false;r.serie.forEach(s=>{const v=f(s);if(v===null){pen=false;return;}d+=(pen?'L':'M')+X(s.t).toFixed(1)+' '+Y(v).toFixed(1)+' ';pen=true;});return d;};
  let g='';[0,25,50,75,100].forEach(v=>{g+=`<line x1="${L}" x2="${W-R}" y1="${Y1(v)}" y2="${Y1(v)}" class="gl"/><text x="${L-6}" y="${Y1(v)+4}" text-anchor="end">${v}</text>`;});
  [0,250,500,750,1000].forEach(v=>{g+=`<text x="${W-R+6}" y="${Y2(v)+4}" text-anchor="start">${v}</text>`;});
  [0,10,20,30,40,50,60].forEach(t=>{g+=`<text x="${X(t)}" y="${H-10}" text-anchor="middle">${t}</text>`;});
  g+=`<line x1="${X(5)}" x2="${X(5)}" y1="${T}" y2="${H-B}" class="ev"/><line x1="${X(20)}" x2="${X(20)}" y1="${T}" y2="${H-B}" class="ev"/>`;
  g+=`<text x="${X(5)+4}" y="${T+10}" text-anchor="start">coupure</text><text x="${X(20)+4}" y="${T+10}" text-anchor="start">allumage</text>`;
  if(r.ok)g+=`<line x1="${X(20+r.tr)}" x2="${X(20+r.tr)}" y1="${T}" y2="${H-B}" class="ev ok"/><text x="${X(20+r.tr)+4}" y="${T+24}" text-anchor="start" class="okt">rallumé</text>`;
  g+=`<line x1="${X(50)}" x2="${X(50)}" y1="${T}" y2="${H-B}" class="ev lim"/><text x="${X(50)-4}" y="${H-B-6}" text-anchor="end" class="limt">limite 30 s</text>`;
  g+=`<path d="${path(s=>s.n2,Y1)}" class="s0" fill="none"/><path d="${path(s=>s.egt,Y2)}" class="s2" fill="none"/>`;
  root.innerHTML=`<div class="g-main">
    <h2>Analyse des données et décision</h2>
    <p>Choisis un point pour afficher ses courbes. Le rallumage se voit quand l’EGT remonte d’un coup, puis que N2 repart vers le ralenti.</p>
    <div class="chips">${S.runs.map((x,i)=>`<button type="button" class="chip" aria-pressed="${i===sel}" data-s="${i}">${fr(x.p.alt)} ft · M${fr(x.p.mach,1)}</button>`).join('')}</div>
    <div class="panel g-flight"><svg viewBox="0 0 ${W} ${H}" class="g-chart" role="img" aria-label="Courbes N2 et EGT du point choisi">${g}</svg>
      <div class="g-leg"><span><i></i>N2 (%, échelle de gauche)</span><span><i class="k2"></i>EGT (°C, échelle de droite)</span>${r.lost?'<span class="bad">EGT perdue en télémesure</span>':''}</div></div>
    <div class="tbl-scroll"><table class="g-table"><thead><tr><th>Point</th><th>Dans le domaine</th><th>Résultat</th><th>Exigence &lt; 30 s</th></tr></thead><tbody>
      ${S.runs.map(x=>`<tr><td>${fr(x.p.alt)} ft · M${fr(x.p.mach,1)}</td><td>${x.dom?'oui':'non'}</td><td class="mono">${x.lost?'données perdues':x.ok?fr(x.tr,1)+' s':'échec'}</td><td>${!x.dom?'<span class="c">non concerné</span>':x.lost?'<span class="bad">non démontré</span>':x.ok&&x.tr<30?'<b class="okc">tenue</b>':'<span class="bad">non tenue</span>'}</td></tr>`).join('')}
    </tbody></table></div>
    <h3>Ta décision sur l’essai</h3>
    <div class="dec">${DEC.map((d,i)=>`<button type="button" class="dec-b ${S.decision!==null?(i===b?'right':(i===S.decision?'wrong':'')):''}" data-d="${i}" ${S.decision!==null?'disabled':''}>${d}</button>`).join('')}</div>
    ${S.decision!==null?`<p class="why">${S.decision===b?'Bonne décision. ':'Ce n’est pas la bonne décision : la réponse attendue est '+DEC[b]+'. '}${pourquoi(b)}</p>`:''}
    ${nav('Rédiger le rapport',S.decision!==null)}
  </div>`;
  root.querySelectorAll('[data-s]').forEach(c=>c.addEventListener('click',()=>{sel=+c.dataset.s;analyse();}));
  root.querySelectorAll('[data-d]').forEach(c=>c.addEventListener('click',()=>{S.decision=+c.dataset.d;analyse();}));
  bindNav();
}

/* 5. Rapport */
function rapport(){
  const b=bonneDecision();
  try{if(window.CPS&&window.CPS.progress){window.CPS.progress.markIn('essais','exos','rallumage');window.CPS.progress.mark('essais','read',true);}}catch(e){}
  const lignes=[['RAPPORT D’ESSAI','M88 · extinction et rallumage en vol'],['Exigence','rallumage < 30 s, 10 000 à 30 000 ft, Mach ≥ 0,6 (fictive)'],
    ['Points réalisés',S.runs.map(r=>`${fr(r.p.alt)} ft / M${fr(r.p.mach,1)}`).join(', ')],
    ...S.runs.map(r=>[`Résultat ${fr(r.p.alt)} ft / M${fr(r.p.mach,1)}`,r.lost?'données perdues':r.ok?`rallumé en ${fr(r.tr,1)} s`:'pas de rallumage']),
    ['Décision attendue',DEC[b]],['Ta décision',S.decision!==null?DEC[S.decision]:'–']];
  root.innerHTML=`<div class="g-grid"><div class="g-main">
    <h2>Rapport d’essai</h2>
    <div class="panel g-report mono">${lignes.map(l=>`<div><span>${l[0]}</span><span>${l[1]}</span></div>`).join('')}</div>
    <p>${pourquoi(b)}</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px"><button type="button" class="btn" id="rl-dl">Télécharger le rapport</button><button type="button" class="btn" id="rl-csv">Télémesure (CSV)</button><button type="button" class="btn" id="rl-pdf">Rapport (PDF)</button><button type="button" class="btn" id="rl-again">Refaire la campagne</button>${S.runs.length?`<a class="btn" href="jumeau.html?avion=rafale&mach=${S.runs[0].p.mach}&alt=${S.runs[0].p.alt}&thr=72">Revoir le 1er point dans le jumeau numérique</a>`:''}<a class="btn primary" href="orientation.html#essais-vol">Découvrir le métier</a></div>
  </div><aside class="panel g-side"><h3>Dans la vraie vie</h3><p>Les essais de rallumage se préparent des mois à l’avance, souvent d’abord au banc en altitude simulée, puis en vol avec un avion d’accompagnement. Chaque point est rejoué si une mesure manque : un résultat sans données n’a aucune valeur de preuve.</p></aside></div>`;
  root.querySelector('#rl-again').addEventListener('click',()=>{S.runs=null;S.decision=null;S.max=1;go(1);});
  const X=window.CPS_EXPORT;
  root.querySelector('#rl-csv').addEventListener('click',()=>X&&X.csv('telemesure-rallumage-m88.csv',['point','altitude (ft)','Mach','dans le domaine','temps (s)','N2 (%)','EGT (°C)','débit carburant (kg/min)','altitude instantanée (ft)'],
    S.runs.flatMap((r,i)=>r.serie.map(s=>[i+1,r.p.alt,r.p.mach,r.dom?'oui':'non',s.t,s.n2,s.egt,s.pf,s.alt]))));
  root.querySelector('#rl-pdf').addEventListener('click',()=>X&&X.pdf('Rapport d’essai · rallumage du M88',[{h:'Synthèse',kv:lignes},{h:'Conclusion',p:pourquoi(b)},
    {h:'Résultats par point',table:{entetes:['Point','Domaine','Résultat','Temps de rallumage (s)'],lignes:S.runs.map(r=>[`${fr(r.p.alt)} ft · M${fr(r.p.mach,1)}`,r.dom?'oui':'non',r.lost?'données perdues':r.ok?'rallumé':'échec',r.ok&&!r.lost?r.tr:'–'])}}]));
  root.querySelector('#rl-dl').addEventListener('click',()=>window.CPS_downloadReport('rapport-essai-rallumage-m88.txt',lignes.map(l=>l[0]+' : '+l[1]).join('\n')+'\n\n'+pourquoi(b)+'\n\nCPS Aero · simulation pédagogique, mesures fictives.'));
}

render();
window.CPS_RALLUMAGE={S,machMin,tRallumage,simuler,bonneDecision};
};

/* ---------- Sélecteur de missions ---------- */
const hub=document.getElementById('missions');
if(hub){
  const start=m=>{hub.querySelectorAll('[data-mission]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mission===m)));
    document.getElementById('game').innerHTML='';window.CPS_MISSIONS[m]&&window.CPS_MISSIONS[m]();};
  hub.querySelectorAll('[data-mission]').forEach(b=>b.addEventListener('click',()=>start(b.dataset.mission)));
  start(location.hash==='#rallumage'?'rallumage':'dme');
}
})();
