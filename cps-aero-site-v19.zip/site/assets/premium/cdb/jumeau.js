/* CPSAero — Jumeau numérique (grade CDB).
   Un modèle pédagogique simplifié relie les conditions de vol (Mach, altitude), la manette et la post-combustion
   au moteur 3D du hangar (régime, couleur des gaz, flux d'air, cône de Mach) et à une télémesure en direct.
   Les ordres de grandeur viennent de données publiques ; les lois sont volontairement simples et toutes affichées sur la page.
   API pour les tests : window.CPS_TWIN = { isa, model, ENG }. */
(function(){
const fr=(x,d=0)=>Number(x).toLocaleString('fr-FR',{minimumFractionDigits:d,maximumFractionDigits:d});
const FT=0.3048,KT=1852/3600,R=287.05,GAM=1.4;

/* Données publiques arrondies (sources : motoriste et ministère des Armées). T3max, rendements : hypothèses du modèle. */
const ENG={
  rafale:{avion:'Rafale',moteur:'M88-2',n:2,Fsec:50,Fpc:75,pi:24.5,T4max:1850,T4ralenti:1050,T3max:960,sfc:0.80,sfcPc:1.75,Mmax:1.8,plafond:50000},
  mirage:{avion:'Mirage 2000',moteur:'M53-P2',n:1,Fsec:64.3,Fpc:95.1,pi:9.8,T4max:1600,T4ralenti:950,T3max:760,sfc:0.90,sfcPc:2.05,Mmax:2.2,plafond:60000}
};
const ETAc=0.85,CPA=1005,CPG=1150;

/* Atmosphère standard (ISA) */
function isa(hft){const h=hft*FT;let T,p;
  if(h<=11000){T=288.15-0.0065*h;p=101325*Math.pow(T/288.15,5.2559);}else{T=216.65;p=22632*Math.exp(-(h-11000)/6341.6);}
  return {T,p,rho:p/(R*T),a:Math.sqrt(GAM*R*T)};}

const piAt=(E,x)=>1+(E.pi-1)*(0.25+0.75*x);
const T3At=(E,Tt2,x)=>Tt2*(1+(Math.pow(piAt(E,x),(GAM-1)/GAM)-1)/ETAc);

function model(inp){
  const E=ENG[inp.avion]||ENG.rafale,M=Math.max(0,inp.mach),A=isa(Math.max(0,inp.alt)),pc=!!inp.pc;
  const k=1+0.2*M*M,Tt2=A.T*k,pt2=A.p*Math.pow(k,3.5),d2=pt2/101325,th2=Tt2/288.15;
  const xd=pc?1:Math.max(0,Math.min(1,inp.x));
  // le FADEC limite la température en sortie de compresseur : on cherche le régime le plus haut tel que T3 ≤ T3max
  let xe=xd;
  if(T3At(E,Tt2,xd)>E.T3max){let lo=0,hi=xd;if(T3At(E,Tt2,0)>E.T3max)xe=0;else{for(let i=0;i<40;i++){const m=(lo+hi)/2;if(T3At(E,Tt2,m)>E.T3max)hi=m;else lo=m;}xe=lo;}}
  const limite=xe<xd-0.005;
  const pi=piAt(E,xe),T3=T3At(E,Tt2,xe);
  const T4=E.T4ralenti+(E.T4max-E.T4ralenti)*xe;
  const T5=T4-(CPA/CPG)*(T3-Tt2);                       // la turbine fournit le travail du compresseur
  const phi=0.08+0.92*Math.pow(xe,2.2);
  const F0=E.Fsec*phi+(pc?(E.Fpc-E.Fsec)*(0.6+0.4*xe):0);
  const lam=1/(1+(pc?0.35:0.6)*M);
  const F=Math.max(0,F0*d2*lam);                         // kN par moteur
  const sfc=(pc?E.sfcPc:E.sfc)*Math.sqrt(th2);           // kg/(daN·h)
  const ff=sfc*F*100;                                    // kg/h par moteur
  const V=M*A.a,q=0.5*A.rho*V*V;
  const alertes=[];
  if(limite)alertes.push(`Limite T3 : l’air arrive déjà à ${fr(Tt2)} K à cause de la vitesse. Pour ne pas dépasser ${fr(E.T3max)} K en sortie de compresseur, le FADEC ramène le régime de ${fr(xd*100)} % à ${fr(xe*100)} %.`);
  if(M>E.Mmax)alertes.push(`Mach ${fr(M,2)} : au-delà du Mach maximal public du ${E.avion} (Mach ${fr(E.Mmax,1)}).`);
  if(inp.alt>E.plafond)alertes.push(`${fr(inp.alt)} ft : au-dessus du plafond public du ${E.avion} (≈ ${fr(E.plafond)} ft).`);
  return {E,A,M,Tt2,pt2,d2,th2,xd,xe,limite,pi,T3,T4,T5,F,Ftot:F*E.n,sfc,ff,fftot:ff*E.n,V,q,n2:65+35*xe,
    mu:M>1?Math.asin(1/M)*180/Math.PI:null,alertes,pc};
}
window.CPS_TWIN={isa,model,ENG};

/* ---------------- Interface ---------------- */
const $=id=>document.getElementById(id);
const root=$('jumeau');if(!root)return;
const S={avion:'rafale',mach:0.9,alt:30000,x:0.85,pc:false};
const DOM={mach:[0,2.2,0.01],alt:[0,55000,500],x:[0,100,1]};
const PRESETS={sol:{mach:0,alt:0,x:0,pc:false,n:'Ralenti au sol'},decollage:{mach:0.25,alt:0,x:1,pc:true,n:'Décollage'},
  croisiere:{mach:0.9,alt:30000,x:0.85,pc:false,n:'Croisière'},super:{mach:1.6,alt:36000,x:1,pc:true,n:'Supersonique'},
  haut:{mach:2,alt:45000,x:1,pc:true,n:'Mach 2 en altitude'}};
// paramètres d'adresse : jumeau.html?mach=1.4&alt=35000&thr=90&pc=1&avion=mirage (liens depuis les calculateurs et les essais)
try{const u=new URLSearchParams(location.search),num=(k,a,b)=>{const v=parseFloat(u.get(k));return isFinite(v)?Math.max(a,Math.min(b,v)):null;};
  const m=num('mach',0,2.2),h=num('alt',0,55000),t=num('thr',0,100);if(m!==null)S.mach=m;if(h!==null)S.alt=h;if(t!==null)S.x=t/100;
  if(u.get('pc')==='1'){S.pc=true;S.x=1;}if(ENG[u.get('avion')])S.avion=u.get('avion');}catch(e){}

const hist=[];let tLast=0,t0=performance.now();
function gauge(label,unit,v,min,max,warn,dec=0){
  const Rg=46,cx=60,cy=60,a0=Math.PI*0.75,a1=Math.PI*2.25,f=Math.max(0,Math.min(1,(v-min)/(max-min))),a=a0+(a1-a0)*f;
  const P=(ang,r)=>[cx+r*Math.cos(ang),cy+r*Math.sin(ang)];
  const arc=(s,e,cls)=>{const p=P(s,Rg),q=P(e,Rg);return `<path d="M${p[0].toFixed(1)},${p[1].toFixed(1)} A${Rg},${Rg} 0 ${e-s>Math.PI?1:0} 1 ${q[0].toFixed(1)},${q[1].toFixed(1)}" class="${cls}"/>`;};
  const wa=warn!=null?a0+(a1-a0)*Math.max(0,Math.min(1,(warn-min)/(max-min))):null,n=P(a,Rg-10),hot=warn!=null&&v>warn*1.002;
  return `<div class="tm-g${hot?' hot':''}"><svg viewBox="0 0 120 104" aria-hidden="true">${arc(a0,a1,'tm-bg')}${wa?arc(wa,a1,'tm-warn'):''}${arc(a0,Math.max(a0+0.001,a),'tm-val')}
    <line x1="${cx}" y1="${cy}" x2="${n[0].toFixed(1)}" y2="${n[1].toFixed(1)}" class="tm-needle"/></svg><b>${fr(v,dec)}</b><span>${label}${unit?' · '+unit:''}</span></div>`;
}
function trace(){
  const W=640,H=170,L=40,Rr=40,Tp=12,B=22,n=hist.length;if(n<2)return '';
  const tmax=hist[n-1].t,tmin=Math.max(0,tmax-60),X=t=>L+(t-tmin)/60*(W-L-Rr);
  const fmax=Math.max(10,...hist.map(h=>h.F))*1.15,tm=2000;
  const Y1=v=>Tp+(1-v/fmax)*(H-Tp-B),Y2=v=>Tp+(1-(v-600)/(tm-600))*(H-Tp-B);
  const path=(fy,key)=>hist.filter(h=>h.t>=tmin).map((h,i)=>(i?'L':'M')+X(h.t).toFixed(1)+' '+fy(h[key]).toFixed(1)).join(' ');
  let g='';for(let i=0;i<=3;i++){const y=Tp+i*(H-Tp-B)/3;g+=`<line x1="${L}" x2="${W-Rr}" y1="${y}" y2="${y}" class="gl"/><text x="${L-6}" y="${y+4}" text-anchor="end">${fr(fmax*(1-i/3))}</text><text x="${W-Rr+6}" y="${y+4}">${fr(tm-(tm-600)*i/3)}</text>`;}
  g+=`<text x="${L}" y="${H-4}">− 60 s</text><text x="${W-Rr}" y="${H-4}" text-anchor="end">maintenant</text>`;
  return `<svg viewBox="0 0 ${W} ${H}" class="g-chart j-chart" role="img" aria-label="Poussée totale et température T4 sur la dernière minute">${g}<path d="${path(Y1,'F')}" class="s0" fill="none"/><path d="${path(Y2,'T4')}" class="s3" fill="none" stroke-dasharray="5 4"/></svg>`;
}
let R0=null;
function render(push){
  const r=model(S);R0=r;const E=r.E;
  const fmax=(E.Fpc*E.n)*1.25,ffmax=E.sfcPc*E.Fpc*100*E.n*1.2;
  $('j-gauges').innerHTML=gauge('Régime N2','%',r.n2,50,110,100)+gauge('T4 turbine','K',r.T4,800,2000,E.T4max)+gauge('T3 compresseur','K',r.T3,250,1000,E.T3max)
    +gauge('EGT (sortie turbine)','K',r.T5,400,1700,null)+gauge(`Poussée ×${E.n}`,'kN',r.Ftot,0,fmax,null)+gauge('Carburant','kg/min',r.fftot/60,0,ffmax/60,null,1);
  const rows=[['Température extérieure',`${fr(r.A.T-273.15)} °C (${fr(r.A.T,1)} K)`],['Pression · masse volumique',`${fr(r.A.p/100)} hPa · ${fr(r.A.rho,3)} kg/m³`],
    ['Vitesse du son a',`${fr(r.A.a,1)} m/s`],['Vitesse propre V = M·a',`${fr(r.V/KT)} kt · ${fr(r.V*3.6)} km/h`],['Pression dynamique q = ½ρV²',`${fr(r.q/1000,1)} kPa`],
    ['Température d’arrêt Tt2 (nez, entrée d’air)',`${fr(r.Tt2)} K · ${fr(r.Tt2-273.15)} °C`],['Taux de compression π',fr(r.pi,1)],
    ['Consommation spécifique',`${fr(r.sfc,2)} kg/(daN·h)`],['Demi-angle du cône de Mach μ',r.mu?`${fr(r.mu,1)}°`:'subsonique : pas d’onde de choc attachée']];
  $('j-read').innerHTML=rows.map(x=>`<div><dt>${x[0]}</dt><dd>${x[1]}</dd></div>`).join('');
  $('j-warn').innerHTML=r.alertes.length?r.alertes.map(a=>`<p class="fb bad" role="alert">${a}</p>`).join(''):`<p class="fb ok">Point de vol dans le domaine du modèle : aucune limite atteinte.</p>`;
  const sh=$('j-shock');if(sh)sh.textContent=r.mu?`Supersonique : un cône de choc part du nez avec un demi-angle μ = arcsin(1/M) = ${fr(r.mu,1)}°.`:r.M>=0.8?'Transsonique : des zones supersoniques apparaissent déjà sur l’avion.':'Subsonique : l’air est prévenu de l’arrivée de l’avion, pas d’onde de choc.';
  const hud=`<span>${E.avion.toUpperCase()} · MACH <b>${fr(r.M,2)}</b></span><span>ALT <b>${fr(S.alt)} FT</b></span><span>N2 <b class="${r.limite?'warn':''}">${fr(r.n2)} %</b></span><span>T4 <b>${fr(r.T4)} K</b></span><span>PC <b class="${r.pc?'on':''}">${r.pc?'ALLUMÉE':'ÉTEINTE'}</b></span><span>F <b>${fr(r.Ftot,1)} kN</b></span>`;
  if(window.CPS_HANGAR&&CPS_HANGAR.twin)CPS_HANGAR.twin({mach:r.M,x:r.xe,pc:r.pc,hud});
  if(push)sample();
  $('j-trace').innerHTML=trace();
  const lk=$('j-link');if(lk)lk.dataset.url=`${location.origin}${location.pathname}?avion=${S.avion}&mach=${S.mach}&alt=${S.alt}&thr=${Math.round(S.x*100)}${S.pc?'&pc=1':''}`;
}
function sample(){const t=(performance.now()-t0)/1000,r=R0;if(!r)return;hist.push({t,mach:r.M,alt:S.alt,thr:S.pc?100:Math.round(S.x*100),pc:r.pc?1:0,n2:r.n2,T3:r.T3,T4:r.T4,T5:r.T5,F:r.Ftot,ff:r.fftot,q:r.q});
  while(hist.length&&hist[0].t<t-120)hist.shift();}
// échantillonnage continu : la télémesure défile même sans toucher aux commandes
setInterval(()=>{if(document.hidden)return;sample();const tr=$('j-trace');if(tr)tr.innerHTML=trace();},500);

/* Saisie : curseur + case, erreur en rouge si hors domaine */
function bind(key,scale){
  const rg=$('j-'+key),num=$('j-'+key+'-n'),err=$('j-'+key+'-e'),[mn,mx]=DOM[key];
  const show=v=>{rg.value=v;num.value=v;};
  show(key==='x'?Math.round(S.x*100):S[key]);
  rg.addEventListener('input',()=>{num.value=rg.value;num.removeAttribute('aria-invalid');err.textContent='';S[key]=+rg.value/scale;if(key==='x'&&S.pc&&S.x<1){S.pc=false;$('j-pc').checked=false;}mark(null);render(true);});
  num.addEventListener('input',()=>{const v=parseFloat(String(num.value).replace(',','.'));
    if(!isFinite(v)||v<mn||v>mx){num.setAttribute('aria-invalid','true');err.textContent=`Valeur hors domaine : entre ${fr(mn,key==='mach'?1:0)} et ${fr(mx,key==='mach'?1:0)}.`;return;}
    num.removeAttribute('aria-invalid');err.textContent='';rg.value=v;S[key]=v/scale;mark(null);render(true);});
}
function mark(k){document.querySelectorAll('[data-preset]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.preset===k)));}
function setAll(){$('j-mach').value=$('j-mach-n').value=S.mach;$('j-alt').value=$('j-alt-n').value=S.alt;$('j-x').value=$('j-x-n').value=Math.round(S.x*100);$('j-pc').checked=S.pc;
  ['mach','alt','x'].forEach(k=>{$('j-'+k+'-n').removeAttribute('aria-invalid');$('j-'+k+'-e').textContent='';});}
bind('mach',1);bind('alt',1);bind('x',100);
$('j-pc').checked=S.pc;
$('j-pc').addEventListener('change',()=>{S.pc=$('j-pc').checked;if(S.pc){S.x=1;setAll();}mark(null);render(true);});
document.querySelectorAll('[data-preset]').forEach(b=>b.addEventListener('click',()=>{const p=PRESETS[b.dataset.preset];Object.assign(S,{mach:p.mach,alt:p.alt,x:p.x,pc:p.pc});setAll();mark(b.dataset.preset);render(true);}));
// avion : suit les boutons du hangar
document.querySelectorAll('[data-duo]').forEach(b=>b.addEventListener('click',()=>{if(ENG[b.dataset.duo]){S.avion=b.dataset.duo;render(true);}}));
if(window.CPS_HANGAR&&CPS_HANGAR.setDuo)CPS_HANGAR.setDuo(S.avion);

/* Exports */
const csvRows=()=>hist.map(h=>[h.t,h.mach,h.alt,h.thr,h.pc,h.n2,h.T3,h.T4,h.T5,h.F,h.ff,h.q/1000]);
$('j-csv').addEventListener('click',()=>{window.CPS_EXPORT&&CPS_EXPORT.csv(`telemesure-jumeau-${S.avion}.csv`,
  ['temps (s)','Mach','altitude (ft)','manette (%)','post-combustion','N2 (%)','T3 (K)','T4 (K)','EGT (K)','poussée totale (kN)','carburant (kg/h)','q (kPa)'],csvRows());});
$('j-pdf').addEventListener('click',()=>{const r=R0,E=r.E;if(!window.CPS_EXPORT)return;
  CPS_EXPORT.pdf(`Jumeau numérique · ${E.avion} / ${E.moteur}`,[
    {h:'Point de vol',kv:[['Avion · moteur',`${E.avion} · ${E.n} × ${E.moteur}`],['Mach',fr(r.M,2)],['Altitude',`${fr(S.alt)} ft`],['Manette demandée',`${fr(r.xd*100)} %`],['Post-combustion',r.pc?'allumée':'éteinte']]},
    {h:'Moteur',kv:[['Régime réel N2',`${fr(r.n2)} %${r.limite?' (limité par le FADEC)':''}`],['Taux de compression π',fr(r.pi,1)],['T3 sortie compresseur',`${fr(r.T3)} K`],['T4 entrée turbine',`${fr(r.T4)} K`],['EGT sortie turbine',`${fr(r.T5)} K`],
      ['Poussée',`${fr(r.F,1)} kN par moteur · ${fr(r.Ftot,1)} kN au total`],['Carburant',`${fr(r.fftot)} kg/h au total`]]},
    {h:'Air et avion',kv:[['Température extérieure',`${fr(r.A.T-273.15)} °C`],['Masse volumique',`${fr(r.A.rho,3)} kg/m³`],['Vitesse propre',`${fr(r.V/KT)} kt`],['Pression dynamique',`${fr(r.q/1000,1)} kPa`],['Température d’arrêt',`${fr(r.Tt2)} K`],['Cône de Mach',r.mu?`${fr(r.mu,1)}°`:'—']]},
    {h:'Alertes',p:r.alertes.length?r.alertes.join(' '):'Aucune limite atteinte.'},
    {h:'Télémesure (dernière minute)',svg:trace()},
    {h:'Modèle',p:'Atmosphère standard ; entrée d’air idéale (Tt2 = T(1+0,2M²), pt2 = p(1+0,2M²)^3,5) ; T3 = Tt2[1+(π^0,286−1)/0,85] limitée par le FADEC ; EGT = T4 − (1005/1150)(T3 − Tt2) ; poussée = F0 · (pt2/p0) / (1 + k·M). Lois simplifiées à but pédagogique.'}]);});
$('j-link').addEventListener('click',e=>{const u=e.target.dataset.url,ok=()=>{e.target.textContent='Lien copié ✓';setTimeout(()=>e.target.textContent='Copier le lien de ce point',1600);};
  if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(u).then(ok,()=>{e.target.textContent='Copie impossible';});});
render(true);
// la 3D peut finir de se charger après ce script : on lui renvoie l'état
addEventListener('load',()=>{if(window.CPS_HANGAR&&CPS_HANGAR.setDuo)CPS_HANGAR.setDuo(S.avion);render(false);});
})();
