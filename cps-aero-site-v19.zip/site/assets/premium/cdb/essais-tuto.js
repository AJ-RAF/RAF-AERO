/* CPSAero — tutoriel d'accueil du simulateur d'essais en vol (4 étapes).
   S'ouvre à la première visite (localStorage « cps-essais-tuto »), puis via le bouton « Revoir le tutoriel ».
   1. Qui fait quoi (IEV, pilote, technicien)  2. Les paramètres surveillés  3. Lire une courbe de télémesure  4. Lancer la mission. */
(function(){
  const LS='cps-essais-tuto';
  const head=document.querySelector('.page-head');if(!head||!document.getElementById('game'))return;
  // une trace de télémesure : palier stable (A) ou point perturbé (B)
  function trace(kind){
    const W=300,H=120,x0=34,x1=290,y=v=>H-18-v*(H-36);let alt='',egt='';
    for(let i=0;i<=60;i++){const t=i/60,x=x0+t*(x1-x0);
      let a=0.75+0.03*Math.sin(t*40)*(kind==='A'?0.4:1),e=0.2+0.02*Math.sin(t*23);
      if(kind==='B'){a+=t>0.45?(t-0.45)*0.4:0;if(t>0.55&&t<0.72)e+=0.33*Math.sin((t-0.55)/0.17*Math.PI);}
      alt+=(i?'L':'M')+x.toFixed(1)+' '+y(Math.min(0.98,a)).toFixed(1)+' ';egt+=(i?'L':'M')+x.toFixed(1)+' '+y(e).toFixed(1)+' ';}
    const band=`<rect x="${x0}" y="${y(0.83)}" width="${x1-x0}" height="${y(0.67)-y(0.83)}" fill="var(--green)" opacity=".12"/>`;
    const lim=`<line x1="${x0}" x2="${x1}" y1="${y(0.45)}" y2="${y(0.45)}" stroke="var(--red)" stroke-dasharray="5 4"/><text x="${x1}" y="${y(0.45)-4}" font-size="10" fill="var(--red)" text-anchor="end">limite EGT</text>`;
    return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Enregistrement ${kind} : altitude et EGT en fonction du temps">${band}${lim}
      <path d="${alt}" fill="none" stroke="var(--cyan)" stroke-width="2.2"/><path d="${egt}" fill="none" stroke="var(--amber)" stroke-width="2.2"/>
      <line x1="${x0}" x2="${x0}" y1="10" y2="${H-18}" stroke="var(--line2)"/><line x1="${x0}" x2="${x1}" y1="${H-18}" y2="${H-18}" stroke="var(--line2)"/>
      <text x="${(x0+x1)/2}" y="${H-4}" font-size="10" fill="var(--muted)" text-anchor="middle">temps (60 s)</text>
      <text x="6" y="16" font-size="12" font-weight="700" fill="var(--fg)">${kind}</text><text x="30" y="${y(0.75)+3}" font-size="10" fill="var(--cyan)" text-anchor="end">alt</text><text x="30" y="${y(0.2)+3}" font-size="10" fill="var(--amber)" text-anchor="end">EGT</text></svg>`;
  }
  const STEPS=[
    {t:'Qui fait quoi pendant un essai ?',h:`<div class="tuto-roles">
      <div class="panel"><b>L’ingénieur d’essais en vol (IEV)</b><p>Il prépare le programme : quels points de vol, dans quel ordre, avec quels critères de réussite. Pendant le vol, il suit les mesures (à bord ou en salle de télémesure au sol) et décide si chaque point est valide. Après le vol, il analyse et rédige le rapport.</p></div>
      <div class="panel"><b>Le pilote d’essai</b><p>Il amène l’avion exactement sur le point demandé (altitude, vitesse, régime) et le tient stable le temps de la mesure. Il a toujours le dernier mot sur la sécurité.</p></div>
      <div class="panel"><b>Le technicien d’essais</b><p>Il installe et étalonne l’instrumentation : capteurs, câblage, enregistreurs, émetteur de télémesure. Il vérifie que toute la chaîne de mesure est juste avant le vol, puis aide au dépouillement des données.</p></div></div>
      <p class="tuto-small">Dans ce simulateur, tu joues l’IEV : tu choisis les points, tu surveilles les mesures et tu conclus.</p>`},
    {t:'Les paramètres à surveiller',h:`<div class="tuto-params">
      <div><b>Vitesse</b><span>kt</span><p>Le point n’est exploitable que si la vitesse reste dans sa tolérance pendant la mesure.</p></div>
      <div><b>Altitude</b><span>ft</span><p>On mesure en palier stabilisé : l’altitude ne doit pas dériver pendant l’enregistrement.</p></div>
      <div><b>EGT</b><span>°C</span><p>Température des gaz d’échappement : le meilleur indicateur de la santé du moteur. Elle a une limite à ne jamais dépasser.</p></div>
      <div><b>Pressions</b><span>bar, hPa</span><p>Huile, carburant, cabine : une pression qui chute ou oscille signale un problème avant qu’il soit grave.</p></div></div>
      <p class="tuto-small">Tolérances de l’exercice : ±100 ft en altitude et ±5 kt en vitesse pendant au moins 30 s. Ce sont des valeurs d’entraînement, chaque programme réel fixe les siennes.</p>`},
    {t:'Lire une courbe de télémesure',h:`<p>Deux enregistrements du même point d’essai. En <span style="color:var(--cyan);font-weight:600">cyan</span> l’altitude, avec sa bande de tolérance verte ; en <span style="color:var(--amber);font-weight:600">ambre</span> l’EGT, avec sa limite rouge. <b>Lequel donne un point valide ?</b></p>
      <div class="tuto-traces"><button type="button" class="tuto-tr" data-tr="A">${trace('A')}</button><button type="button" class="tuto-tr" data-tr="B">${trace('B')}</button></div>
      <p class="tuto-why" aria-live="polite"></p>`},
    {t:'À toi de jouer',h:`<ol class="tuto-recap"><li><b>Objectif</b> : lis l’exigence à démontrer.</li><li><b>Paramètres</b> : choisis l’avion et les points de vol.</li><li><b>Briefing</b> : coche la liste de vérification, comme avant un vrai vol.</li><li><b>Vol et mesures</b> : regarde les mesures arriver.</li><li><b>Analyse et débriefing</b> : point valide ou à refaire ? Conclus comme un IEV.</li></ol>
      <p class="tuto-small">Les exigences et les mesures sont inventées pour l’exercice ; la physique (horizon radio, distance oblique, rallumage) est réelle.</p>`}
  ];
  let dlg,i=0;
  function render(){
    const s=STEPS[i],last=i===STEPS.length-1;
    dlg.innerHTML=`<div class="hab-in"><button type="button" class="hab-x" aria-label="Fermer le tutoriel">×</button>
      <div class="hab-bar"><span>Tutoriel · étape ${i+1} / ${STEPS.length}</span><span></span></div><div class="hab-prog" aria-hidden="true"><i style="width:${(i+1)/STEPS.length*100}%"></i></div>
      <h2 id="tuto-t">${s.t}</h2>${s.h}
      <div class="hab-nav">${i?'<button type="button" class="btn" data-a="prev">Précédent</button>':'<button type="button" class="btn" data-a="skip">Passer le tutoriel</button>'}
      ${last?'<button type="button" class="btn primary" data-a="go">Lancer la mission guidée →</button>':'<button type="button" class="btn primary" data-a="next">Suivant</button>'}</div></div>`;
    dlg.querySelector('.hab-x').onclick=close;
    dlg.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>{const a=b.dataset.a;if(a==='next'){i++;render();}else if(a==='prev'){i--;render();}else if(a==='skip')close();else launch();});
    dlg.querySelectorAll('[data-tr]').forEach(b=>b.onclick=()=>{const good=b.dataset.tr==='A';
      dlg.querySelectorAll('[data-tr]').forEach(x=>x.classList.toggle(x.dataset.tr==='A'?'right':'wrong',true));
      dlg.querySelector('.tuto-why').innerHTML=(good?'<b>Exact.</b> ':'<b>Non : c’est A.</b> ')+'En A, l’altitude reste dans sa bande pendant toute la mesure et l’EGT reste loin de sa limite : le point est valide. En B, l’altitude sort de la tolérance à mi-parcours (l’avion n’était plus stabilisé) et l’EGT dépasse brièvement sa limite : le point est à refaire, et le dépassement d’EGT est à signaler au motoriste.';});
    const f=dlg.querySelector('[data-a="next"],[data-a="go"]');if(f)f.focus();
  }
  function open(){if(!dlg){dlg=document.createElement('dialog');dlg.className='hab-dlg tuto-dlg';dlg.setAttribute('aria-labelledby','tuto-t');dlg.addEventListener('click',e=>{if(e.target===dlg)close();});document.body.appendChild(dlg);}
    i=0;render();if(!dlg.open){try{dlg.showModal();}catch(e){dlg.setAttribute('open','');}}}
  function close(){try{localStorage.setItem(LS,'1');}catch(e){}if(dlg&&dlg.open)dlg.close();}
  function launch(){close();const b=document.querySelector('[data-mission="dme"]');if(b)b.click();const g=document.getElementById('game-steps')||document.getElementById('game');if(g)g.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});}
  const btn=document.createElement('button');btn.type='button';btn.className='btn small tuto-open';btn.textContent='Revoir le tutoriel (4 étapes)';btn.onclick=open;head.appendChild(btn);
  let seen=false;try{seen=!!localStorage.getItem(LS);}catch(e){}
  if(!seen&&!/[?&]visite=1/.test(location.search))setTimeout(open,400);
  window.CPS_ESSAIS_TUTO={open,close};
})();
