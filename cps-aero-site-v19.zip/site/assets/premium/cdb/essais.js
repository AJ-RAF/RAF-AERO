/* CPS Aero — Campagne d'essais en vol guidée : « Le DME tient-il en altitude ? »
   Les exigences et les mesures sont fictives (simulées) mais suivent la physique : horizon radio, portée DME, distance oblique. */
(function(){
window.CPS_MISSIONS=window.CPS_MISSIONS||{};
window.CPS_MISSIONS.dme=function(){
const root=document.getElementById('game'); if(!root)return;
const fr=(x,d=0)=>Number(x).toLocaleString('fr-FR',{minimumFractionDigits:d,maximumFractionDigits:d});
const H_STATION=50, DME_MAX=199;
const AVIONS={
  atr:{n:'ATR 72',mmin:13,mmax:23,plaf:25000,vmin:180,vmax:300,v:270,m:18},
  a320:{n:'Airbus A320',mmin:45,mmax:78,plaf:39000,vmin:250,vmax:480,v:450,m:60},
  rafale:{n:'Rafale',mmin:10,mmax:24.5,plaf:50000,vmin:300,vmax:700,v:480,m:14}
};
const FLS=[50,100,200,300,400];
const ETAPES=['Objectif','Paramètres','Briefing','Vol et mesures','Analyse','Débriefing'];
const S={step:0,max:0,avion:'a320',masse:60,vitesse:450,fls:[100,300],checks:{},mesures:null,reponses:{}};

/* Physique */
const horizon=hft=>1.23*(Math.sqrt(hft)+Math.sqrt(H_STATION));
const plafond=a=>{const A=AVIONS[a];return Math.round(A.plaf-(S.masse-A.mmin)/(A.mmax-A.mmin)*6000);};
const attendu=fl=>Math.min(horizon(fl*100),DME_MAX);
const branche=fl=>attendu(fl)+10;
function dureeTotale(){return S.fls.filter(fl=>fl*100<=plafond(S.avion)).reduce((t,fl)=>t+2*branche(fl)/S.vitesse*60+10,0);}
function rng(seed){let x=seed;return()=>{x=(x*16807)%2147483647;return (x-1)/2147483646;};}

const stepper=document.getElementById('game-steps');
function renderStepper(){
  stepper.innerHTML=ETAPES.map((e,i)=>`<button type="button" ${i===S.step?'aria-current="step"':''} class="${i<S.max?'done':''}" ${i>S.max?'disabled':''} data-i="${i}">${e}<small>${["Ce qu’on veut prouver","Ce qu’on règle","Ce qu’on prépare","Ce qu’on mesure","Ce qu’on conclut","Ce qu’on retient"][i]||""}</small></button>`).join('');
  stepper.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>go(+b.dataset.i)));
}
function go(i){S.step=i;S.max=Math.max(S.max,i);render();root.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});}
function next(){go(S.step+1);}
function nav(label,ok=true){return `<div class="g-nav">${S.step>0?'<button type="button" class="btn small" data-back>Étape précédente</button>':'<span></span>'}<button type="button" class="btn primary" data-next ${ok?'':'disabled'}>${label}</button></div>`;}
function bindNav(){const n=root.querySelector('[data-next]');if(n)n.addEventListener('click',next);const b=root.querySelector('[data-back]');if(b)b.addEventListener('click',()=>go(S.step-1));}

function render(){
  renderStepper();
  [objectif,parametres,briefing,vol,analyse,debrief][S.step]();
}

/* 1. Objectif */
function objectif(){
  root.innerHTML=`<div class="g-grid">
    <div class="g-main">
      <span class="pill goal">Mission</span>
      <h2>Le DME de bord tient-il en altitude ?</h2>
      <p>Un nouvel équipement DME vient d’être installé. Avant de le déclarer bon pour le service, ton équipe doit vérifier en vol deux exigences. Elles sont fictives, pour l’exercice, mais ressemblent à de vraies exigences d’essai.</p>
      <div class="g-req"><b>E1</b><span>Au niveau de vol 300 (30 000 ft), le DME doit accrocher la balise à <b>au moins 150 NM</b>.</span></div>
      <div class="g-req"><b>E2</b><span>Près de la balise, l’écart entre la distance affichée et la distance au sol doit être <b>mesuré et expliqué</b>.</span></div>
      <p>Ton rôle : ingénieur d’essais en vol. Tu prépares le vol, tu suis les mesures, tu analyses les courbes et tu rédiges la conclusion.</p>
      ${nav('Accepter la mission')}
    </div>
    <aside class="panel g-side"><h3>Le DME en 20 secondes</h3><p>L’avion envoie des impulsions radio, la balise au sol répond. Le temps de l’aller-retour donne la distance en ligne droite. Le principe complet est dans le <a href="dme.html">chapitre DME</a>.</p></aside>
  </div>`;bindNav();
}

/* 2. Paramètres */
function parametres(){
  const A=AVIONS[S.avion], pl=plafond(S.avion), dur=dureeTotale();
  const okFl=S.fls.filter(fl=>fl*100<=pl);
  const warn=[];
  if(S.masse<A.mmin||S.masse>A.mmax)warn.push(`La masse doit rester entre ${fr(A.mmin,1)} et ${fr(A.mmax,1)} t pour un ${A.n}.`);
  if(S.vitesse<A.vmin||S.vitesse>A.vmax)warn.push(`La vitesse doit rester entre ${A.vmin} et ${A.vmax} kt pour un ${A.n}.`);
  S.fls.filter(fl=>fl*100>pl).forEach(fl=>warn.push(`Le FL${fl} est au-dessus du plafond de l’avion à cette masse (${fr(pl)} ft) : ce palier sera annulé.`));
  if(!okFl.includes(300))warn.push('Sans palier au FL300 atteignable, l’exigence E1 ne pourra pas être vérifiée.');
  if(dur>180)warn.push(`Le vol durerait ${fr(dur)} min : c’est plus que les 3 h de vol réservées. Retire un palier ou va plus vite.`);
  const blocking=okFl.length===0||S.masse<A.mmin||S.masse>A.mmax||S.vitesse<A.vmin||S.vitesse>A.vmax||dur>180;
  root.innerHTML=`<div class="g-grid"><div class="g-main">
    <h2>Préparer le vol</h2>
    <p>Choisis l’avion d’essai, sa masse, sa vitesse et les paliers d’altitude où tu feras les mesures. Comme dans la réalité, tout n’est pas compatible : plus l’avion est lourd, moins il monte haut, et le temps de vol réservé est limité.</p>
    <div class="fields">
      <div class="field"><label for="g-av">Avion d’essai</label><select id="g-av">${Object.entries(AVIONS).map(([k,a])=>`<option value="${k}" ${k===S.avion?'selected':''}>${a.n}</option>`).join('')}</select></div>
      <div class="field"><label for="g-m">Masse <span class="u">t · ${fr(A.mmin,1)} à ${fr(A.mmax,1)}</span></label><input id="g-m" type="number" step="0.5" value="${S.masse}"></div>
      <div class="field"><label for="g-v">Vitesse sur les branches <span class="u">kt · ${A.vmin} à ${A.vmax}</span></label><input id="g-v" type="number" step="10" value="${S.vitesse}"></div>
    </div>
    <h3 style="margin-top:18px">Paliers de mesure</h3>
    <div class="chips" id="g-fl">${FLS.map(fl=>`<button type="button" class="chip" aria-pressed="${S.fls.includes(fl)}" data-fl="${fl}">FL${fl} · ${fr(fl*100)} ft</button>`).join('')}</div>
    <div class="g-calc panel"><div><span>Plafond à cette masse</span><b>${fr(pl)} ft</b></div><div><span>Paliers réalisables</span><b>${okFl.length} / ${S.fls.length}</b></div><div><span>Durée estimée</span><b class="${dur>180?'bad':''}">${fr(dur)} min</b></div></div>
    ${warn.length?`<ul class="g-warn">${warn.map(w=>`<li>${w}</li>`).join('')}</ul>`:'<p class="fb good">Plan cohérent : tu peux passer au briefing.</p>'}
    ${nav('Valider le plan de vol',!blocking)}
  </div>
  <aside class="panel g-side"><h3>Pourquoi la masse compte</h3><p>Plus l’avion est lourd, plus l’aile doit porter. En altitude, l’air rare porte moins : un avion lourd atteint donc un plafond plus bas. Ici, un modèle simplifié retire jusqu’à 6 000 ft au plafond quand l’avion est plein.</p>
  <h3>Pourquoi la durée</h3><p>Pour chaque palier, l’avion s’éloigne jusqu’à perdre le signal, puis revient. Plus la portée est grande, plus la branche est longue.</p></aside></div>`;
  root.querySelector('#g-av').addEventListener('change',e=>{S.avion=e.target.value;const a=AVIONS[S.avion];S.masse=a.m;S.vitesse=a.v;parametres();});
  root.querySelector('#g-m').addEventListener('change',e=>{S.masse=parseFloat(e.target.value.replace(',','.'))||0;parametres();});
  root.querySelector('#g-v').addEventListener('change',e=>{S.vitesse=parseFloat(e.target.value.replace(',','.'))||0;parametres();});
  root.querySelectorAll('[data-fl]').forEach(b=>b.addEventListener('click',()=>{const fl=+b.dataset.fl;S.fls=S.fls.includes(fl)?S.fls.filter(x=>x!==fl):[...S.fls,fl].sort((a,b)=>a-b);parametres();}));
  bindNav();S.mesures=null;
}

/* 3. Briefing */
const CHECK=[['meteo','Météo de la zone d’essai vérifiée'],['notam','Balise DME en service (pas de NOTAM d’indisponibilité)'],['zone','Zone d’essai réservée auprès du contrôle aérien'],['carbu','Carburant calculé avec la réserve réglementaire'],['instru','Enregistreur de mesures étalonné et synchronisé']];
function plan(){return S.fls.filter(fl=>fl*100<=plafond(S.avion));}
function briefing(){
  const all=CHECK.every(c=>S.checks[c[0]]);
  root.innerHTML=`<div class="g-grid"><div class="g-main">
    <h2>Briefing</h2>
    <p>Avant chaque vol d’essai, l’équipe se réunit : on revoit les points de mesure, ce qu’on s’attend à trouver, et la sécurité.</p>
    <h3>Ce qu’on s’attend à mesurer</h3>
    <p>Les ondes du DME vont en ligne droite : au-delà de l’horizon, la Terre cache la balise. La portée théorique est l’<b>horizon radio</b> :</p>
    <div class="eq">d<sub>horizon</sub> ≈ 1,23 × ( √h<sub>avion</sub> + √h<sub>balise</sub> )   <span class="c">← d en NM, hauteurs en pieds</span></div>
    <div class="tbl-scroll"><table class="g-table"><thead><tr><th>Palier</th><th>Calcul de l’horizon</th><th>Portée attendue</th><th>Durée</th></tr></thead><tbody>
      ${plan().map(fl=>{const h=fl*100,d=horizon(h);return `<tr><td>FL${fl}</td><td class="mono">1,23 × (√${fr(h)} + √${H_STATION}) = ${fr(d,1)} NM</td><td class="mono">${fr(attendu(fl),1)} NM${d>DME_MAX?' <span class="c">(limite DME 199)</span>':''}</td><td class="mono">${fr(2*branche(fl)/S.vitesse*60+10)} min</td></tr>`;}).join('')}
    </tbody></table></div>
    <h3>Check-list sécurité</h3>
    <div class="g-checks">${CHECK.map(c=>`<label><input type="checkbox" data-c="${c[0]}" ${S.checks[c[0]]?'checked':''}> ${c[1]}</label>`).join('')}</div>
    ${nav('Décoller',all)}
  </div><aside class="panel g-side"><h3>D’où vient 1,23 ?</h3><p>La distance à l’horizon géométrique vaut √(2 × R × h), avec R le rayon de la Terre. Les ondes radio se courbent un peu dans l’atmosphère, ce qu’on compte en prenant un rayon terrestre « 4/3 » plus grand. Avec h en pieds et d en NM, tout cela donne ce coefficient de 1,23.</p></aside></div>`;
  root.querySelectorAll('[data-c]').forEach(b=>b.addEventListener('change',()=>{S.checks[b.dataset.c]=b.checked;briefing();}));
  bindNav();
}

/* 4. Vol et mesures */
function mesurer(){
  return plan().map(fl=>{const r=rng(fl*7919+11);r();const exp=attendu(fl);
    const loss=Math.min(exp*(1-0.04*r())-(exp>=DME_MAX?r()*2:0),DME_MAX-r()*1.5);
    const h=fl*100/6076.12, ds=5, slant=Math.sqrt(ds*ds+h*h);
    return {fl,exp,loss,h,slant,ecart:slant-ds};});
}
function chartSvg(series,opt){
  const W=640,H=240,L=48,R=14,Tp=14,B=34;
  const xmax=opt.xmax,ymax=opt.ymax;const X=x=>L+x/xmax*(W-L-R), Y=y=>Tp+(1-y/ymax)*(H-Tp-B);
  let g='';
  for(let i=0;i<=4;i++){const yv=ymax*i/4;g+=`<line x1="${L}" x2="${W-R}" y1="${Y(yv)}" y2="${Y(yv)}" class="gl"/><text x="${L-6}" y="${Y(yv)+4}" text-anchor="end">${fr(yv)}</text>`;}
  for(let i=0;i<=opt.xt;i++){const xv=xmax*i/opt.xt;g+=`<text x="${X(xv)}" y="${H-B+16}" text-anchor="middle">${fr(xv)}</text>`;}
  g+=`<text x="${(L+W-R)/2}" y="${H-4}" text-anchor="middle">${opt.xl}</text><text x="12" y="${Tp+4}" text-anchor="start">${opt.yl}</text>`;
  series.forEach(s=>{if(s.line)g+=`<path d="${s.pts.map((p,i)=>(i?'L':'M')+X(p[0]).toFixed(1)+' '+Y(p[1]).toFixed(1)).join(' ')}" fill="none" class="${s.cls}" ${s.dash?'stroke-dasharray="5 4"':''}/>`;
    if(s.dots)s.pts.forEach(p=>{g+=`<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="5" class="${s.cls}d"/>`;});});
  return `<svg viewBox="0 0 ${W} ${H}" class="g-chart" role="img" aria-label="${opt.aria}">${g}</svg>`;
}
function vol(){
  if(!S.mesures)S.mesures=mesurer();
  const M=S.mesures;
  root.innerHTML=`<div class="g-main">
    <h2>Vol et mesures</h2>
    <p>L’avion monte à chaque palier, puis s’éloigne de la balise en ligne droite jusqu’à perdre le signal. La courbe montre la distance lue par le DME au fil de la branche ; elle s’arrête quand le DME décroche.</p>
    <div class="g-flight panel"><div class="g-log mono" id="g-log" aria-live="polite"></div><div id="g-chart"></div></div>
    <div class="g-run"><button type="button" class="btn primary" id="g-play">Lancer l’enregistrement</button><span class="c" id="g-state">${M.length} palier(s) à enregistrer</span></div>
    <div id="g-sum" hidden></div>
    ${nav('Analyser les résultats',false)}
  </div>`;
  bindNav();
  const log=root.querySelector('#g-log'),ch=root.querySelector('#g-chart'),btn=root.querySelector('#g-play');
  const finish=()=>{
    root.querySelector('#g-sum').hidden=false;
    root.querySelector('#g-sum').innerHTML=`<div class="tbl-scroll"><table class="g-table"><thead><tr><th>Palier</th><th>Attendu</th><th>Décrochage mesuré</th></tr></thead><tbody>${M.map(m=>`<tr><td>FL${m.fl}</td><td class="mono">${fr(m.exp,1)} NM</td><td class="mono">${fr(m.loss,1)} NM</td></tr>`).join('')}</tbody></table></div>`;
    root.querySelector('[data-next]').disabled=false;btn.disabled=true;root.querySelector('#g-state').textContent='Enregistrement terminé';
  };
  const drawAll=(k,frac)=>{
    const xmax=Math.max(...M.map(m=>m.loss))*1.1;
    const series=M.slice(0,k+1).map((m,i)=>{const end=i<k?m.loss:m.loss*frac;const pts=[];for(let d=0;d<=end;d+=Math.max(1,end/60))pts.push([d,Math.sqrt(d*d+m.h*m.h)]);pts.push([end,Math.sqrt(end*end+m.h*m.h)]);return {pts,line:true,cls:'s'+(i%5)};});
    ch.innerHTML=chartSvg(series,{xmax,ymax:Math.ceil(xmax/50)*50,xt:4,xl:'distance au sol depuis la balise (NM)',yl:'lecture DME (NM)',aria:'Lecture DME au cours de chaque branche'})+
      `<div class="g-leg">${M.slice(0,k+1).map((m,i)=>`<span><i class="k${i%5}"></i>FL${m.fl}</span>`).join('')}</div>`;
  };
  btn.addEventListener('click',()=>{
    btn.disabled=true;log.innerHTML='';
    const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
    if(reduce){M.forEach((m,i)=>{log.innerHTML+=`FL${m.fl} : signal perdu à ${fr(m.loss,1)} NM<br>`;});drawAll(M.length-1,1);finish();return;}
    let k=0,f=0,h0=10,mins=0;
    const tick=()=>{
      if(f===0){mins+=8;log.innerHTML+=`T+${fr(mins)} min · FL${M[k].fl} atteint, début de la branche<br>`;}
      f=Math.min(1,f+0.03);drawAll(k,f);
      if(f>=1){mins+=Math.round(M[k].loss/S.vitesse*60);log.innerHTML+=`T+${fr(mins)} min · <b>signal perdu à ${fr(M[k].loss,1)} NM</b>, retour vers la balise<br>`;k++;f=0;
        if(k>=M.length){log.innerHTML+=`Atterrissage. Les données sont dans l’enregistreur.`;finish();return;}}
      log.scrollTop=log.scrollHeight;setTimeout(tick,40);
    };tick();
  });
}

/* 5. Analyse */
const QUESTIONS=[
  {id:'q1',q:'Ta décision pour l’exigence E1 (au moins 150 NM au FL300) :',choix:['VALIDÉ : l’exigence est tenue','À REFAIRE : la mesure n’est pas exploitable ou pas conforme','INCOMPLET : le point de mesure nécessaire n’a pas été fait'],
   bonne:()=>{const m=S.mesures.find(x=>x.fl===300);return m?(m.loss>=150?0:1):2;},
   pourquoi:()=>{const m=S.mesures.find(x=>x.fl===300);return m?`Au FL300, le signal a tenu jusqu’à ${fr(m.loss,1)} NM.`:'Aucun palier n’a été fait au FL300 : on ne peut pas conclure. Un vrai essai devrait être refait.';}},
  {id:'q2',q:'Pourquoi le DME décroche-t-il plus tôt à basse altitude ?',choix:['La balise émet moins fort quand l’avion est bas','La rondeur de la Terre cache la balise : l’horizon radio est plus proche','L’air plus dense freine les ondes radio','Le DME consomme moins d’énergie à basse altitude'],bonne:()=>1,
   pourquoi:()=>'Les ondes du DME, en UHF, vont presque en ligne droite. Plus l’avion est haut, plus il « voit » loin derrière la courbure de la Terre.'},
  {id:'q3',q:'Au FL300, à 5 NM au sol de la balise, le DME affiche environ 7 NM. Pourquoi ?',choix:['Le DME est mal réglé','Le DME mesure la distance en ligne droite, qui inclut l’altitude de l’avion','L’avion vole en virage','La balise est mal placée'],bonne:()=>1,
   pourquoi:()=>'Près de la balise, la hauteur pèse beaucoup dans le triangle : √(5² + 4,9²) ≈ 7 NM. Loin de la balise, l’écart devient négligeable.'}
];
function analyse(){
  const M=S.mesures, xmax=Math.max(400,...M.map(m=>m.fl*100))/100;
  const theo=[];for(let fl=10;fl<=420;fl+=10)theo.push([fl,Math.min(horizon(fl*100),DME_MAX)]);
  const done=QUESTIONS.every(q=>S.reponses[q.id]!==undefined);
  root.innerHTML=`<div class="g-main">
    <h2>Analyse des résultats</h2>
    <p>On superpose les mesures (points) et la théorie (ligne) : portée en fonction de l’altitude. Un bon essai commence toujours par cette comparaison.</p>
    <div class="panel g-flight">${chartSvg([{pts:theo,line:true,cls:'th',dash:true},{pts:M.map(m=>[m.fl,m.loss]),dots:true,cls:'s0'}],{xmax:420,ymax:250,xt:6,xl:'niveau de vol (FL)',yl:'portée (NM)',aria:'Portée mesurée et théorique selon le niveau de vol'})}
      <div class="g-leg"><span><i class="kth"></i>Théorie : horizon radio, plafonné à 199 NM</span><span><i class="k0"></i>Mesures</span></div></div>
    <h3>Écart oblique près de la balise (exigence E2)</h3>
    <div class="tbl-scroll"><table class="g-table"><thead><tr><th>Palier</th><th>Hauteur</th><th>Distance sol</th><th>Lecture DME</th><th>Écart</th></tr></thead><tbody>
    ${M.map(m=>`<tr><td>FL${m.fl}</td><td class="mono">${fr(m.h,2)} NM</td><td class="mono">5,00 NM</td><td class="mono">√(5² + ${fr(m.h,2)}²) = ${fr(m.slant,2)} NM</td><td class="mono">${fr(m.ecart,2)} NM</td></tr>`).join('')}</tbody></table></div>
    <h3>Tes conclusions</h3>
    <div class="g-qs">${QUESTIONS.map(q=>{const a=S.reponses[q.id],b=q.bonne();return `<div class="panel g-q"><p class="q">${q.q}</p><div class="opts">${q.choix.map((c,k)=>`<button type="button" class="opt ${a!==undefined?(k===b?'right':(k===a?'wrong':'')):''}" data-q="${q.id}" data-k="${k}" ${a!==undefined?'disabled':''}>${c}</button>`).join('')}</div>${a!==undefined?`<p class="why">${a===b?'Exact. ':'Pas tout à fait. '}${q.pourquoi()}</p>`:''}</div>`;}).join('')}</div>
    ${nav('Rédiger le débriefing',done)}
  </div>`;
  root.querySelectorAll('[data-q]').forEach(b=>b.addEventListener('click',()=>{S.reponses[b.dataset.q]=+b.dataset.k;analyse();}));
  bindNav();
}

/* 6. Débriefing */
function debrief(){
  const M=S.mesures, m3=M.find(x=>x.fl===300), A=AVIONS[S.avion];
  const e1=m3?(m3.loss>=150?'<b class="ok">Conforme</b>':'<b class="bad">Non conforme</b>'):'<b class="bad">Non démontrée</b>';
  const score=QUESTIONS.filter(q=>S.reponses[q.id]===q.bonne()).length;
  try{if(window.CPS&&window.CPS.progress){window.CPS.progress.markIn('essais','exos','dme-'+S.avion);window.CPS.progress.mark('essais','read',true);}}catch(e){}
  root.innerHTML=`<div class="g-grid"><div class="g-main">
    <h2>Débriefing</h2>
    <div class="panel g-report mono">
      <div><span>RAPPORT D’ESSAI</span><span>DME de bord · vol n° 1</span></div>
      <div><span>Avion</span><span>${A.n}, ${fr(S.masse,1)} t, ${fr(S.vitesse)} kt</span></div>
      <div><span>Paliers réalisés</span><span>${M.map(m=>'FL'+m.fl).join(', ')}</span></div>
      <div><span>E1 · portée ≥ 150 NM au FL300</span><span>${e1}${m3?` (${fr(m3.loss,1)} NM)`:''}</span></div>
      <div><span>E2 · écart oblique</span><span><b class="ok">Mesuré et expliqué</b> : jusqu’à ${fr(Math.max(...M.map(m=>m.ecart)),2)} NM à 5 NM de la balise</span></div>
      <div><span>Conclusions de l’ingénieur</span><span>${score} / ${QUESTIONS.length} justes</span></div>
    </div>
    <p>${m3?(m3.loss>=150?'Le DME peut être déclaré conforme sur ce point. La portée suit la théorie de l’horizon radio, avec quelques pourcents de marge : c’est le comportement attendu.':'La portée est insuffisante : il faudrait chercher la cause (antenne, câblage, réglage) puis refaire un vol.'):'Sans mesure au FL300, l’exigence E1 n’est pas démontrée : il faut planifier un nouveau vol, par exemple avec un avion plus léger ou un autre palier.'}</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px"><button type="button" class="btn" id="g-dl">Télécharger le rapport</button><button type="button" class="btn" id="g-csv">Données de vol (CSV)</button><button type="button" class="btn" id="g-pdf">Rapport (PDF)</button><button type="button" class="btn" id="g-again">Refaire avec d’autres paramètres</button><a class="btn primary" href="orientation.html#essais-vol">Découvrir le métier</a></div>
  </div><aside class="panel g-side"><h3>Ce que tu viens de faire</h3><p>C’est le cœur du métier d’ingénieur d’essais en vol :</p><ul><li>traduire une exigence en points de mesure ;</li><li>composer avec les limites de l’avion et du temps de vol ;</li><li>préparer la sécurité avec l’équipage et le contrôle ;</li><li>comparer mesures et théorie, puis conclure par écrit.</li></ul></aside></div>`;
  root.querySelector('#g-again').addEventListener('click',()=>{S.reponses={};S.mesures=null;S.max=1;go(1);});
  const X=window.CPS_EXPORT;
  root.querySelector('#g-csv').addEventListener('click',()=>X&&X.csv(`donnees-essai-dme-${S.avion}.csv`,['palier (FL)','portée attendue (NM)','décrochage mesuré (NM)','hauteur (NM)','distance sol près balise (NM)','lecture DME (NM)','écart oblique (NM)'],
    M.map(m=>[m.fl,m.exp,m.loss,m.h,5,m.slant,m.ecart])));
  root.querySelector('#g-pdf').addEventListener('click',()=>{if(!X)return;const theo=[];for(let fl=10;fl<=420;fl+=10)theo.push([fl,Math.min(horizon(fl*100),DME_MAX)]);
    X.pdf('Rapport d’essai · DME de bord',[{h:'Synthèse',kv:[...root.querySelectorAll('.g-report > div')].map(d=>[...d.children].map(c=>c.textContent.trim()))},
      {h:'Conclusion',p:root.querySelector('.g-main > p').textContent},
      {h:'Portée mesurée et théorique',svg:chartSvg([{pts:theo,line:true,cls:'th',dash:true},{pts:M.map(m=>[m.fl,m.loss]),dots:true,cls:'s0'}],{xmax:420,ymax:250,xt:6,xl:'niveau de vol (FL)',yl:'portée (NM)',aria:'Portée'})},
      {h:'Mesures',table:{entetes:['Palier','Attendu (NM)','Décrochage (NM)','Lecture DME à 5 NM sol','Écart (NM)'],lignes:M.map(m=>['FL'+m.fl,m.exp,m.loss,m.slant,m.ecart])}}]);});
  root.querySelector('#g-dl').addEventListener('click',()=>{const lines=[...root.querySelectorAll('.g-report > div')].map(d=>[...d.children].map(c=>c.textContent.trim()).join(' : '));
    window.CPS_downloadReport&&window.CPS_downloadReport('rapport-essai-dme.txt',lines.join('\n')+'\n\n'+root.querySelector('.g-main > p').textContent+'\n\nCPS Aero · simulation pédagogique, mesures fictives.');});
}

render();
window.CPS_ESSAIS={S,horizon,attendu,plafond,dureeTotale,mesurer};
};
})();
