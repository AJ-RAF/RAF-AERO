/* CPSAero — export des données de vol (grade CDB).
   CPS_EXPORT.csv(nom, entetes, lignes) : fichier CSV lisible par Excel en français (séparateur « ; », virgule décimale, BOM UTF-8).
   CPS_EXPORT.pdf(titre, sections) : ouvre la boîte d'impression du navigateur sur un rapport mis en page ;
   choisir « Enregistrer au format PDF ». sections = [{h, kv:[[clé, valeur]…]} | {h, p} | {h, table:{entetes, lignes}}]. */
(function(){
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const cell=v=>{if(v===null||v===undefined)return '';if(typeof v==='number')return isFinite(v)?String(+v.toFixed(6)).replace('.',','):'';
  const s=String(v);return /[;"\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;};
function download(name,text,type){
  try{const blob=new Blob([text],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;
    document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);return true;}catch(e){return false;}
}
function csvText(entetes,lignes){return '﻿'+[entetes,...lignes].map(l=>l.map(cell).join(';')).join('\r\n')+'\r\n';}
function csv(nom,entetes,lignes){return download(nom,csvText(entetes,lignes),'text/csv;charset=utf-8');}
function reportHtml(titre,sections){
  const date=new Date().toLocaleString('fr-FR',{dateStyle:'long',timeStyle:'short'});
  const body=sections.map(s=>`<section><h2>${esc(s.h)}</h2>${
    s.kv?`<table class="kv">${s.kv.map(r=>`<tr><th>${esc(r[0])}</th><td>${esc(r[1])}</td></tr>`).join('')}</table>`:
    s.table?`<table class="t"><thead><tr>${s.table.entetes.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${s.table.lignes.map(l=>`<tr>${l.map(c=>`<td>${esc(typeof c==='number'?String(+c.toFixed(3)).replace('.',','):c)}</td>`).join('')}</tr>`).join('')}</tbody></table>`:
    s.svg?`<div class="svg">${s.svg}</div>`:
    `<p>${esc(s.p)}</p>`}</section>`).join('');
  return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>${esc(titre)}</title><style>
    @page{size:A4;margin:16mm}body{font:11pt/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#0b1120;margin:0}
    header{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:2px solid #06b6d4;padding-bottom:8px;margin-bottom:14px}
    header b{font-size:18pt}header span{font-size:9pt;color:#475569}h2{font-size:12pt;margin:16px 0 6px;color:#0e7490}
    table{border-collapse:collapse;width:100%;font-size:9.5pt}th,td{border:1px solid #cbd5e1;padding:3px 6px;text-align:left;vertical-align:top}
    .kv th{width:42%;background:#f1f5f9;font-weight:600}.t thead th{background:#e2e8f0}.t td{font-variant-numeric:tabular-nums}
    .svg svg{width:100%;height:auto}.svg text{fill:#0b1120}footer{margin-top:18px;font-size:8.5pt;color:#64748b;border-top:1px solid #cbd5e1;padding-top:6px}
    section{break-inside:avoid}</style></head><body><header><b>${esc(titre)}</b><span>CPSAero · ${esc(date)}</span></header>${body}
    <footer>CPSAero · simulation pédagogique : modèle simplifié et valeurs fictives ou approchées, à ne pas utiliser pour une décision réelle.</footer></body></html>`;
}
function pdf(titre,sections){
  const html=reportHtml(titre,sections);
  const f=document.createElement('iframe');f.setAttribute('aria-hidden','true');f.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0';
  document.body.appendChild(f);
  const go=()=>{try{f.contentWindow.focus();f.contentWindow.print();}catch(e){download(titre.replace(/[^\w-]+/g,'-').toLowerCase()+'.html',html,'text/html;charset=utf-8');}
    setTimeout(()=>f.remove(),60000);};
  f.onload=()=>setTimeout(go,150);
  f.srcdoc=html;
}
window.CPS_EXPORT={csv,csvText,pdf,reportHtml,download};
})();
