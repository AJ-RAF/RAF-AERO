/* CPSAero — calculateurs de dimensionnement (grade CPL).
   Ce fichier est servi par le serveur uniquement aux grades CPL, CDB et administrateur quand les grades sont ouverts.
   Il ne s'exécute pas seul : calc-lab.js l'appelle avec ses fonctions utilitaires. */
window.CPS_CALC_AVANCE=function(h){
const {fr,nx,isa,G,KT,FT,NM,sv,tx}=h;
/* CAS -> TAS en subsonique (formule de Saint-Venant, air gaz parfait γ = 1,4) */
const A0=661.4788; // kt, vitesse du son au niveau de la mer ISA
function tasCalc(v){const a=isa(v.h),T=v.oat+273.15,qc=Math.pow(1+0.2*Math.pow(v.ias/A0,2),3.5)-1;
  const M=Math.sqrt(5*(Math.pow(qc/a.delta+1,2/7)-1)),as=A0*Math.sqrt(T/288.15),sg=a.delta/(T/288.15);
  return {delta:a.delta,qc,M,T,a:as,tas:M*as,approx:v.ias*Math.sqrt(1/sg),isaC:a.T-273.15};}


const formules=[
{id:'tas',titre:'Vitesse propre (TAS)',domaine:'Mécanique du vol',
 formule:'V<sub>p</sub> = M × a     avec  M tiré de la vitesse corrigée V<sub>c</sub> et de la pression p',
 idee:'L’anémomètre ne mesure pas une vitesse : il mesure une pression, la surpression de l’air qui frappe la sonde Pitot. En altitude, l’air est moins dense : à aiguille égale, l’avion va en réalité beaucoup plus vite par rapport à l’air. Le calcul passe par trois étapes : la surpression mesurée, le Mach qu’elle représente à cette pression, puis la vitesse du son à la température réelle.',
 vars:[['V<sub>p</sub>','Vitesse propre (TAS) : vitesse réelle de l’avion dans l’air','kt'],['V<sub>c</sub>','Vitesse corrigée (CAS) : la vitesse indiquée IAS corrigée des erreurs d’installation de la sonde. On les confond ici.','kt'],
       ['q<sub>c</sub>','Surpression d’impact mesurée par la sonde Pitot','Pa'],
       ['p / p<sub>0</sub>','Pression relative à l’altitude de vol (atmosphère standard), p<sub>0</sub> = 1 013,25 hPa','–'],
       ['a<sub>0</sub>','Vitesse du son au niveau de la mer en atmosphère standard','661,47 kt'],
       ['T','Température réelle de l’air (OAT + 273,15)','K']],
 exemple:{contexte:'Un A320 en croisière à 35 000 ft lit 270 kt ; la température extérieure est de −54 °C (atmosphère standard).',
   etapes:['p / p<sub>0</sub> = 0,235 à 35 000 ft','q<sub>c</sub> / p<sub>0</sub> = (1 + 0,2 × (270 / 661,47)²)<sup>3,5</sup> − 1 = 0,122','M = √(5 × ((0,122 / 0,235 + 1)<sup>2/7</sup> − 1)) = 0,795','a = 661,47 × √(219,15 / 288,15) = 576,9 kt','V<sub>p</sub> = 0,795 × 576,9 ≈ 459 kt'],
   resultat:'459 kt, soit 850 km/h dans l’air, à Mach 0,80'},
 note:'Hypothèses : vol subsonique, air gaz parfait (γ = 1,4), altitude pression lue en atmosphère standard, CAS ≈ IAS. La formule simplifiée V<sub>p</sub> ≈ V<sub>i</sub> √(ρ<sub>0</sub>/ρ) oublie que l’air se comprime dans la sonde : elle est affichée en comparaison sous le résultat. Elle convient à basse vitesse et basse altitude, mais surestime nettement la TAS en croisière (environ 27 kt de trop dans l’exemple).',
 inputs:[{id:'ias',label:'Vitesse corrigée V<sub>c</sub>',u:'kt',v:270,min:40,max:600,step:1},{id:'h',label:'Altitude pression',u:'ft',v:35000,min:0,max:50000,step:500},{id:'oat',label:'Température extérieure OAT',u:'°C',v:-54,min:-80,max:50,step:1}],
 calc(v){const r=tasCalc(v);if(r.M>=1)return {err:'Avec ces valeurs, l’avion serait supersonique (Mach '+fr(r.M,2)+') : cette formule ne vaut qu’en subsonique (il faudrait la formule de Rayleigh, hors programme ici).'};
   return {etapes:[`p / p<sub>0</sub> = ${fr(r.delta,4)} à ${fr(v.h,0)} ft`,`q<sub>c</sub> / p<sub>0</sub> = (1 + 0,2 × (${fr(v.ias,0)} / 661,47)²)<sup>3,5</sup> − 1 = ${fr(r.qc,4)}`,`M = √(5 × ((${fr(r.qc,4)} / ${fr(r.delta,4)} + 1)<sup>2/7</sup> − 1)) = ${fr(r.M,3)}`,`a = 661,47 × √(${fr(r.T,2)} / 288,15) = ${fr(r.a,1)} kt`,`V<sub>p</sub> = ${fr(r.M,3)} × ${fr(r.a,1)} = ${fr(r.tas,0)} kt`],
     res:`${fr(r.tas,0)} kt`,sub:`${fr(r.tas*KT*3.6,0)} km/h · Mach ${fr(r.M,2)} · formule simplifiée √(ρ₀/ρ) : ${fr(r.approx,0)} kt (${r.approx-r.tas>=0?'+':''}${fr(r.approx-r.tas,0)} kt) · en atmosphère standard il ferait ${fr(r.isaC,0)} °C ici`,raw:{ias:v.ias,tas:r.tas,M:r.M}};},
 jumeau:(v,r)=>({mach:Math.min(2.2,+r.raw.M.toFixed(2)),alt:v.h,thr:85})},

{id:'mach',titre:'Nombre de Mach',domaine:'Mécanique du vol',
 formule:'M = V<sub>p</sub> / a     avec  a = √( γ × r × T )',
 idee:'Le Mach compare la vitesse de l’avion à la vitesse du son autour de lui. Or la vitesse du son ne dépend que de la température : plus il fait froid, plus elle est faible. C’est pour ça qu’on règle ici la température, pas l’altitude.',
 vars:[['M','Nombre de Mach : 1 = vitesse du son','–'],['V<sub>p</sub>','Vitesse propre de l’avion','m/s'],['a','Vitesse du son locale','m/s'],
       ['γ','Rapport des capacités thermiques de l’air','1,4'],['r','Constante de l’air','287 J/(kg·K)'],['T','Température réelle de l’air (OAT + 273,15)','K']],
 exemple:{contexte:'Le même A320 vole à 459 kt de vitesse propre, dans un air à −54 °C.',
   etapes:['T = −54 + 273,15 = 219,2 K','a = √(1,4 × 287 × 219,2) = 296,7 m/s','V<sub>p</sub> = 459 × 0,5144 = 236,1 m/s','M = 236,1 / 296,7 = 0,80'],
   resultat:'Mach 0,80 : l’ordre de grandeur de la croisière d’un A320'},
 inputs:[{id:'tas',label:'Vitesse propre V<sub>p</sub>',u:'kt',v:459,min:50,max:1500,step:1},{id:'oat',label:'Température extérieure OAT',u:'°C',v:-54,min:-70,max:50,step:1}],
 calc(v){const T=v.oat+273.15,s=Math.sqrt(1.4*287.05*T),vp=v.tas*KT,M=vp/s;
   return {etapes:[`T = ${fr(v.oat,0)} + 273,15 = ${fr(T,1)} K`,`a = √(1,4 × 287 × ${fr(T,1)}) = ${fr(s,1)} m/s`,`V<sub>p</sub> = ${fr(v.tas,0)} × 0,5144 = ${fr(vp,1)} m/s`,`M = ${fr(vp,1)} / ${fr(s,1)} = ${fr(M,2)}`],
     res:`Mach ${fr(M,2)}`,sub:M>=1.2?'supersonique':M>=0.8?'transsonique : des zones supersoniques apparaissent sur l’avion':'subsonique',raw:{M}};},
 // altitude standard correspondant à la température saisie (ISA), pour le jumeau numérique
 jumeau:(v,r)=>{const T=v.oat+273.15,h=T>=216.65?Math.max(0,(288.15-T)/0.0065/FT):36089;return {mach:Math.min(2.2,+r.raw.M.toFixed(2)),alt:Math.min(55000,Math.round(h/500)*500),thr:r.raw.M>1?100:85,pc:r.raw.M>1?1:0};}},

{id:'charge',titre:'Facteur de charge en virage',domaine:'Mécanique du vol',
 formule:'n = 1 / cos φ',
 idee:'En virage stabilisé, l’aile doit à la fois porter le poids et tirer l’avion vers l’intérieur du virage. Plus on incline, plus elle doit porter : le pilote se sent plus lourd.',
 vars:[['n','Facteur de charge : combien de fois son poids on ressent (« g »)','g'],['φ','Inclinaison de l’avion (angle de roulis)','°'],
       ['cos φ','Part de la portance qui sert encore à porter le poids','–']],
 exemple:{contexte:'Un Rafale vire à altitude constante, incliné à 80°.',
   etapes:['cos 80° = 0,174','n = 1 / 0,174 = 5,76'],resultat:'5,8 g : le pilote « pèse » 5,8 fois son poids'},
 inputs:[{id:'phi',label:'Inclinaison φ',u:'°',v:60,min:0,max:85,step:1}],
 calc(v){const c=Math.cos(v.phi*Math.PI/180),n=1/c;
   return {etapes:[`cos ${fr(v.phi,0)}° = ${fr(c,3)}`,`n = 1 / ${fr(c,3)} = ${fr(n,2)}`],
     res:`${fr(n,2)} g`,sub:`un pilote de 75 kg « pèse » ${fr(75*n,0)} kg`,raw:{phi:v.phi,n}};}},

{id:'rayon',titre:'Rayon de virage',domaine:'Mécanique du vol',
 formule:'R = V² / ( g × tan φ )',
 idee:'Plus on va vite, plus le virage est large ; plus on incline, plus il est serré. La vitesse compte au carré : doubler la vitesse multiplie le rayon par quatre.',
 vars:[['R','Rayon du cercle décrit par l’avion','m'],['V','Vitesse propre','m/s (1 kt = 0,5144 m/s)'],['g','Accélération de la pesanteur','9,81 m/s²'],['φ','Inclinaison','°']],
 exemple:{contexte:'Un A320 en approche vire à 250 kt, incliné à 25°.',
   etapes:['V = 250 × 0,5144 = 128,6 m/s','V² = 16 540 m²/s²','tan 25° = 0,466','R = 16 540 / (9,81 × 0,466) ≈ 3 617 m'],resultat:'3,6 km de rayon, soit un demi-tour de 7,2 km de large'},
 inputs:[{id:'v',label:'Vitesse',u:'kt',v:250,min:40,max:1200,step:1},{id:'phi',label:'Inclinaison φ',u:'°',v:25,min:1,max:85,step:1}],
 calc(v){const V=v.v*KT,t=Math.tan(v.phi*Math.PI/180),R=V*V/(G*t);
   return {etapes:[`V = ${fr(v.v,0)} × 0,5144 = ${fr(V,1)} m/s`,`V² = ${fr(V*V,0)} m²/s²`,`tan ${fr(v.phi,0)}° = ${fr(t,3)}`,`R = ${fr(V*V,0)} / (9,81 × ${fr(t,3)}) = ${fr(R,0)} m`],
     res:`${fr(R/1000,2)} km`,sub:`demi-tour de ${fr(2*R/1000,1)} km de large`,raw:{R}};}},

{id:'poussee',titre:'Poussée d’un réacteur',domaine:'Propulsion',lien:['turboreacteur.html','Cours turboréacteur'],
 formule:'F = ṁ × ( V<sub>9</sub> − V<sub>0</sub> )',
 idee:'Un réacteur pousse parce qu’il accélère de l’air vers l’arrière. La poussée dépend de la masse d’air traitée chaque seconde et du gain de vitesse qu’on lui donne.',
 vars:[['F','Poussée','N'],['ṁ','Débit d’air : kg d’air qui traversent le moteur chaque seconde','kg/s'],['V<sub>9</sub>','Vitesse du jet en sortie de tuyère','m/s'],['V<sub>0</sub>','Vitesse de l’avion (l’air arrive à cette vitesse)','m/s']],
 exemple:{contexte:'Un Atar 9K50 de Mirage F1 au point fixe, sans post-combustion.',
   etapes:['ṁ = 72 kg/s, V<sub>9</sub> = 650 m/s, V<sub>0</sub> = 0','F = 72 × (650 − 0) = 46 800 N'],resultat:'46,8 kN, de quoi soulever 4,8 t'},
 note:'Formule simplifiée : elle suppose une tuyère adaptée (pression du jet p<sub>9</sub> égale à la pression ambiante p<sub>0</sub>) et néglige la masse de carburant ajoutée. La forme complète est F = (ṁ + ṁ<sub>f</sub>) V<sub>9</sub> − ṁ V<sub>0</sub> + (p<sub>9</sub> − p<sub>0</sub>) A<sub>9</sub>, où le dernier terme, le terme de pression, compte dès que la tuyère n’est pas adaptée (A<sub>9</sub> : section de sortie).',
 inputs:[{id:'m',label:'Débit d’air ṁ',u:'kg/s',v:72,min:1,max:1000,step:1},{id:'v9',label:'Vitesse du jet V<sub>9</sub>',u:'m/s',v:650,min:10,max:2000,step:5},{id:'v0',label:'Vitesse avion V<sub>0</sub>',u:'m/s',v:0,min:0,max:800,step:5}],
 calc(v){const F=v.m*(v.v9-v.v0);if(F<=0)return {err:'Le jet doit sortir plus vite que l’avion n’avance, sinon le moteur ne pousse plus.'};
   return {etapes:[`gain de vitesse = ${fr(v.v9,0)} − ${fr(v.v0,0)} = ${fr(v.v9-v.v0,0)} m/s`,`F = ${fr(v.m,0)} × ${fr(v.v9-v.v0,0)} = ${fr(F,0)} N`],
     res:`${fr(F/1000,1)} kN`,sub:`de quoi soulever ${fr(F/G/1000,1)} t`,raw:{F}};}}
];
const viz={
  tas(r){const W=300,H=190,cx=150,cy=150,R=118,max=700,ang=v=>Math.PI*(1-Math.min(v,max)/max);
    const P=(v,rr)=>[cx+rr*Math.cos(ang(v)),cy-rr*Math.sin(ang(v))];let g=`<path d="M${cx-R},${cy} A${R},${R} 0 0 1 ${cx+R},${cy}" class="v-arc"/>`;
    for(let v=0;v<=max;v+=100){const [a1,b1]=P(v,R),[a2,b2]=P(v,R-10),[a3,b3]=P(v,R-24);g+=`<line x1="${a1}" y1="${b1}" x2="${a2}" y2="${b2}" class="v-tick"/>${tx(a3,b3+4,v,'v-dim')}`;}
    const n=(v,cls)=>{const [a,b]=P(v,R-30);return `<line x1="${cx}" y1="${cy}" x2="${a}" y2="${b}" class="${cls}"/>`;};
    g+=n(r.ias,'v-ni')+n(r.tas,'v-nt')+`<circle cx="${cx}" cy="${cy}" r="6" class="v-dot"/>`+tx(cx,cy+28,'IAS '+fr(r.ias,0)+' kt  ·  TAS '+fr(r.tas,0)+' kt','v-dim');
    return sv(W,H,g,'Jauge comparant vitesse indiquée et vitesse propre');},
  mach(r){const W=560,H=80,L=20,max=2.5,X=m=>L+Math.min(m,max)/max*(W-2*L);
    return sv(W,H,`<rect x="${X(0)}" y="28" width="${X(0.8)-X(0)}" height="14" class="v-z1"/><rect x="${X(0.8)}" y="28" width="${X(1.2)-X(0.8)}" height="14" class="v-z2"/><rect x="${X(1.2)}" y="28" width="${X(2.5)-X(1.2)}" height="14" class="v-z3"/>
      ${tx((X(0)+X(0.8))/2,20,'subsonique','v-dim')}${tx((X(0.8)+X(1.2))/2,20,'transsonique','v-dim')}${tx((X(1.2)+X(2.5))/2,20,'supersonique','v-dim')}
      ${[0,0.5,1,1.5,2,2.5].map(m=>tx(X(m),62,fr(m,1),'v-dim')).join('')}<path d="M${X(r.M)},44 l-7,12 h14 z" class="v-mk"/>`,'Position du Mach sur l’échelle de vitesse');},
  charge(r){const W=420,H=200,L=40,B=30,T=12,R=12,X=p=>L+p/85*(W-L-R),Y=n=>T+(1-Math.min(n,12)/12)*(H-T-B);
    let d='';for(let p=0;p<=85;p+=1){const n=1/Math.cos(p*Math.PI/180);d+=(p?'L':'M')+X(p).toFixed(1)+' '+Y(n).toFixed(1)+' ';}
    let g=[0,3,6,9,12].map(n=>`<line x1="${L}" x2="${W-R}" y1="${Y(n)}" y2="${Y(n)}" class="v-grid"/>${tx(L-6,Y(n)+4,n+' g','v-dim','end')}`).join('');
    g+=[0,20,40,60,80].map(p=>tx(X(p),H-10,p+'°','v-dim')).join('');
    g+=`<path d="${d}" class="v-curve"/><circle cx="${X(r.phi)}" cy="${Y(r.n)}" r="6" class="v-pt"/>`;
    return sv(W,H,g,'Facteur de charge selon l’inclinaison');},
  rayon(r){const W=320,H=200,cx=W/2,cy=H/2,km=r.R/1000,nice=[0.5,1,2,5,10,20,50,100,200].find(s=>s>=km*0.6)||km,k=70/km;
    return sv(W,H,`<circle cx="${cx}" cy="${cy}" r="70" class="v-circ"/><line x1="${cx}" y1="${cy}" x2="${cx+70}" y2="${cy}" class="v-la"/><circle cx="${cx}" cy="${cy}" r="3" class="v-dot"/>
      <path d="M${cx},${cy-70} l-9,-4 l0,8 z" class="v-mk"/>${tx(cx+35,cy-6,'R = '+fr(km,2)+' km','v-ta')}
      <line x1="20" y1="${H-16}" x2="${20+nice*k}" y2="${H-16}" class="v-lc"/>${tx(20,H-24,'échelle : '+fr(nice,nice<1?1:0)+' km','v-dim','start')}`,'Cercle de virage vu de dessus');},
  poussee(r){const refs=[['Ton calcul',r.F/1000,'v-c'],['Atar 9K50 sec',49.2,'v-r'],['M88 sec',50,'v-r'],['M88 avec PC',75,'v-r'],['CFM56-5B (max)',147,'v-r']];
    const W=560,L=130,max=Math.max(160,r.F/1000*1.1),bw=W-L-60;
    return sv(W,refs.length*28+10,refs.map((x,i)=>`${tx(L-8,i*28+22,x[0],'v-dim','end')}<rect x="${L}" y="${i*28+10}" width="${Math.max(2,x[1]/max*bw)}" height="16" rx="3" class="${x[2]}"/>${tx(L+Math.max(2,x[1]/max*bw)+6,i*28+22,fr(x[1],1)+' kN','v-dim','start')}`).join(''),'Comparaison de poussée avec des moteurs réels');}
};
const tex={
tas:{main:'\\vv{V_p} = \\vv{M}\\,a \\qquad a = \\kk{a_0}\\sqrt{\\dfrac{\\vv{T}}{T_0}} \\qquad \\vv{M} = \\sqrt{5\\left[\\left(\\dfrac{q_c}{p}+1\\right)^{2/7}-1\\right]} \\qquad \\dfrac{q_c}{p_0} = \\left(1+0{,}2\\left(\\dfrac{\\vv{V_c}}{\\kk{a_0}}\\right)^{2}\\right)^{3{,}5}-1',vars:['\\vv{V_p}','\\vv{V_c}','q_c','p/p_0','\\kk{a_0}','\\vv{T}'],
 steps(v){const r=tasCalc(v);if(r.M>=1)return null;return [
  `\\dfrac{p}{p_0} = ${nx(r.delta,4)} \\quad \\text{(altitude ${nx(v.h,0)} ft)}`,
  `\\dfrac{q_c}{p_0} = \\left(1+0{,}2\\left(\\dfrac{${nx(v.ias,0)}}{661{,}47}\\right)^{2}\\right)^{3{,}5}-1 = ${nx(r.qc,4)}`,
  `\\vv{M} = \\sqrt{5\\left[\\left(\\dfrac{${nx(r.qc,4)}}{${nx(r.delta,4)}}+1\\right)^{2/7}-1\\right]} = ${nx(r.M,3)}`,
  `a = 661{,}47\\sqrt{\\dfrac{${nx(r.T,2)}}{288{,}15}} = ${nx(r.a,1)}\\ \\text{kt}`,
  `\\vv{V_p} = ${nx(r.M,3)} \\times ${nx(r.a,1)} = \\rr{${nx(r.tas,0)}\\ \\text{kt}}`];}},
mach:{main:'\\vv{M} = \\dfrac{\\vv{V_p}}{a} \\qquad a = \\sqrt{\\kk{\\gamma}\\,\\kk{r}\\,\\vv{T}}',vars:['\\vv{M}','\\vv{V_p}','a','\\kk{\\gamma}','\\kk{r}','\\vv{T}'],
 steps(v){const T=v.oat+273.15,s=Math.sqrt(1.4*287.05*T),vp=v.tas*KT,M=vp/s;return [
  `\\vv{T} = ${nx(v.oat,0)}+273{,}15 = ${nx(T,1)}\\ \\text{K}`,
  `a = \\sqrt{1{,}4\\times 287\\times ${nx(T,1)}} = ${nx(s,1)}\\ \\text{m/s}`,
  `\\vv{V_p} = ${nx(v.tas,0)}\\times 0{,}5144 = ${nx(vp,1)}\\ \\text{m/s}`,
  `\\vv{M} = \\dfrac{${nx(vp,1)}}{${nx(s,1)}} = \\rr{${nx(M,2)}}`];}},
charge:{main:'\\vv{n} = \\dfrac{1}{\\cos\\vv{\\varphi}}',vars:['\\vv{n}','\\vv{\\varphi}','\\cos\\varphi'],
 steps(v){const c=Math.cos(v.phi*Math.PI/180);return [`\\cos ${nx(v.phi,0)}^\\circ = ${nx(c,3)}`,`\\vv{n} = \\dfrac{1}{${nx(c,3)}} = \\rr{${nx(1/c,2)}\\ g}`];}},
rayon:{main:'\\vv{R} = \\dfrac{\\vv{V}^{2}}{\\kk{g}\\,\\tan\\vv{\\varphi}}',vars:['\\vv{R}','\\vv{V}','\\kk{g}','\\vv{\\varphi}'],
 steps(v){const V=v.v*KT,t=Math.tan(v.phi*Math.PI/180),R=V*V/(G*t);return [
  `\\vv{V} = ${nx(v.v,0)}\\times 0{,}5144 = ${nx(V,1)}\\ \\text{m/s} \\qquad \\vv{V}^2 = ${nx(V*V,0)}`,
  `\\tan ${nx(v.phi,0)}^\\circ = ${nx(t,3)}`,
  `\\vv{R} = \\dfrac{${nx(V*V,0)}}{9{,}81\\times ${nx(t,3)}} = ${nx(R,0)}\\ \\text{m} = \\rr{${nx(R/1000,2)}\\ \\text{km}}`];}},
poussee:{main:'\\vv{F} = \\vv{\\dot m}\\,(\\vv{V_9}-\\vv{V_0})',vars:['\\vv{F}','\\vv{\\dot m}','\\vv{V_9}','\\vv{V_0}'],
 steps(v){const F=v.m*(v.v9-v.v0);if(F<=0)return null;return [`\\Delta V = ${nx(v.v9,0)}-${nx(v.v0,0)} = ${nx(v.v9-v.v0,0)}\\ \\text{m/s}`,`\\vv{F} = ${nx(v.m,0)}\\times ${nx(v.v9-v.v0,0)} = ${nx(F,0)}\\ \\text{N} = \\rr{${nx(F/1000,1)}\\ \\text{kN}}`];}}
};
return {formules,viz,tex,tasCalc};
};
