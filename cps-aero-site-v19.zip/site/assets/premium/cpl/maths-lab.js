/* CPSAero — laboratoires du chapitre Mathématiques.
   1. Fonction quadratique de deux variables f(x) = ½ xᵀAx : lignes de niveau, gradient, axes propres, nature du point critique.
   2. Système du second ordre amorti : réponse à un lâcher x(0) = 1, selon ω₀ et ζ. */
(function(){
const fr=(x,d=2)=>(Math.abs(x)<5e-13?0:x).toLocaleString('fr-FR',{minimumFractionDigits:d,maximumFractionDigits:d});
const css=v=>getComputedStyle(document.documentElement).getPropertyValue(v).trim()||'#888';
const slider=(k,l,a,b,s,v)=>`<label class="mlab-f"><span>${l}</span><input type="range" min="${a}" max="${b}" step="${s}" value="${v}" data-a="${k}" aria-label="${l}"><output data-o="${k}">${fr(v,s<1?1:0)}</output></label>`;

/* ---------- 1. Quadratique ---------- */
const Q=document.getElementById('quad-lab');
if(Q){
  const P={a:2,b:0.6,c:1};
  const PRE=[['Minimum (A définie positive)',2,0.6,1],['Maximum',-2,0.4,-1],['Point selle',1.5,0.3,-1],['Vallée plate (λ = 0)',1,1,1]];
  Q.innerHTML=`<div class="mlab-hd"><b>Laboratoire : f(x, y) = ½ (a x² + 2b xy + c y²)</b><span class="pill">Interactif</span></div>
    <div class="mlab-ctl">${slider('a','a',-3,3,0.1,P.a)}${slider('b','b (couplage)',-2,2,0.1,P.b)}${slider('c','c',-3,3,0.1,P.c)}</div>
    <div class="chips mlab-pre" role="group" aria-label="Préréglages">${PRE.map((p,i)=>`<button type="button" class="chip" data-p="${i}">${p[0]}</button>`).join('')}</div>
    <div class="q-wrap"><canvas width="560" height="380" aria-label="Carte des niveaux de f, gradient et axes propres"></canvas><div class="q-info" aria-live="polite"></div></div>
    <p class="mlab-note">Couleur : valeur de f (bleu = négatif, ambre = positif). Traits fins : lignes de niveau. Flèches : gradient A·x. Axes verts : vecteurs propres de A.</p>`;
  const cv=Q.querySelector('canvas'),ctx=cv.getContext('2d');
  function draw(){
    const {a,b,c}=P,W=cv.width,H=cv.height,S=46,ox=W/2,oy=H/2;
    const tr=a+c,det=a*c-b*b,disc=Math.sqrt(Math.max(0,(tr/2)**2-det)),l1=tr/2+disc,l2=tr/2-disc;
    // vecteur propre de l1
    let v1=Math.abs(b)>1e-9?[l1-c,b]:(a>=c?[1,0]:[0,1]);const n1=Math.hypot(...v1);v1=[v1[0]/n1,v1[1]/n1];const v2=[-v1[1],v1[0]];
    const f=(x,y)=>0.5*(a*x*x+2*b*x*y+c*y*y);
    const img=ctx.createImageData(W,H),cpos=hex(css('--amber')),cneg=hex(css('--cyan')),bg=hex(css('--solid'));
    let fmax=0;for(const [x,y] of [[-6,-4],[6,4],[-6,4],[6,-4],[6,0],[0,4]])fmax=Math.max(fmax,Math.abs(f(x,y)));fmax=fmax||1;
    const step=fmax/7;
    for(let j=0;j<H;j++)for(let i=0;i<W;i++){const x=(i-ox)/S,y=(oy-j)/S,v=f(x,y),t=Math.min(1,Math.abs(v)/fmax),col=v>=0?cpos:cneg;
      const band=Math.abs((v/step)-Math.round(v/step))<0.06*(1+Math.abs(v)/fmax)?0.85:0;
      const k=0.12+0.5*t,o=(j*W+i)*4;for(let q=0;q<3;q++)img.data[o+q]=Math.round(bg[q]*(1-k)+col[q]*k+(band?(255-bg[q])*0.15:0));img.data[o+3]=255;}
    ctx.putImageData(img,0,0);
    ctx.strokeStyle=css('--line2');ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(0,oy);ctx.lineTo(W,oy);ctx.moveTo(ox,0);ctx.lineTo(ox,H);ctx.stroke();
    // axes propres
    ctx.strokeStyle=css('--green');ctx.lineWidth=2.4;[v1,v2].forEach(v=>{ctx.beginPath();ctx.moveTo(ox-v[0]*300,oy+v[1]*300);ctx.lineTo(ox+v[0]*300,oy-v[1]*300);ctx.stroke();});
    // gradient
    ctx.strokeStyle=css('--fg');ctx.fillStyle=css('--fg');ctx.lineWidth=1.4;
    let gmax=0;const pts=[];for(let x=-5;x<=5;x+=1.25)for(let y=-3.5;y<=3.5;y+=1.25){const gx=a*x+b*y,gy=b*x+c*y;gmax=Math.max(gmax,Math.hypot(gx,gy));pts.push([x,y,gx,gy]);}
    pts.forEach(([x,y,gx,gy])=>{const L=Math.hypot(gx,gy);if(L<1e-9)return;const s=24*L/gmax,X=ox+x*S,Y=oy-y*S,ex=X+gx/L*s,ey=Y-gy/L*s;
      ctx.beginPath();ctx.moveTo(X,Y);ctx.lineTo(ex,ey);ctx.stroke();const an=Math.atan2(ey-Y,ex-X);ctx.beginPath();ctx.moveTo(ex,ey);ctx.lineTo(ex-6*Math.cos(an-0.4),ey-6*Math.sin(an-0.4));ctx.lineTo(ex-6*Math.cos(an+0.4),ey-6*Math.sin(an+0.4));ctx.fill();});
    ctx.fillStyle=css('--green');ctx.beginPath();ctx.arc(ox,oy,5,0,7);ctx.fill();
    const eps=1e-6;let nat,cls;
    if(l1>eps&&l2>eps){nat='Minimum unique en (0 ; 0)';cls='A définie positive : lignes de niveau en ellipses. Exemple : l’énergie d’une structure bien tenue.';}
    else if(l1<-eps&&l2<-eps){nat='Maximum unique en (0 ; 0)';cls='A définie négative : ellipses, mais f descend dans toutes les directions.';}
    else if(l1>eps&&l2<-eps){nat='Point selle (col)';cls='Valeurs propres de signes opposés : f monte le long d’un axe propre et descend le long de l’autre. Lignes de niveau en hyperboles.';}
    else{nat='Point critique non isolé';cls='Une valeur propre nulle : A n’est pas inversible, f est constante le long d’une droite (une vallée ou une crête plate).';}
    Q.querySelector('.q-info').innerHTML=`<p><b>A</b> = [[${fr(a,1)} ; ${fr(b,1)}] ; [${fr(b,1)} ; ${fr(c,1)}]]</p><p>tr A = ${fr(tr)} · det A = ${fr(det)}</p>
      <p><b>λ₁</b> = ${fr(l1)} · <b>λ₂</b> = ${fr(l2)}</p><p class="q-nat">${nat}</p><p>${cls}</p>`;
  }
  function hex(c){const m=c.match(/^#([0-9a-f]{6})$/i);if(m){const n=parseInt(m[1],16);return [n>>16,(n>>8)&255,n&255];}const r=c.match(/\d+/g);return r?r.slice(0,3).map(Number):[128,128,128];}
  Q.querySelectorAll('[data-a]').forEach(r=>r.addEventListener('input',()=>{P[r.dataset.a]=+r.value;Q.querySelector(`[data-o="${r.dataset.a}"]`).textContent=fr(+r.value,1);draw();}));
  Q.querySelectorAll('[data-p]').forEach(bt=>bt.addEventListener('click',()=>{const p=PRE[+bt.dataset.p];['a','b','c'].forEach((k,i)=>{P[k]=p[i+1];Q.querySelector(`[data-a="${k}"]`).value=p[i+1];Q.querySelector(`[data-o="${k}"]`).textContent=fr(p[i+1],1);});draw();}));
  draw();new MutationObserver(draw).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
}

/* ---------- 2. Second ordre ---------- */
const O=document.getElementById('ode-lab');
if(O){
  const P={w:6.3,z:0.6};
  O.innerHTML=`<div class="mlab-hd"><b>Laboratoire : m ẍ + c ẋ + k x = 0, lâché depuis x = 1</b><span class="pill">Interactif</span></div>
    <div class="mlab-ctl">${slider('w','Pulsation propre ω₀ (rad/s)',1,20,0.1,P.w)}${slider('z','Amortissement ζ',0,2,0.05,P.z)}</div>
    <svg class="ode-fig" viewBox="0 0 560 240" role="img" aria-label="Réponse x(t) du système"></svg><div class="ode-info" aria-live="polite"></div>`;
  const svg=O.querySelector('svg');
  function x(t){const {w,z}=P;
    if(z<1){const wd=w*Math.sqrt(1-z*z);return Math.exp(-z*w*t)*(Math.cos(wd*t)+z*w/wd*Math.sin(wd*t));}
    if(Math.abs(z-1)<1e-9)return Math.exp(-w*t)*(1+w*t);
    const s=Math.sqrt(z*z-1),r1=-w*(z-s),r2=-w*(z+s),A=-r2/(r1-r2),B=r1/(r1-r2);return A*Math.exp(r1*t)+B*Math.exp(r2*t);}
  function draw(){
    const {w,z}=P,Tm=Math.max(2,Math.min(30,12/w*(z<0.2?3:1.6))),L=40,R=548,T=16,B=200,X=t=>L+t/Tm*(R-L),Y=v=>(T+B)/2-v*(B-T)/2.2;
    let d='';for(let i=0;i<=300;i++){const t=i/300*Tm;d+=(i?'L':'M')+X(t).toFixed(1)+' '+Y(x(t)).toFixed(1)+' ';}
    let env='';if(z<1&&z>0){for(const sg of [1,-1]){let e='';for(let i=0;i<=100;i++){const t=i/100*Tm;e+=(i?'L':'M')+X(t).toFixed(1)+' '+Y(sg*Math.exp(-z*w*t)).toFixed(1)+' ';}env+=`<path d="${e}" fill="none" stroke="var(--muted)" stroke-dasharray="4 4" stroke-width="1"/>`;}}
    const ticks=[0,0.25,0.5,0.75,1].map(f=>`<text x="${X(f*Tm)}" y="${B+22}" font-size="11" fill="var(--muted)" text-anchor="middle">${fr(f*Tm,1)} s</text>`).join('');
    svg.innerHTML=`<line x1="${L}" x2="${R}" y1="${Y(0)}" y2="${Y(0)}" stroke="var(--line2)"/><line x1="${L}" x2="${L}" y1="${T}" y2="${B}" stroke="var(--line2)"/>
      <rect x="${L}" y="${Y(0.05)}" width="${R-L}" height="${Y(-0.05)-Y(0.05)}" fill="var(--green)" opacity=".1"/>
      <text x="${L-6}" y="${Y(1)+4}" font-size="11" fill="var(--muted)" text-anchor="end">1</text><text x="${L-6}" y="${Y(0)+4}" font-size="11" fill="var(--muted)" text-anchor="end">0</text>
      ${env}<path d="${d}" fill="none" stroke="var(--cyan)" stroke-width="2.4"/>${ticks}`;
    // temps d'entrée dans ±5 %
    let ts=null;for(let i=3000;i>=0;i--){const t=i/3000*Tm*3;if(Math.abs(x(t))>0.05){ts=(i+1)/3000*Tm*3;break;}}
    const reg=z===0?'Non amorti : oscille indéfiniment (cas idéal sans frottement).':z<1?`Sous-amorti : oscille à ${fr(w*Math.sqrt(1-z*z)/(2*Math.PI),2)} Hz en s’amortissant.`:Math.abs(z-1)<1e-9?'Amortissement critique : retour le plus rapide sans dépasser.':'Sur-amorti : revient lentement, sans osciller.';
    O.querySelector('.ode-info').innerHTML=`<p><b>${reg}</b></p><p>Retour dans la bande ±5 % (verte) : ${z===0?'jamais':ts?fr(ts,2)+' s':'immédiat'}${z>0&&z<1?` · premier dépassement : ${fr(100*Math.exp(-Math.PI*z/Math.sqrt(1-z*z)),0)} %`:''}</p>`;
  }
  O.querySelectorAll('[data-a]').forEach(r=>r.addEventListener('input',()=>{P[r.dataset.a]=+r.value;O.querySelector(`[data-o="${r.dataset.a}"]`).textContent=fr(+r.value,r.dataset.a==='z'?2:1);draw();}));
  draw();
}
})();
