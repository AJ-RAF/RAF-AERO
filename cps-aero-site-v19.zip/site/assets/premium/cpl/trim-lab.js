/* CPSAero — laboratoire d'équilibrage longitudinal (chapitre Stabilité).
   Modèle linéaire : Cz = Cz0 + Czα α + Czδ δE ; Cm = Cm0 + Cmα α + Cmδ δE ; équilibre Cz = mg/(½ρV²S), Cm = 0. */
(function(){
const R=document.getElementById('trim-lab');if(!R)return;
const D=window.CPS_TRIM_DEFAULTS||{S:129.2,cbar:4.2246,SH:31,lt:15};
const fr=(x,d=3)=>Number(x).toLocaleString('fr-FR',{minimumFractionDigits:d,maximumFractionDigits:d});
const rad=x=>x*Math.PI/180,deg=x=>x*180/Math.PI;
const F=[['m','Masse','t',68,20,600,1],['V','Vitesse propre','m/s',230,40,320,1],['rho','Masse volumique ρ','kg/m³',0.38,0.2,1.25,0.01],['xcg','Centrage x_CG / c̄','—',0.30,0.05,0.6,0.01],['iph','Calage du plan horizontal','°',-2.5,-8,4,0.1],['butee','Butée de profondeur (à cabrer)','°',-20,-30,-5,1]];
const A=[['aw','Pente aile a_aile','rad⁻¹',5.0],['at','Pente PH a_PH','rad⁻¹',4.0],['eta','(V′/V)²','—',0.9],['deda','dε/dα','—',0.35],['e0','ε₀','°',0.5],['iw','Calage aile','°',2],['a0','α₀ aile','°',-2],['tau','Efficacité τ','—',0.45],['cmf','Cm au foyer','—',-0.08],['xf','Foyer aile+fuselage x_f / c̄','—',0.22]];
const field=([k,l,u,v,mn,mx,st])=>`<div class="field"><label for="tl-${k}">${l} <span class="u">${u}</span></label><input id="tl-${k}" data-k="${k}" type="number" inputmode="decimal" value="${v}" ${mn!==undefined?`min="${mn}" max="${mx}"`:''} step="${st||'any'}"></div>`;
R.innerHTML=`<div class="mlab-hd"><b>Laboratoire : équilibrer l’avion d’étude</b><span class="pill">Interactif</span></div>
<p class="mlab-note">Géométrie fixe : S = ${fr(D.S,1)} m², c̄ = ${fr(D.cbar,3)} m, S_H = ${D.SH} m², l_T = ${D.lt} m (au centrage 0,30 c̄). Change la masse, la vitesse, l’altitude (ρ) ou le centrage, et regarde l’équilibre se recalculer.</p>
<div class="fields mlab-kf">${F.map(field).join('')}</div>
<details class="trim-adv"><summary>Données aérodynamiques (avancé)</summary><div class="fields mlab-kf">${A.map(a=>field([a[0],a[1],a[2],a[3]])).join('')}</div></details>
<div class="trim-out" aria-live="polite"></div>`;
function run(){
  const v={};let bad='';
  R.querySelectorAll('[data-k]').forEach(el=>{const x=parseFloat(String(el.value).replace(',','.'));if(!isFinite(x)){bad='Entre un nombre dans chaque case.';el.setAttribute('aria-invalid','true');return;}
    const mn=parseFloat(el.min),mx=parseFloat(el.max);if((isFinite(mn)&&x<mn)||(isFinite(mx)&&x>mx)){bad=`${el.labels[0].textContent.trim()} : hors du domaine de ce modèle (${mn} à ${mx}).`;el.setAttribute('aria-invalid','true');return;}
    el.removeAttribute('aria-invalid');v[el.dataset.k]=x;});
  const out=R.querySelector('.trim-out');if(bad){out.innerHTML=`<p class="fb bad" role="alert">${bad}</p>`;return;}
  const ltc=D.lt/D.cbar+0.30-v.xcg,k=v.eta*D.SH/D.S*v.at;
  const Cza=v.aw+k*(1-v.deda),Cz0=v.aw*rad(v.iw-v.a0)+k*rad(v.iph-v.e0),Czd=k*v.tau;
  const Cm0=v.cmf-v.aw*rad(v.iw-v.a0)*(v.xf-v.xcg)-k*rad(v.iph-v.e0)*ltc,Cma=-v.aw*(v.xf-v.xcg)-k*(1-v.deda)*ltc,Cmd=-k*v.tau*ltc;
  const q=0.5*v.rho*v.V*v.V,Czt=v.m*1000*9.81/(q*D.S),det=Cza*Cmd-Czd*Cma,dC=Czt-Cz0;
  const al=(dC*Cmd+Czd*Cm0)/det,de=-(Cma*dC+Cza*Cm0)/det,Ks=-Cma/Cza;
  const warn=[];
  if(Cma>=0)warn.push('C<sub>mα</sub> ≥ 0 : le centre de gravité est au foyer ou derrière, l’avion est instable. Avance le centrage.');
  if(deg(de)<v.butee)warn.push(`La profondeur devrait braquer ${fr(deg(de),1)}°, au-delà de sa butée (${v.butee}°) : équilibre impossible. Recule le centrage, accélère ou allège l’avion.`);
  if(deg(de)>15)warn.push('Braquage à piquer très important : vérifie le calage du plan horizontal.');
  if(Czt>1.6)warn.push(`C<sub>z,trim</sub> = ${fr(Czt,2)} : au-delà d’environ 1,6, une aile lisse décroche. Trop lent pour cette masse.`);
  out.innerHTML=`<div class="k-res">
    <div><span>C<sub>z,trim</sub></span><b>${fr(Czt,4)}</b></div><div><span>Marge statique</span><b>${fr(Ks*100,1)} %</b><em>${Ks>0?'stable':'instable'}</em></div><div><span>Déterminant</span><b>${fr(det,4)}</b></div>
    <div><span>α<sub>trim</sub></span><b>${fr(deg(al),2)}°</b></div><div><span>δ<sub>E,trim</sub></span><b>${fr(deg(de),2)}°</b><em>${de<0?'vers le haut (cabreur)':'vers le bas (piqueur)'}</em></div><div><span>Pression dynamique</span><b>${fr(q,0)} Pa</b></div></div>
    <p class="mlab-small">C<sub>z0</sub> = ${fr(Cz0,4)} · C<sub>zα</sub> = ${fr(Cza,4)} · C<sub>zδ</sub> = ${fr(Czd,4)} · C<sub>m0</sub> = ${fr(Cm0,4)} · C<sub>mα</sub> = ${fr(Cma,4)} · C<sub>mδ</sub> = ${fr(Cmd,4)}</p>
    ${warn.map(w=>`<p class="fb bad" role="alert">${w}</p>`).join('')}`;
}
R.querySelectorAll('[data-k]').forEach(el=>el.addEventListener('input',run));run();
window.CPS_TRIM={run};
})();
