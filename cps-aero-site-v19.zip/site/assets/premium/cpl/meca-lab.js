/* CPSAero — laboratoires du chapitre « Repères, rotations et calcul matriciel ».
   1. Angles d'Euler aéronautiques (lacet ψ, tangage θ, roulis φ, convention z-y-x, repère NED) :
      trois vues 2D + matrice de passage calculée en direct + contrôle d'orthogonalité.
   2. Solveur [K]{U} = {F} pour trois ressorts en série (élimination de Gauss) + contrôle d'équilibre. */
(function(){
const fr=(x,d=3)=>(Math.abs(x)<5e-13?0:x).toLocaleString('fr-FR',{minimumFractionDigits:d,maximumFractionDigits:d});
const R=Math.PI/180;

/* ---------------- 1. Angles d'Euler ---------------- */
const E=document.getElementById('euler-lab');
if(E){
  const PRE=[['Croisière cap 090',90,2,0],['Virage à 30°',45,3,30],['Montée',0,10,0],['Nez à 89° (blocage de cardan)',0,89,40]];
  E.innerHTML=`<div class="mlab-hd"><b>Laboratoire : l’attitude d’un avion</b><span class="pill">Interactif</span></div>
  <div class="mlab-ctl">
    ${[['psi','Lacet ψ (cap)',-180,180,30],['theta','Tangage θ (assiette)',-89,89,10],['phi','Roulis φ (inclinaison)',-180,180,20]].map(([k,l,a,b,v])=>
      `<label class="mlab-f"><span>${l}</span><input type="range" min="${a}" max="${b}" step="1" value="${v}" data-a="${k}" aria-label="${l}"><output data-o="${k}">${v}°</output></label>`).join('')}
  </div>
  <div class="chips mlab-pre" role="group" aria-label="Préréglages">${PRE.map((p,i)=>`<button type="button" class="chip" data-p="${i}">${p[0]}</button>`).join('')}</div>
  <div class="mlab-views">
    <figure><svg viewBox="0 0 200 170" role="img" aria-label="Vue de dessus : lacet" data-v="top"></svg><figcaption>Vue de dessus : <b>lacet ψ</b></figcaption></figure>
    <figure><svg viewBox="0 0 200 170" role="img" aria-label="Vue de côté : tangage" data-v="side"></svg><figcaption>Vue de côté : <b>tangage θ</b></figcaption></figure>
    <figure><svg viewBox="0 0 200 170" role="img" aria-label="Vue de l’arrière : roulis" data-v="back"></svg><figcaption>Vue de l’arrière : <b>roulis φ</b></figcaption></figure>
  </div>
  <p class="mlab-note">Chaque vue isole un angle. La matrice, elle, enchaîne les trois rotations dans l’ordre lacet → tangage → roulis.</p>
  <div class="mlab-out">
    <div><span class="eyebrow">Matrice de passage [R] (colonnes : nez, aile droite, ventre, dans NED)</span><table class="mat" aria-live="polite"></table></div>
    <div class="mlab-checks"></div>
  </div>`;
  const ang={psi:30,theta:10,phi:20};
  const plane=(c)=>`<path d="M0 -46 L6 -30 L6 -8 L44 10 L44 18 L6 8 L5 30 L16 40 L16 46 L0 42 L-16 46 L-16 40 L-5 30 L-6 8 L-44 18 L-44 10 L-6 -8 L-6 -30 Z" fill="var(--panel2)" stroke="${c}" stroke-width="2"/>`;
  const side=`<path d="M-50 2 C-50 -6 -42 -9 -30 -9 L34 -9 C46 -9 54 -4 58 0 C54 5 46 7 34 7 L-30 7 C-42 7 -50 6 -50 2Z" fill="var(--panel2)" stroke="var(--fg)" stroke-width="2"/><path d="M-44 -8 L-52 -28 L-40 -28 L-28 -9Z" fill="var(--panel2)" stroke="var(--fg)" stroke-width="2"/>`;
  const back=`<path d="M-70 2 L70 2 L70 8 L-70 8Z" fill="var(--panel2)" stroke="var(--fg)" stroke-width="2"/><circle cx="0" cy="4" r="11" fill="var(--panel2)" stroke="var(--fg)" stroke-width="2"/><path d="M-3 -6 L-3 -32 L3 -32 L3 -6Z" fill="var(--panel2)" stroke="var(--fg)" stroke-width="2"/>`;
  const ax=(x,y,dx,dy,c,l)=>`<line x1="${x}" y1="${y}" x2="${x+dx}" y2="${y+dy}" stroke="${c}" stroke-width="2.4" stroke-linecap="round"/><circle cx="${x+dx}" cy="${y+dy}" r="3.5" fill="${c}"/><text x="${x+dx*1.18}" y="${y+dy*1.18+4}" fill="${c}" font-size="12" font-weight="700" text-anchor="middle">${l}</text>`;
  function draw(){
    const {psi,theta,phi}=ang;
    const top=E.querySelector('[data-v="top"]'),sd=E.querySelector('[data-v="side"]'),bk=E.querySelector('[data-v="back"]');
    top.innerHTML=`<text x="100" y="14" fill="var(--muted)" font-size="11" text-anchor="middle">N</text><line x1="100" y1="20" x2="100" y2="150" stroke="var(--line2)" stroke-dasharray="4 4"/>
      <path d="M100 40 A45 45 0 ${Math.abs(psi)>180?1:0} ${psi>=0?1:0} ${100+45*Math.sin(psi*R)} ${85-45*Math.cos(psi*R)}" fill="none" stroke="var(--amber)" stroke-width="2"/>
      <g transform="translate(100 85) rotate(${psi})">${plane('var(--fg)')}</g><text x="100" y="166" fill="var(--amber)" font-size="12" font-weight="700" text-anchor="middle">ψ = ${psi}°</text>`;
    sd.innerHTML=`<line x1="10" y1="85" x2="190" y2="85" stroke="var(--line2)" stroke-dasharray="4 4"/><text x="14" y="80" fill="var(--muted)" font-size="10">horizon</text>
      <g transform="translate(100 85) rotate(${-theta})">${side}</g><text x="100" y="166" fill="var(--amber)" font-size="12" font-weight="700" text-anchor="middle">θ = ${theta}°</text>`;
    bk.innerHTML=`<line x1="10" y1="85" x2="190" y2="85" stroke="var(--line2)" stroke-dasharray="4 4"/><text x="16" y="80" fill="var(--muted)" font-size="10">G</text><text x="184" y="80" fill="var(--muted)" font-size="10" text-anchor="end">D</text>
      <g transform="translate(100 85) rotate(${phi})">${back}</g><text x="100" y="166" fill="var(--amber)" font-size="12" font-weight="700" text-anchor="middle">φ = ${phi}°</text>`;
    // matrice z-y-x (corps → NED)
    const cps=Math.cos(psi*R),sps=Math.sin(psi*R),ct=Math.cos(theta*R),st=Math.sin(theta*R),cf=Math.cos(phi*R),sf=Math.sin(phi*R);
    const M=[[ct*cps, sf*st*cps-cf*sps, cf*st*cps+sf*sps],
             [ct*sps, sf*st*sps+cf*cps, cf*st*sps-sf*cps],
             [-st,    sf*ct,            cf*ct]];
    E.querySelector('.mat').innerHTML='<tr><th></th><th>x₁ nez</th><th>y₁ aile D</th><th>z₁ ventre</th></tr>'+['Nord','Est','Bas'].map((n,i)=>`<tr><th>${n}</th>${M[i].map(v=>`<td>${fr(v)}</td>`).join('')}</tr>`).join('');
    const det=M[0][0]*(M[1][1]*M[2][2]-M[1][2]*M[2][1])-M[0][1]*(M[1][0]*M[2][2]-M[1][2]*M[2][0])+M[0][2]*(M[1][0]*M[2][1]-M[1][1]*M[2][0]);
    let orth=0;for(let i=0;i<3;i++)for(let j=0;j<3;j++){let s=0;for(let k=0;k<3;k++)s+=M[k][i]*M[k][j];orth=Math.max(orth,Math.abs(s-(i===j?1:0)));}
    const th=-Math.asin(Math.max(-1,Math.min(1,M[2][0])))/R,ps=Math.atan2(M[1][0],M[0][0])/R,ph=Math.atan2(M[2][1],M[2][2])/R;
    const gl=Math.abs(theta)>=85;
    E.querySelector('.mlab-checks').innerHTML=`<p><b>Nez</b> = (${fr(M[0][0])} ; ${fr(M[1][0])} ; ${fr(M[2][0])}) en (N ; E ; Bas)</p>
      <p><b>det [R]</b> = ${fr(det)} · <b>[R]ᵀ[R] − I</b> : écart max ${orth.toExponential(1).replace('.',',')} → c’est bien une rotation</p>
      <p><b>Angles relus dans la matrice</b> : ψ = ${fr(ps,1)}°, θ = ${fr(th,1)}°, φ = ${fr(ph,1)}°</p>
      ${gl?'<p class="fb bad" role="alert">Proche de θ = ±90° : lacet et roulis tournent presque autour du même axe. Bouge ψ puis φ : leurs effets se ressemblent. C’est le blocage de cardan, et les angles relus deviennent instables.</p>':''}`;
    if(window.CPS_TEX&&CPS_TEX.fit)CPS_TEX.fit(E);
  }
  E.querySelectorAll('[data-a]').forEach(r=>r.addEventListener('input',()=>{ang[r.dataset.a]=+r.value;E.querySelector(`[data-o="${r.dataset.a}"]`).textContent=r.value+'°';draw();}));
  E.querySelectorAll('[data-p]').forEach(b=>b.addEventListener('click',()=>{const p=PRE[+b.dataset.p];[['psi',p[1]],['theta',p[2]],['phi',p[3]]].forEach(([k,v])=>{ang[k]=v;E.querySelector(`[data-a="${k}"]`).value=v;E.querySelector(`[data-o="${k}"]`).textContent=v+'°';});draw();}));
  draw();
  window.CPS_EULER={get matrix(){return E.querySelector('.mat').textContent;},set(p,t,f){ang.psi=p;ang.theta=t;ang.phi=f;draw();}};
}

/* ---------------- 2. Solveur [K]{U} = {F} ---------------- */
const K=document.getElementById('k-lab');
if(K){
  const D={k1:2000,k2:1000,k3:1000,f1:0,f2:0,f3:10000};
  K.innerHTML=`<div class="mlab-hd"><b>Laboratoire : trois ressorts en série</b><span class="pill">Interactif</span></div>
  <svg class="kfig" viewBox="0 0 560 120" role="img" aria-label="Bâti, trois ressorts et trois nœuds, déplacements exagérés"></svg>
  <div class="fields mlab-kf">${[['k1','k₁','N/mm'],['k2','k₂','N/mm'],['k3','k₃','N/mm'],['f1','F₁','N'],['f2','F₂','N'],['f3','F₃','N']].map(([k,l,u])=>
    `<div class="field"><label for="kl-${k}">${l} <span class="u">${u}</span></label><input id="kl-${k}" type="number" inputmode="decimal" data-k="${k}" value="${D[k]}" ${k[0]==='k'?'min="1" max="1000000"':'min="-1000000" max="1000000"'} step="any"></div>`).join('')}</div>
  <div class="mlab-out k-out" aria-live="polite"></div>`;
  function gauss(A,b){const n=b.length,M=A.map((r,i)=>r.concat([b[i]])),steps=[];
    for(let c=0;c<n;c++){let p=c;for(let r=c+1;r<n;r++)if(Math.abs(M[r][c])>Math.abs(M[p][c]))p=r;
      if(Math.abs(M[p][c])<1e-12)return null;[M[c],M[p]]=[M[p],M[c]];
      for(let r=c+1;r<n;r++){const f=M[r][c]/M[c][c];if(f){for(let k=c;k<=n;k++)M[r][k]-=f*M[c][k];steps.push(`L${r+1} ← L${r+1} − (${fr(f,4)}) × L${c+1}`);}}}
    const x=new Array(n).fill(0);for(let i=n-1;i>=0;i--){let s=M[i][n];for(let k=i+1;k<n;k++)s-=M[i][k]*x[k];x[i]=s/M[i][i];}return {x,steps};}
  const mat=(A,h)=>`<table class="mat">${h?`<tr>${h.map(t=>`<th>${t}</th>`).join('')}</tr>`:''}${A.map(r=>`<tr>${(Array.isArray(r)?r:[r]).map(v=>`<td>${typeof v==='number'?fr(v,v%1?3:0):v}</td>`).join('')}</tr>`).join('')}</table>`;
  function spring(x0,x1,y){const n=8,w=(x1-x0)/(n+2);let d=`M${x0} ${y} L${x0+w} ${y}`;for(let i=0;i<n;i++){d+=` L${x0+w+(i+0.5)*w} ${y+(i%2?9:-9)}`;}d+=` L${x1-w} ${y} L${x1} ${y}`;return d;}
  function run(){
    const v={};let err='';
    K.querySelectorAll('[data-k]').forEach(el=>{const x=parseFloat(String(el.value).replace(',','.'));
      if(!isFinite(x)){err='Entre un nombre dans chaque case.';el.setAttribute('aria-invalid','true');return;}
      if(el.dataset.k[0]==='k'&&x<=0){err='Une raideur doit être strictement positive : un ressort de raideur nulle ou négative ne tient rien.';el.setAttribute('aria-invalid','true');return;}
      el.removeAttribute('aria-invalid');v[el.dataset.k]=x;});
    const out=K.querySelector('.k-out');
    if(err){out.innerHTML=`<p class="fb bad" role="alert">${err}</p>`;return;}
    const A=[[v.k1+v.k2,-v.k2,0],[-v.k2,v.k2+v.k3,-v.k3],[0,-v.k3,v.k3]],F=[v.f1,v.f2,v.f3];
    const s=gauss(A,F);if(!s){out.innerHTML='<p class="fb bad" role="alert">Système singulier : la structure n’est pas tenue.</p>';return;}
    const U=s.x,R0=-v.k1*U[0],sumF=F[0]+F[1]+F[2],N=[v.k1*U[0],v.k2*(U[1]-U[0]),v.k3*(U[2]-U[1])];
    out.innerHTML=`<div class="k-sys">${mat(A)}<span class="k-op">×</span>${mat(['u₁','u₂','u₃'])}<span class="k-op">=</span>${mat(F)}</div>
      <p class="mlab-small"><b>Élimination de Gauss :</b> ${s.steps.join(' ; ')||'aucune opération (déjà triangulaire)'} ; puis remontée.</p>
      <div class="k-res">${U.map((u,i)=>`<div><span>u${'₁₂₃'[i]}</span><b>${fr(u,3)} mm</b></div>`).join('')}
        ${N.map((n,i)=>`<div><span>effort ressort ${i+1}</span><b>${fr(n,0)} N</b><em>${n>=0?'traction':'compression'}</em></div>`).join('')}</div>
      <p class="mlab-small"><b>Équilibre :</b> réaction du bâti R₀ = −k₁ u₁ = ${fr(R0,0)} N ; ΣF + R₀ = ${fr(sumF+R0,1)} N ${Math.abs(sumF+R0)<1e-6*Math.max(1,Math.abs(sumF))?'✓':'✗'}</p>`;
    const umax=Math.max(1e-9,...U.map(Math.abs)),k=60/umax,X=[60,200,340,480].map((x,i)=>x+(i?U[i-1]*k:0));
    K.querySelector('.kfig').innerHTML=`<rect x="20" y="30" width="16" height="60" fill="var(--panel2)" stroke="var(--fg)"/><path d="M20 34 l-8 8 M20 50 l-8 8 M20 66 l-8 8 M20 82 l-8 8" stroke="var(--muted)"/>
      <line x1="36" y1="60" x2="60" y2="60" stroke="var(--fg)" stroke-width="2"/>
      ${[0,1,2].map(i=>`<path d="${spring(X[i],X[i+1],60)}" fill="none" stroke="var(--cyan)" stroke-width="2"/><text x="${(X[i]+X[i+1])/2}" y="28" fill="var(--muted)" font-size="12" text-anchor="middle">k${'₁₂₃'[i]}</text>`).join('')}
      ${[1,2,3].map(i=>`<circle cx="${X[i]}" cy="60" r="7" fill="var(--amber)"/><text x="${X[i]}" y="104" fill="var(--fg)" font-size="12" text-anchor="middle">nœud ${i}</text>${F[i-1]?`<line x1="${X[i]}" y1="60" x2="${X[i]+Math.sign(F[i-1])*34}" y2="60" stroke="var(--c-thrust)" stroke-width="3"/>`:''}`).join('')}
      <text x="550" y="116" fill="var(--muted)" font-size="10" text-anchor="end">déplacements exagérés pour être visibles</text>`;
    if(window.CPS_TEX&&CPS_TEX.fit)CPS_TEX.fit(K);
  }
  K.querySelectorAll('[data-k]').forEach(el=>el.addEventListener('input',run));run();
}
})();
