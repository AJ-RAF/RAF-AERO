/* CPSAero — hangar 3D : données des duos civils (grade CPL).
   Servi par le serveur aux seuls grades autorisés quand les grades sont ouverts ; hangar3d.js les fusionne s'ils sont présents. */
(function(){
/* Turbofans civils (dimensions et étages : fiches publiques CFM / Safran / FAA, voir la page) */
const TF={
  leap1a:{D:1.98,L:3.33,nFan:18,nBoost:3,nHP:10,nHPT:2,nLPT:7,bpr:11},
  leap1b:{D:1.76,L:3.15,nFan:18,nBoost:3,nHP:10,nHPT:2,nLPT:5,bpr:9},
  cfm56:{D:1.73,L:2.60,nFan:36,nBoost:4,nHP:9,nHPT:1,nLPT:4,bpr:5.7}
};
/* Cellules (proportions approximatives à partir des longueurs et envergures publiques) */
const AL={
  a320:{L:37.57,span:35.8,R:1.98,x0:3.5,wingY:-1.0,engZ:5.75,lead:2.4,engDrop:0.35,ht:12.45,fin:5.9},
  b737:{L:39.52,span:35.9,R:1.88,x0:3.0,wingY:-1.05,engZ:4.9,lead:3.4,engDrop:0.05,ht:14.35,fin:5.6}
};

const DUOS={};
Object.assign(DUOS,{
  a320neo:{avion:'A320neo',moteur:'LEAP-1A',civil:true,nEng:2,Fsec:143,Fpc:143,tf:TF.leap1a,al:AL.a320},
  b737max:{avion:'737 MAX 8',moteur:'LEAP-1B',civil:true,nEng:2,Fsec:125,Fpc:125,tf:TF.leap1b,al:AL.b737},
  a320ceo:{avion:'A320ceo',moteur:'CFM56-5B',civil:true,nEng:2,Fsec:120,Fpc:120,tf:TF.cfm56,al:AL.a320}
});

const CIV_COMMON={
  nacelle:{n:'Nacelle et entrée d’air',c:'Intégration',t:'Le carénage autour du moteur. L’entrée d’air ralentit l’air avant la soufflante ; à l’arrière, l’inverseur de poussée dévie le flux secondaire vers l’avant pour freiner à l’atterrissage.'},
  mat:{n:'Mât d’accrochage',c:'Intégration',t:'La pièce qui suspend le moteur sous l’aile. Elle transmet à l’aile la poussée, le poids et les efforts de rafale, et porte les tuyaux de carburant, d’air et les câbles. Le calcul de ses efforts est un torseur : voir le cours Repères et matrices.'},
  secondaire:{n:'Flux secondaire',c:'Double flux',t:'La plus grande partie de l’air ne traverse pas le cœur : la soufflante l’accélère un peu et il ressort directement par la tuyère froide. C’est lui qui fournit l’essentiel de la poussée d’un turbofan civil.'},
  tuyere:{n:'Tuyères séparées',c:'Éjection',t:'Deux sorties : la tuyère du flux froid, autour, et la tuyère du flux chaud, au centre, avec son cône. Pas de post-combustion sur un moteur civil.'},
  fadec:{n:'FADEC',c:'Régulation numérique',t:'Calculateur à pleine autorité, à deux voies. Il dose le carburant, règle les géométries variables du compresseur et protège le moteur de ses limites (régime, EGT).'},
  booster:{n:'Compresseur basse pression (booster)',c:'Corps basse pression',t:'Quelques étages derrière la soufflante, sur le même arbre qu’elle, qui précompriment l’air du cœur avant le compresseur haute pression.'}
};
const civ=(o)=>Object.assign({},CIV_COMMON,o);
const INFO_CIV={
  a320neo:civ({
    soufflante:{n:'Soufflante (18 aubes)',c:'Corps basse pression',t:'1,98 m de diamètre. Les aubes sont en composite carbone tissé en 3D et injecté de résine (procédé RTM) : plus légères et plus résistantes que le titane.'},
    hp:{n:'Compresseur HP (10 étages)',c:'Corps haute pression',t:'Dix étages qui multiplient la pression du cœur par environ 22. Taux de compression global du moteur : environ 40 au décollage.'},
    chambre:{n:'Chambre TAPS II (prémélange pauvre)',c:'Cœur',t:'Le carburant est prémélangé à beaucoup d’air avant de brûler : flamme « pauvre », plus froide par endroits, qui produit beaucoup moins d’oxydes d’azote (NOx). Les injecteurs sont fabriqués par impression 3D.'},
    thp:{n:'Turbine HP (2 étages)',c:'Corps haute pression',t:'Deux étages entraînent le compresseur HP. Des composites céramiques (CMC) sont utilisés dans les parties les plus chaudes.'},
    tbp:{n:'Turbine BP (7 étages)',c:'Corps basse pression',t:'Sept étages pour entraîner la grande soufflante et le booster, qui tournent lentement par rapport au corps HP.'},
    moteurs:{n:'Deux LEAP-1A',c:'A320neo',t:'Environ 143 kN au décollage chacun. Environ 15 % de carburant et de CO₂ en moins que les moteurs de la génération précédente, selon le motoriste.'},
    aile:{n:'Aile en flèche',c:'A320neo',t:'35,8 m d’envergure avec les ailettes « sharklets ». Les moteurs sont suspendus devant et sous l’aile.'},
    tuyeres:{n:'Tuyères',c:'A320neo',t:'Flux froid autour, flux chaud au centre.'}}),
  b737max:civ({
    soufflante:{n:'Soufflante (18 aubes)',c:'Corps basse pression',t:'1,76 m de diamètre seulement : le 737 est bas sur pattes, la soufflante devait passer sous l’aile sans toucher le sol. Même technologie d’aubes en composite tissé 3D.'},
    hp:{n:'Compresseur HP (10 étages)',c:'Corps haute pression',t:'Même cœur haute pression que le LEAP-1A.'},
    chambre:{n:'Chambre de combustion',c:'Cœur',t:'Chambre à prémélange de la famille LEAP, injecteurs imprimés en 3D, NOx réduits.'},
    thp:{n:'Turbine HP (2 étages)',c:'Corps haute pression',t:'Deux étages refroidis, matériaux céramiques (CMC) dans les parties chaudes.'},
    tbp:{n:'Turbine BP (5 étages)',c:'Corps basse pression',t:'Cinq étages au lieu de sept : la soufflante, plus petite, demande moins de puissance.'},
    moteurs:{n:'Deux LEAP-1B',c:'737 MAX 8',t:'Environ 125 kN au décollage chacun (28 000 lbf, valeur du motoriste). Moteurs avancés et surélevés par rapport au 737 précédent.'},
    aile:{n:'Aile en flèche',c:'737 MAX 8',t:'35,9 m d’envergure avec les ailettes. L’avion étant bas, la nacelle est placée haut et en avant de l’aile.'},
    tuyeres:{n:'Tuyères',c:'737 MAX 8',t:'Flux froid autour, flux chaud au centre.'}}),
  a320ceo:civ({
    soufflante:{n:'Soufflante (36 aubes)',c:'Corps basse pression',t:'1,73 m de diamètre, aubes en titane à large corde. La génération précédente : deux fois plus d’aubes que sur le LEAP, et un taux de dilution d’environ 5,5 à 6.'},
    booster:{n:'Booster (4 étages)',c:'Corps basse pression',t:'Quatre étages basse pression derrière la soufflante.'},
    hp:{n:'Compresseur HP (9 étages)',c:'Corps haute pression',t:'Neuf étages. Taux de compression global d’environ 33 à 35.'},
    chambre:{n:'Chambre annulaire',c:'Cœur',t:'Chambre annulaire simple ; une version à double anneau a été proposée pour réduire les NOx.'},
    thp:{n:'Turbine HP (1 étage)',c:'Corps haute pression',t:'Un seul étage de turbine HP entraîne les neuf étages du compresseur.'},
    tbp:{n:'Turbine BP (4 étages)',c:'Corps basse pression',t:'Quatre étages pour la soufflante et le booster.'},
    moteurs:{n:'Deux CFM56-5B',c:'A320ceo',t:'Environ 120 kN au décollage dans la version A320. Plus de 34 000 moteurs CFM56 livrés, toutes versions, selon le motoriste.'},
    aile:{n:'Aile en flèche',c:'A320ceo',t:'Même cellule que l’A320neo : on compare les deux générations de moteurs sur le même avion.'},
    tuyeres:{n:'Tuyères',c:'A320ceo',t:'Flux froid autour, flux chaud au centre.'}})
};


const TP={
  a320neo:{soufflante:[['Diamètre','1,98 m (78 in)'],['Taux de dilution','≈ 11']],hp:[['Compression globale','≈ 40 (≈ 50 en haut de montée)']],moteurs:[['Poussée décollage','143 kN (32 160 lbf, fiche FAA)'],['Masse','3 153 kg avec fluides']]},
  b737max:{soufflante:[['Diamètre','1,76 m (69 in)'],['Taux de dilution','≈ 9']],moteurs:[['Poussée décollage','≈ 125 kN (28 000 lbf)']]},
  a320ceo:{soufflante:[['Diamètre','1,73 m (68,3 in)'],['Taux de dilution','≈ 5,5 à 6']],hp:[['Compression globale','≈ 33 à 35']],moteurs:[['Poussée décollage','≈ 120 kN (version -5B4)']]}
};
window.CPS_HANGAR_CIVIL={DUOS,INFO:INFO_CIV,TP};
})();
