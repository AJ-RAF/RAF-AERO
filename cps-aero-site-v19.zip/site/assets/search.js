/* CPSAero — recherche globale. L'index (window.CPS_SEARCH) est généré par build.py dans search-index.js.
   Bouton dans le menu, raccourci « / » ou Ctrl+K, navigation au clavier (flèches, Entrée, Échap). */
(function(){
  const IDX=window.CPS_SEARCH||[];
  const norm=t=>(t||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[’']/g,' ');
  IDX.forEach(e=>{e._t=norm(e.t);e._a=norm(e.t+' '+(e.d||'')+' '+(e.k||'')+' '+(e.c||''));});
  const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const right=document.querySelector('.nav-right');
  if(!right)return;
  const btn=document.createElement('button');
  btn.type='button';btn.className='srch-btn';btn.setAttribute('aria-label','Rechercher dans le site');
  btn.innerHTML='<span aria-hidden="true">⌕</span><span class="lbl">Rechercher</span><kbd>/</kbd>';
  right.insertBefore(btn,right.querySelector('.theme-btn'));
  let ov=null,input,list,sel=0,hits=[],lastFocus=null;

  function score(e,words){
    let s=0;
    for(const w of words){
      if(!e._a.includes(w))return -1;
      if(e._t.startsWith(w))s+=12;else if(e._t.includes(w))s+=6;else s+=1;
    }
    return s+(e.w||0);
  }
  function search(q){
    const words=norm(q).trim().split(/\s+/).filter(Boolean);
    if(!words.length)return IDX.filter(e=>e.f).slice(0,8);
    return IDX.map(e=>[score(e,words),e]).filter(x=>x[0]>=0).sort((a,b)=>b[0]-a[0]).slice(0,12).map(x=>x[1]);
  }
  function draw(){
    hits=search(input.value);sel=Math.min(sel,Math.max(hits.length-1,0));
    list.innerHTML=hits.length?hits.map((e,i)=>`<li><a href="${esc(e.u)}" class="${i===sel?'on':''}" data-i="${i}"><b>${esc(e.t)}</b><em>${esc(e.d||'')}</em><i>${esc(e.c)}</i></a></li>`).join('')
      :'<li><p class="srch-empty">Aucun résultat. Essaie un mot plus court : « Mach », « portance », « BUT »…</p></li>';
    list.querySelectorAll('a').forEach(a=>a.addEventListener('mousemove',()=>{sel=+a.dataset.i;mark();}));
  }
  function mark(){list.querySelectorAll('a').forEach((a,i)=>a.classList.toggle('on',i===sel));const a=list.querySelector('a.on');if(a&&a.scrollIntoView)a.scrollIntoView({block:'nearest'});}
  function open(){
    if(ov)return;lastFocus=document.activeElement;
    ov=document.createElement('div');ov.className='srch-ov';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');ov.setAttribute('aria-label','Recherche');
    ov.innerHTML='<div class="srch-box"><label class="srch-in"><span>RECH</span><input type="search" placeholder="Un cours, un mot du lexique, un moteur, un métier…" aria-label="Rechercher" autocomplete="off"><kbd>Échap</kbd></label><ul class="srch-res" role="listbox"></ul><div class="srch-foot"><span>↑ ↓ pour choisir</span><span>Entrée pour ouvrir</span></div></div>';
    document.body.appendChild(ov);
    input=ov.querySelector('input');list=ov.querySelector('.srch-res');sel=0;draw();input.focus();
    input.addEventListener('input',()=>{sel=0;draw();});
    input.addEventListener('keydown',e=>{
      if(e.key==='ArrowDown'){e.preventDefault();sel=Math.min(sel+1,hits.length-1);mark();}
      else if(e.key==='ArrowUp'){e.preventDefault();sel=Math.max(sel-1,0);mark();}
      else if(e.key==='Enter'){const h=hits[sel];if(h){e.preventDefault();go(h.u);}}
    });
    ov.addEventListener('click',e=>{if(e.target===ov)close();});
    list.addEventListener('click',e=>{const a=e.target.closest('a');if(a){e.preventDefault();go(a.getAttribute('href'));}});
  }
  function go(u){close();const here=location.pathname.split('/').pop()||'index.html';const [p,h]=u.split('#');
    if((p||'index.html')===here&&h){location.hash=h;const el=document.getElementById(h);if(el&&el.scrollIntoView)el.scrollIntoView({block:'start'});}else location.href=u;}
  function close(){if(!ov)return;ov.remove();ov=null;if(lastFocus&&lastFocus.focus)lastFocus.focus();}
  btn.addEventListener('click',open);
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&ov){close();return;}
    const t=e.target,typing=t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.tagName==='SELECT'||t.isContentEditable);
    if((e.key==='/'&&!typing)||((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k')){e.preventDefault();open();}
  });
  window.CPS_SEARCH_UI={open,close,search};
})();
