/* CPSAero — test d'habilitation « Mode Ingénieur » (version renforcée, v15).
   5 questions, une par thème (lois de conservation, ordres de grandeur, hypothèses d'écoulement,
   thermodynamique, mécanique du vol), tirées dans une banque de 18. 4 bonnes réponses sur 5 pour le badge.
   Chaque réponse est expliquée ; on peut repasser le test autant de fois que nécessaire.
   Le badge est gardé sur l'appareil (localStorage « cps-badge », version 2), sans compte ni serveur.
   Le badge débloque le mode Ingénieur (bouton du menu) : démonstrations ouvertes et calculateurs de dimensionnement.
   Quand les grades sont ouverts (v19), le même test sert d'essai gratuit : CPS_HAB.trial() demande 5 questions au serveur
   (/api/essai), qui corrige lui-même les réponses et ouvre 24 h de grade CPL si 4 sont justes.
   API : window.CPS_HAB = { ok(), open(onDone), trial(), reset(), method() } ; événements « cps:badge » sur document. */
(function(){
  const KEY='cps-badge',VER=2,N=5,PASS=4;
  const THEMES=['conservation','grandeur','ecoulement','thermo','vol'];
  const THEME_LBL={conservation:'Lois de conservation',grandeur:'Ordres de grandeur',ecoulement:'Hypothèses d’écoulement',thermo:'Thermodynamique',vol:'Mécanique du vol'};
  const BANK=[
    // --- Lois de conservation
    {t:'conservation',q:'Dans une tuyère convergente subsonique, la section passe de 0,8 m² à 0,5 m². La masse volumique varie peu et l’air entre à 150 m/s. Quelle est sa vitesse en sortie ?',o:['94 m/s','150 m/s','240 m/s','384 m/s'],a:2,
     w:'Conservation de la masse en régime permanent : ρ·V·A est constant. Avec ρ quasi constant, V₂ = V₁ × A₁ / A₂ = 150 × 0,8 / 0,5 = 240 m/s.'},
    {t:'conservation',q:'Un réacteur avale 100 kg/s d’air à 200 m/s et le rejette à 500 m/s (tuyère adaptée, carburant négligé). Quelle est sa poussée ?',o:['50 kN','30 kN','20 kN','70 kN'],a:1,
     w:'Bilan de quantité de mouvement : F = ṁ·(V₉ − V₀) = 100 × (500 − 200) = 30 000 N = 30 kN. Utiliser 500 m/s seul oublie la traînée de captation.'},
    {t:'conservation',q:'L’équation de Bernoulli, p + ½ρV² = constante le long d’une ligne de courant, suppose un écoulement…',o:['Turbulent et visqueux','Permanent, incompressible, sans frottement et sans apport de travail ni de chaleur','Compressible à n’importe quel Mach','Uniquement supersonique'],a:1,
     w:'Bernoulli sous cette forme demande les quatre hypothèses : permanent, incompressible, non visqueux, sans machine ni échange de chaleur entre les deux points. Dès qu’un compresseur est entre les deux, il faut le premier principe.'},
    {t:'conservation',q:'Dans un compresseur en régime permanent, adiabatique, le travail fourni à chaque kilo d’air vaut…',o:['Sa variation de vitesse','Sa variation d’enthalpie, soit cₚ × ΔT','Sa variation de pression divisée par la masse','Zéro, car le système est adiabatique'],a:1,
     w:'Premier principe en système ouvert : w = Δh (énergies cinétique et potentielle négligées). Pour un gaz parfait, Δh = cₚ·ΔT. Adiabatique veut dire sans échange de chaleur, pas sans travail.'},
    // --- Ordres de grandeur
    {t:'grandeur',q:'Ordre de grandeur de la température des gaz à l’entrée de la turbine d’un moteur militaire moderne ?',o:['Environ 600 K','Environ 1 800 K','Environ 5 000 K','Environ 300 K'],a:1,
     w:'Autour de 1 800 K, soit environ 1 500 °C : plus que ce que supportent les superalliages des aubes, d’où le refroidissement par film d’air et les barrières thermiques.'},
    {t:'grandeur',q:'Ton calcul donne une poussée de 4 680 kN pour un moteur d’avion de chasse. Quelle est la bonne réaction ?',o:['Le noter : le calcul est juste','Soupçonner une erreur d’unité ou de donnée : un M88 fait environ 50 kN à sec','Arrondir à 4 700 kN','Diviser par 9,81 pour avoir des kilos'],a:1,
     w:'Valider par l’ordre de grandeur : près de 100 fois un M88. Un facteur 100 trahit presque toujours une erreur d’unité (km/h au lieu de m/s, par exemple).'},
    {t:'grandeur',q:'Ordre de grandeur du nombre de Reynolds sur l’aile d’un avion de ligne en croisière (corde ≈ 4 m) ?',o:['≈ 10³','≈ 10⁵','≈ 10⁷','≈ 10¹¹'],a:2,
     w:'Re = ρVc/μ ≈ 0,38 × 230 × 4 / 1,4·10⁻⁵ ≈ 2,5·10⁷. À ce Reynolds, la couche limite est largement turbulente : les essais en soufflerie sur maquette, à Reynolds plus faible, doivent en tenir compte.'},
    {t:'grandeur',q:'À 35 000 ft en atmosphère standard, la masse volumique de l’air vaut environ…',o:['90 % de celle au sol','30 % de celle au sol','3 % de celle au sol','Zéro : c’est le vide'],a:1,
     w:'σ = ρ/ρ₀ ≈ 0,31 à 35 000 ft. D’où une vitesse propre bien supérieure à la vitesse indiquée en croisière.'},
    // --- Hypothèses d'écoulement
    {t:'ecoulement',q:'Jusqu’à quel nombre de Mach considère-t-on habituellement un écoulement d’air comme incompressible ?',o:['Mach 0,03','Mach 0,3','Mach 1','Mach 3'],a:1,
     w:'En dessous de Mach 0,3 environ, la masse volumique varie de moins de 5 % : on peut la supposer constante. Un avion de ligne en croisière (Mach 0,78) est donc nettement compressible.'},
    {t:'ecoulement',q:'Une compression isentropique est une compression…',o:['À température constante','Adiabatique et réversible','À pression constante','Avec frottements, mais sans échange de chaleur'],a:1,
     w:'Isentropique = entropie constante = adiabatique (pas d’échange de chaleur) ET réversible (pas de frottement). Avec frottements, l’entropie augmente : c’est ce que mesure le rendement isentropique.'},
    {t:'ecoulement',q:'Près de la paroi d’une aile, dans la couche limite, l’hypothèse « fluide parfait » (sans viscosité) est…',o:['Parfaitement justifiée','Fausse : c’est justement là que la viscosité freine l’air jusqu’à une vitesse nulle sur la paroi','Valable seulement en supersonique','Valable si l’aile est lisse'],a:1,
     w:'Le fluide parfait marche loin de la paroi. Dans la couche limite, la viscosité impose une vitesse nulle sur la paroi : elle explique la traînée de frottement et le décollement de l’écoulement.'},
    {t:'ecoulement',q:'« Régime permanent » signifie que…',o:['La vitesse est la même partout dans l’écoulement','En un point fixe, les grandeurs (vitesse, pression, température) ne varient pas dans le temps','Le fluide est immobile','La pression est la même partout'],a:1,
     w:'Permanent veut dire indépendant du temps en chaque point, pas uniforme dans l’espace : dans une tuyère en régime permanent, la vitesse change d’une section à l’autre, mais pas d’un instant à l’autre.'},
    // --- Thermodynamique
    {t:'thermo',q:'On comprime de l’air (γ = 1,4) de façon isentropique, avec un taux de compression de 10, depuis 288 K. Quelle est la température de sortie ?',o:['288 K','≈ 556 K','2 880 K','≈ 1 000 K'],a:1,
     w:'T₂ = T₁ × π^((γ−1)/γ) = 288 × 10^0,286 ≈ 288 × 1,93 ≈ 556 K. La température ne croît pas comme la pression : l’exposant 0,286 l’amortit fortement.'},
    {t:'thermo',q:'Dans un cycle de Joule-Brayton idéal, que fait le rendement thermique quand on augmente le taux de compression ?',o:['Il augmente','Il diminue','Il ne change pas','Il devient négatif'],a:0,
     w:'η = 1 − 1/π^((γ−1)/γ) : plus π est grand, plus le rendement est élevé. C’est une des raisons de la hausse des taux de compression des moteurs modernes (environ 40 pour un LEAP).'},
    {t:'thermo',q:'L’hypothèse « gaz parfait » permet d’écrire, pour l’air…',o:['p = ρ·r·T','p = ρ·g·h','p·V = constante, toujours','ρ = constante'],a:0,
     w:'Loi des gaz parfaits par unité de masse : p = ρ·r·T, avec r = 287 J/(kg·K) pour l’air. p = ρgh est l’hydrostatique, et ρ constante est l’hypothèse incompressible.'},
    // --- Mécanique du vol
    {t:'vol',q:'Un avion vire à altitude constante, incliné à 60°. Quel facteur de charge subit-il ?',o:['1 g','1,5 g','2 g','6 g'],a:2,
     w:'n = 1 / cos φ = 1 / cos 60° = 2 g : l’aile doit porter deux fois le poids.'},
    {t:'vol',q:'En palier stabilisé, un avion double sa vitesse sans changer de masse ni d’altitude. Que devient son coefficient de portance C_L ?',o:['Il double','Il ne change pas','Il est divisé par 2','Il est divisé par 4'],a:3,
     w:'L = ½ρV²SC_L doit rester égal au poids. Si V double, V² est multiplié par 4, donc C_L doit être divisé par 4 : le pilote réduit l’incidence.'},
    {t:'vol',q:'Sur une aile en vol, dans quelle direction s’exerce la portance ?',o:['Perpendiculairement au vent relatif','Toujours à la verticale, vers le haut','Parallèlement au vent relatif','Vers l’avant de l’avion'],a:0,
     w:'La portance est la composante de la force aérodynamique perpendiculaire au vent relatif ; la traînée est la composante parallèle. En virage ou en montée, la portance n’est donc pas verticale.'}
  ];
  const read=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'null');}catch(e){return null;}};
  const ok=()=>{const b=read();return !!(b&&b.v>=VER);};
  const save=s=>{try{localStorage.setItem(KEY,JSON.stringify({v:VER,score:s,n:N,date:new Date().toISOString().slice(0,10)}));}catch(e){}};
  const reset=()=>{try{localStorage.removeItem(KEY);}catch(e){}document.dispatchEvent(new CustomEvent('cps:badge',{detail:{ok:false}}));};
  const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};

  const MODES=`<div class="modes-x"><p><b>Mode Débutant</b> : les concepts sont vulgarisés avec des analogies et des schémas, les démonstrations sont repliées.</p>
    <p><b>Mode Ingénieur</b> : accès aux modèles de calcul rigoureux, aux hypothèses physiques strictes et aux outils de dimensionnement. Il s’ouvre avec le badge.</p></div>`;
  const METHOD=`<ol class="method-steps">
    <li><b>Poser le cadre et les hypothèses.</b> Régime permanent ou transitoire ? Fluide parfait ou réel, compressible ou non ? Quelles simplifications sont acceptables pour la précision voulue ?</li>
    <li><b>Identifier les lois physiques.</b> Conservation de la masse, bilan de quantité de mouvement (Newton), bilan d’énergie (premier principe), second principe. Écrire les équations avant les chiffres.</li>
    <li><b>Dimensionner, puis valider par l’ordre de grandeur.</b> Vérifier les unités à chaque ligne et comparer le résultat à une valeur connue. Un chiffre physiquement impossible signale une erreur, pas une découverte.</li></ol>`;
  const method=()=>METHOD;

  let dlg,done=null,qs=[],k=0,score=0,essai=null,rep=[];
  function build(){
    dlg=document.createElement('dialog');dlg.className='hab-dlg';dlg.setAttribute('aria-labelledby','hab-t');
    dlg.addEventListener('cancel',()=>{done=null;});
    dlg.addEventListener('click',e=>{if(e.target===dlg)dlg.close();});
    document.body.appendChild(dlg);
  }
  function frame(inner){dlg.innerHTML=`<div class="hab-in"><button type="button" class="hab-x" aria-label="Fermer">×</button>${inner}</div>`;dlg.querySelector('.hab-x').onclick=()=>dlg.close();}
  function intro(){
    if(essai){frame(`<span class="eyebrow">Essai gratuit · grade CPL pendant 24 h</span><h2 id="hab-t">Passerelle Ingénieur</h2>
      <p>Réussis ce test de qualification et le serveur t’ouvre <b>24 heures de grade CPL</b> : mode Ingénieur, outils de dimensionnement, maths, repères, fluides visqueux, stabilité et moteurs civils.</p>
      <p>${N} questions tirées par le serveur, une par thème : ${THEMES.map(t=>THEME_LBL[t].toLowerCase()).join(', ')}. Il faut ${PASS} bonnes réponses sur ${N}. Le test est corrigé par le serveur.</p>
      <p class="hab-small">Un essai par navigateur et par mois. Un cookie technique retient la session d’essai et le fait que l’essai a servi ; rien d’autre n’est enregistré.</p>
      <div class="hab-nav"><button type="button" class="btn" data-x>Plus tard</button><button type="button" class="btn primary" data-go>Commencer le test</button></div>`);
      dlg.querySelector('[data-x]').onclick=()=>dlg.close();
      dlg.querySelector('[data-go]').onclick=()=>{qs=essai.ids.map(id=>BANK[id]).map(x=>{const order=shuffle(x.o.map((_,i)=>i));return {t:x.t,q:x.q,o:order.map(i=>x.o[i]),a:order.indexOf(x.a),w:x.w,ord:order};});
        k=0;score=0;rep=[];ask();};
      dlg.querySelector('[data-go]').focus();return;}
    frame(`<span class="eyebrow">Mode Ingénieur · accès sur badge</span><h2 id="hab-t">Test d’habilitation Ingénieur</h2>${MODES}
      <p>${N} questions, une par thème : ${THEMES.map(t=>THEME_LBL[t].toLowerCase()).join(', ')}. Il faut ${PASS} bonnes réponses sur ${N}. Chaque réponse est expliquée, et les questions changent à chaque essai.</p>
      <p class="hab-small">Le badge est gardé sur cet appareil, sans compte ni donnée envoyée. À l’ouverture des <a href="tarifs.html">grades</a>, le mode Ingénieur demandera aussi le grade CPL ; il est gratuit pendant la phase de lancement.</p>
      <div class="hab-nav"><button type="button" class="btn" data-x>Rester en Débutant</button><button type="button" class="btn primary" data-go>Commencer le test</button></div>`);
    dlg.querySelector('[data-x]').onclick=()=>dlg.close();
    dlg.querySelector('[data-go]').onclick=()=>{
      qs=THEMES.map(t=>shuffle(BANK.filter(x=>x.t===t))[0]).map(x=>{const order=shuffle(x.o.map((_,i)=>i));return {t:x.t,q:x.q,o:order.map(i=>x.o[i]),a:order.indexOf(x.a),w:x.w,ord:order};});
      k=0;score=0;rep=[];ask();};
    dlg.querySelector('[data-go]').focus();
  }
  function ask(){
    const x=qs[k];
    frame(`<div class="hab-bar"><span>Question ${k+1} / ${N} · ${THEME_LBL[x.t]}</span><span>${score} / ${k}</span></div>
      <div class="hab-prog" aria-hidden="true"><i style="width:${k/N*100}%"></i></div>
      <h2 id="hab-t" class="hab-q">${esc(x.q)}</h2>
      <div class="hab-opts" role="group" aria-label="Réponses">${x.o.map((t,i)=>`<button type="button" class="hab-opt" data-i="${i}">${esc(t)}</button>`).join('')}</div>
      <p class="hab-why" aria-live="polite"></p><div class="hab-nav"></div>`);
    const opts=[...dlg.querySelectorAll('.hab-opt')];opts[0].focus();
    opts.forEach(b=>b.onclick=()=>{
      const i=+b.dataset.i,right=i===x.a;if(right)score++;rep[k]=x.ord?x.ord[i]:i;
      opts.forEach(o=>{o.disabled=true;if(+o.dataset.i===x.a)o.classList.add('right');});
      if(!right)b.classList.add('wrong');
      dlg.querySelector('.hab-why').innerHTML=`<b>${right?'Exact.':'Pas tout à fait.'}</b> ${esc(x.w)}`;
      const last=k===N-1,nav=dlg.querySelector('.hab-nav');
      nav.innerHTML=`<button type="button" class="btn primary">${last?'Voir le résultat':'Question suivante'}</button>`;
      const nb=nav.querySelector('button');nb.onclick=()=>{if(last)result();else{k++;ask();}};nb.focus();
    });
  }
  function result(){
    if(essai&&score>=PASS){
      frame(`<h2 id="hab-t">${score} / ${N} : vérification par le serveur…</h2><p aria-live="polite">Un instant.</p>`);
      fetch('/api/essai',{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json'},body:JSON.stringify({jeton:essai.jeton,reponses:rep})})
        .then(r=>r.json()).then(j=>{
          if(!j.ok){frame(`<h2 id="hab-t">Essai non ouvert</h2><p class="fb bad" role="alert">${esc(j.texte||'Le serveur a refusé la demande.')}</p><div class="hab-nav"><a class="btn" href="tarifs.html#grade-cpl">Voir les grades</a><button type="button" class="btn primary" data-x>Fermer</button></div>`);dlg.querySelector('[data-x]').onclick=()=>dlg.close();return;}
          save(score);essai=null;
          const fin=new Date(j.expire*1000).toLocaleString('fr-FR',{weekday:'long',hour:'2-digit',minute:'2-digit'});
          frame(`<div class="hab-win"><div class="hab-badge" aria-hidden="true"><img src="assets/brand/logo-cpsaero-mark.svg" alt=""><span>Ingénieur Certifié CPSAero</span></div>
            <h2 id="hab-t">Essai CPL ouvert : ${score} / ${N}</h2><p>Tu as accès au grade CPL jusqu’à <b>${esc(fin)}</b>. Recharge la page pour voir le contenu débloqué.</p></div>
            <section class="method-box"><h3>La méthode d’approche de l’ingénieur</h3>${METHOD}</section>
            <div class="hab-nav"><button type="button" class="btn primary" data-in>Recharger la page</button></div>`);
          dlg.querySelector('[data-in]').onclick=()=>location.reload();dlg.querySelector('[data-in]').focus();
          document.dispatchEvent(new CustomEvent('cps:badge',{detail:{ok:true,score}}));
        }).catch(()=>{frame(`<h2 id="hab-t">Serveur injoignable</h2><p>Réessaie dans un instant.</p><div class="hab-nav"><button type="button" class="btn primary" data-x>Fermer</button></div>`);dlg.querySelector('[data-x]').onclick=()=>dlg.close();});
      return;}
    if(score>=PASS){
      save(score);
      frame(`<div class="hab-win"><div class="hab-badge" aria-hidden="true"><img src="assets/brand/logo-cpsaero-mark.svg" alt=""><span>Ingénieur Certifié CPSAero</span></div>
        <h2 id="hab-t">Badge obtenu : ${score} / ${N}</h2>
        <p>Le mode Ingénieur est activé sur cet appareil : démonstrations complètes et calculateurs de dimensionnement. Avant d’entrer, voici comment un ingénieur aborde un problème.</p></div>
        <section class="method-box"><h3>La méthode d’approche de l’ingénieur</h3>${METHOD}</section>
        <div class="hab-nav"><button type="button" class="btn primary" data-in>Entrer en mode Ingénieur</button></div>`);
      dlg.querySelector('[data-in]').onclick=()=>dlg.close();dlg.querySelector('[data-in]').focus();
      const cb=done;done=null;
      document.dispatchEvent(new CustomEvent('cps:badge',{detail:{ok:true,score}}));
      if(cb)cb(true);
    }else{
      frame(`<h2 id="hab-t">${score} / ${N} : pas encore</h2><p>Il faut ${PASS} bonnes réponses. Relis les explications, puis retente ta chance : les questions changent à chaque essai.</p>
        <p class="hab-small">Pour réviser : <a href="aerodynamique.html">aérodynamique</a>, <a href="thermodynamique.html">thermodynamique</a>, <a href="mecanique.html">mécanique</a>, <a href="lexique.html">lexique</a>.</p>
        <div class="hab-nav"><button type="button" class="btn" data-x>Plus tard</button><button type="button" class="btn primary" data-re>Repasser le test</button></div>`);
      dlg.querySelector('[data-re]').onclick=essai?trial:intro;dlg.querySelector('[data-x]').onclick=()=>dlg.close();dlg.querySelector('[data-re]').focus();
    }
  }
  function show(){if(!dlg.open){try{dlg.showModal();}catch(e){dlg.setAttribute('open','');}}}
  function open(cb){if(!dlg)build();essai=null;done=cb||null;intro();show();}
  // essai gratuit (grades ouverts) : le serveur fournit les questions et dit si l'essai est possible
  function trial(){
    if(!dlg)build();done=null;essai=null;
    frame(`<h2 id="hab-t">Passerelle Ingénieur</h2><p aria-live="polite">Préparation du test…</p>`);show();
    fetch('/api/essai',{credentials:'same-origin',headers:{accept:'application/json'}}).then(r=>{if(!r.ok)throw 0;return r.json();}).then(j=>{
      if(j.dispo){essai=j;intro();return;}
      if(j.raison==='ouvert'){dlg.close();open();return;}
      frame(`<span class="eyebrow">Grade CPL · élève ingénieur</span><h2 id="hab-t">Contenu du grade CPL</h2><p>${esc(j.texte||'')}</p>
        <div class="hab-nav"><a class="btn" href="acces.html">J’ai un code d’accès</a><a class="btn primary" href="tarifs.html?acces=cpl#grade-cpl">Voir les grades</a></div>`);
    }).catch(()=>{dlg.close();location.href='tarifs.html?acces=cpl#grade-cpl';});
  }
  window.CPS_HAB={ok,open,trial,reset,method,read,BANK,PASS,N,THEMES,MODES};
})();
