/* CPS Aero — rendu des équations + infobulles des variables.
   Tout élément portant data-tex="..." est rendu par KaTeX (sortie MathML native).
   Couleurs : \vv{} variable (cyan), \kk{} constante (ambre), \rr{} résultat (vert). data-display = équation centrée.
   Infobulles : chaque symbole d'une formule qui figure dans un dictionnaire de la page (.dict-i) devient survolable
   (ou cliquable sur mobile). L'infobulle rappelle la définition et l'unité, et renvoie à la première définition. */
(function(){
  const MAC={'\\vv':'\\textcolor{##06B6D4}{#1}','\\kk':'\\textcolor{##F59E0B}{#1}','\\rr':'\\textcolor{##22C55E}{#1}'};
  function render(root){
    (root||document).querySelectorAll('[data-tex]').forEach(el=>{
      if(el.dataset.done)return;
      const s=el.getAttribute('data-tex');el.dataset.done='1';
      if(window.katex){try{el.innerHTML=window.katex.renderToString(s,{output:'mathml',throwOnError:false,displayMode:el.hasAttribute('data-display'),macros:Object.assign({},MAC),strict:false});return;}catch(e){}}
      el.textContent=s.replace(/\\(vv|kk|rr)\{/g,'{').replace(/\\(dfrac|frac)\{([^}]*)\}\{([^}]*)\}/g,'($2)/($3)').replace(/\\[a-zA-Z]+/g,' ').replace(/[{}]/g,'');
      el.classList.add('tex-fb');
    });
  }

  /* ---------- Infobulles ---------- */
  // Symboles courants : utilisés seulement si la page ne les définit pas elle-même
  const GLOBAL={'g':['Accélération de la pesanteur','≈ 9,81 m/s²'],'m':['Masse','kg'],'ρ':['Masse volumique (de l’air ou d’un fluide)','kg/m³'],
    'π':['Le nombre pi','≈ 3,1416'],'σ':['Constante de Stefan-Boltzmann','5,67 × 10⁻⁸ W/(m²·K⁴)'],'α':['Incidence (angle)','rad ou °']};
  const key=el=>{const c=el.cloneNode(true);c.querySelectorAll('annotation').forEach(a=>a.remove());return c.textContent.replace(/\s+/g,'');};
  let box=null,cur=null,hideT=null,pinned=false;
  function dictOf(scope){
    const D={};
    scope.querySelectorAll('.dict-i').forEach((it,i)=>{
      const s=it.querySelector('.dict-s');if(!s)return;
      const m=s.querySelector('math')||s;const k=key(m);if(!k)return;
      const p=it.querySelector('p'),u=it.querySelector('.dict-u');
      if(!D[k]){if(!it.id)it.id='def-'+i;D[k]={d:p?p.textContent:'',u:u?u.textContent:'',id:it.id,el:it};}
      else if(!it.querySelector('.dict-prev')){const a=document.createElement('a');a.className='dict-prev';a.href='#'+D[k].id;a.textContent='Déjà défini plus haut ↑';(p||it).after(a);}
    });
    return D;
  }
  function show(el){
    clearTimeout(hideT);cur&&cur.classList.remove('on');cur=el;el.classList.add('on');
    if(!box){box=document.createElement('div');box.className='tipbox';box.setAttribute('role','tooltip');box.id='cps-tip';document.body.appendChild(box);
      box.addEventListener('mouseenter',()=>clearTimeout(hideT));box.addEventListener('mouseleave',()=>{if(!pinned)hide();});}
    const t=el._tip;
    const near=t.el&&el.closest('.fbk,.dict,.lab-card,.formula')&&el.closest('.fbk,.dict,.lab-card,.formula')===t.el.closest('.fbk,.dict,.lab-card,.formula');
    box.innerHTML=`<b>${t.s}</b>${t.d}${t.u?`<br><span class="u">${t.u}</span>`:''}${t.id&&!near?`<a href="#${t.id}">Voir sa définition dans le cours ↑</a>`:''}${t.href?`<a class="tip-ext" href="${t.href}">Voir dans le lexique →</a>`:''}`;
    box.hidden=false;
    const r=el.getBoundingClientRect(),bw=box.offsetWidth,bh=box.offsetHeight;
    let x=Math.min(Math.max(8,r.left+r.width/2-bw/2),innerWidth-bw-8),y=r.top-bh-10;if(y<8)y=r.bottom+10;
    box.style.left=x+'px';box.style.top=y+'px';
    el.setAttribute('aria-describedby','cps-tip');
    const a=box.querySelector('a:not(.tip-ext)');if(a)a.onclick=()=>{hide(true);const d=document.getElementById(t.id);if(d){d.classList.add('flash');setTimeout(()=>d.classList.remove('flash'),1600);}};
  }
  function hide(force){if(pinned&&!force)return;pinned=false;if(box)box.hidden=true;if(cur){cur.classList.remove('on');cur.removeAttribute('aria-describedby');}cur=null;}
  function attach(el,t){
    if(el._tip)return;el._tip=t;el.classList.add('vtip');el.setAttribute('tabindex','0');el.setAttribute('role','button');el.setAttribute('aria-label',t.s+' : '+t.d);
    el.addEventListener('mouseenter',()=>{if(!pinned)show(el);});
    el.addEventListener('mouseleave',()=>{if(!pinned)hideT=setTimeout(()=>hide(),180);});
    el.addEventListener('focus',()=>show(el));el.addEventListener('blur',()=>{if(!pinned)hideT=setTimeout(()=>hide(),180);});
    el.addEventListener('click',e=>{e.stopPropagation();if(cur===el&&pinned){hide(true);return;}show(el);pinned=true;});
    el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();show(el);pinned=true;}});
  }
  function tips(root){
    const scope=root||document,D=dictOf(scope);
    const look=k=>D[k]?{d:D[k].d,u:D[k].u,id:D[k].id,el:D[k].el}:(GLOBAL[k]?{d:GLOBAL[k][0],u:GLOBAL[k][1]}:null);
    scope.querySelectorAll('math').forEach(m=>{
      if(m.closest('.dict-s'))return;
      m.querySelectorAll('mstyle,msub,msubsup,mi').forEach(el=>{
        if(el.closest('.vtip'))return;
        let k=key(el),t=look(k);
        if(!t&&el.tagName.toLowerCase()==='mi'&&k==='Δ'){const n=el.nextElementSibling;if(n){const k2=k+key(n),t2=look(k2);if(t2){attach(el,Object.assign({s:k2},t2));attach(n,Object.assign({s:k2},t2));return;}}}
        if(t&&k)attach(el,Object.assign({s:k},t));
      });
    });
  }
  /* Termes techniques du texte (glossaire généré au build) */
  function gloss(root){
    const G=window.CPS_GLOSS||{};
    (root||document).querySelectorAll('.gl[data-k]').forEach(el=>{const g=G[el.dataset.k];if(!g)return;
      attach(el,{s:g[0],d:g[1],u:g[2]||'',href:'lexique.html#'+el.dataset.k});el.classList.remove('vtip');el.classList.add('gl-on');});
  }
  gloss();
  document.addEventListener('click',()=>hide(true));
  document.addEventListener('keydown',e=>{if(e.key==='Escape')hide(true);});
  window.addEventListener('scroll',()=>{if(!pinned)hide();},{passive:true});

  /* ---------- Formules toujours visibles en entier ----------
     Si une formule dépasse la largeur disponible, on la réécrit sans changer son sens :
     1) équations multiples (\qquad) empilées ; 2) passage en multi-ligne aligné sur les signes
     d'égalité / d'implication ; 3) en dernier recours, légère réduction (jamais sous 80 %).
     Recalculé au redimensionnement et à l'ouverture d'un bloc repliable. */
  const REL=['\\Rightarrow','\\approx','\\simeq','\\equiv','\\leq','\\geq','\\neq','\\to','=','<','>'];
  function topSplit(s,seps){ // découpe au niveau 0 (hors accolades et \left...\right)
    const out=[];let d=0,lr=0,cur='',i=0;
    while(i<s.length){
      const c=s[i];
      if(c==='\\'){const m=s.slice(i).match(/^\\[a-zA-Z]+|^\\./);const cmd=m?m[0]:'\\';
        if(cmd==='\\left')lr++;else if(cmd==='\\right')lr--;
        if(d===0&&lr===0){const sp=seps.find(x=>x.startsWith('\\')&&x===cmd);if(sp){out.push([cur,sp]);cur='';i+=cmd.length;continue;}}
        cur+=cmd;i+=cmd.length;continue;}
      if(c==='{')d++;else if(c==='}')d--;
      if(d===0&&lr===0&&seps.includes(c)){out.push([cur,c]);cur='';i++;continue;}
      cur+=c;i++;
    }
    out.push([cur,null]);return out;
  }
  function stacked(src){const parts=topSplit(src,['\\qquad']).map(p=>p[0].trim()).filter(Boolean);return parts.length>1?parts:null;}
  function aligned(src){
    const parts=topSplit(src,REL);if(parts.length<3)return null; // au moins deux relations pour gagner de la place
    let lines=[parts[0][0].trim()+' &'+parts[0][1]+' '+parts[1][0].trim()],k=1;
    while(k<parts.length-1){lines.push('&'+parts[k][1]+' '+parts[k+1][0].trim());k++;}
    return '\\begin{aligned}'+lines.join(' \\\\ ')+'\\end{aligned}';
  }
  function opSplit(s){ // termes au niveau 0, hors accolades et parenthèses, pour couper une ligne trop longue
    const out=[];let d=0,pr=0,lr=0,cur='',op=null,i=0;
    while(i<s.length){
      const c=s[i];
      if(c==='\\'){const m=s.slice(i).match(/^\\[a-zA-Z]+|^\\./);const cmd=m?m[0]:'\\';
        if(cmd==='\\left')lr++;else if(cmd==='\\right')lr--;
        if(d===0&&pr===0&&lr===0&&(cmd==='\\times'||cmd==='\\cdot')&&cur.trim()){out.push([op,cur]);op=cmd;cur='';i+=cmd.length;continue;}
        cur+=cmd;i+=cmd.length;continue;}
      if(c==='{')d++;else if(c==='}')d--;else if(c==='('||c==='[')pr++;else if(c===')'||c===']')pr--;
      if(d===0&&pr===0&&lr===0&&(c==='+'||c==='-')&&cur.trim()){out.push([op,cur]);op=c;cur='';i++;continue;}
      cur+=c;i++;
    }
    out.push([op,cur]);return out;
  }
  function breakRhs(rhs,n){ // regroupe les termes en n lignes de longueur proche
    const t=opSplit(rhs);if(t.length<2||n<2)return null;
    const len=x=>x.replace(/\\[a-zA-Z]+/g,'x').length;const total=t.reduce((a,x)=>a+len(x[1])+2,0),target=total/n;
    const lines=[];let cur='',acc=0;
    t.forEach(([op,term],j)=>{const piece=(op?op+' ':'')+term.trim();
      if(j>0&&acc>=target*0.85&&lines.length<n-1){lines.push(cur);cur='\\quad '+piece;acc=len(term);}else{cur+=(cur?' ':'')+piece;acc+=len(term)+2;}});
    lines.push(cur);return lines.length>1?lines:null;
  }
  function alignedN(src,n){ // multi-ligne : relations alignées, et côtés droits longs coupés aux opérateurs
    const parts=topSplit(src,REL);if(parts.length<2)return null;
    const rows=[];const lhs=parts[0][0].trim();
    for(let k=0;k<parts.length-1;k++){
      const rel=parts[k][1],rhs=parts[k+1][0].trim();const br=n>1?breakRhs(rhs,n):null;
      const first=(k===0?lhs+' ':'')+'&'+rel+' ';
      if(br){rows.push(first+br[0]);br.slice(1).forEach(x=>rows.push('&'+x));}else rows.push(first+rhs);
    }
    return '\\begin{aligned}'+rows.join(' \\\\ ')+'\\end{aligned}';
  }
  function variants(src){
    const v=[];const st=stacked(src);const pieces=st||[src];
    const join=f=>pieces.length>1?'\\begin{gathered}'+pieces.map(f).join(' \\\\[4pt] ')+'\\end{gathered}':f(pieces[0]);
    if(st)v.push(join(x=>x));
    v.push(join(x=>aligned(x)||x));
    for(const n of [2,3,4])v.push(join(x=>alignedN(x,n)||x));
    return [...new Set(v)].filter(x=>x!==src);
  }
  const blockOf=el=>{let c=el.parentElement;while(c&&getComputedStyle(c).display.startsWith('inline'))c=c.parentElement;return c;};
  const innerW=m=>{const sem=m.querySelector('semantics');const t=sem&&sem.firstElementChild||m;return t.getBoundingClientRect().width;};
  function draw(span,tex,disp){
    if(!window.katex)return null;
    try{span.innerHTML=window.katex.renderToString(tex,{output:'mathml',throwOnError:false,displayMode:disp,macros:Object.assign({},MAC),strict:false});}catch(e){return null;}
    const m=span.querySelector('math');return m;
  }
  function fitOne(k){
    const m0=k.querySelector('math');if(!m0)return;
    let span=k.parentElement;if(!span)return;
    if(span.children.length!==1||span.textContent.trim()!==k.textContent.trim()){const w=document.createElement('span');w.className='tex-wrap';k.before(w);w.appendChild(k);span=w;}
    if(!span.dataset.src){const a=m0.querySelector('annotation');if(!a)return;span.dataset.src=a.textContent;span.dataset.disp=m0.getAttribute('display')==='block'?'1':'';}
    const host=getComputedStyle(span).display.startsWith('inline')?blockOf(span):span;if(!host)return;
    const cs=getComputedStyle(host);const avail=host.clientWidth-(parseFloat(cs.paddingLeft)||0)-(parseFloat(cs.paddingRight)||0)-2;
    if(avail<=0)return;
    const src=span.dataset.src,disp=span.dataset.disp==='1';
    span.style.fontSize='';span.classList.remove('tex-fit');
    let m=span.dataset.fitted?draw(span,src,disp):m0;delete span.dataset.fitted;
    const ok=mm=>mm&&innerW(mm)<=avail&&host.scrollWidth<=host.clientWidth+1;
    if(!m||ok(m))return;
    for(const v of variants(src)){m=draw(span,v,true);span.dataset.fitted='1';span.classList.add('tex-fit');if(ok(m))return;}
    for(const f of [0.92,0.86,0.8,0.74,0.68]){span.style.fontSize=(f*100)+'%';if(ok(span.querySelector('math')))return;}
  }
  function fit(root){[...(root||document).querySelectorAll('.katex')].forEach(fitOne);}
  let rT=null;
  window.addEventListener('resize',()=>{clearTimeout(rT);rT=setTimeout(()=>{fit(document);tips(document);},150);});
  document.addEventListener('toggle',e=>{if(e.target.tagName==='DETAILS'&&e.target.open){fit(e.target);tips(e.target);}},true);
  window.CPS_TEX={render,tips,fit};
  render();fit();tips();
})();
