/* CPS Aero — Hangar 3D « de l'avion au moteur »
   Deux duos : Rafale ↔ M88 et Mirage 2000 ↔ M53. Trois étapes : A l'avion, B l'intégration, C le moteur seul en coupe.
   Modèles construits en code à partir des dimensions publiques (mètres). Aucun fichier 3D externe. */
(function(){
const $=id=>document.getElementById(id);
const box=$('h-box'); if(!box)return;
const fail=$('h-fail');
const failNow=()=>{fail.hidden=false;document.getElementById('hangar').classList.add('no3d');};
if(!window.THREE){failNow();return;}
const T=THREE;
let renderer;
try{renderer=new T.WebGLRenderer({canvas:$('h3d'),antialias:true,alpha:true});}catch(e){failNow();return;}
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
renderer.outputEncoding=T.sRGBEncoding;renderer.setClearColor(0,0);

/* ---------- Données des duos ---------- */
const DUOS={
  rafale:{avion:'Rafale',moteur:'M88-2',nEng:2,Fsec:50,Fpc:75,center:new T.Vector3(-5.65,-0.05,0),
    engine:{hp:6,single:false,sL:1,sR:1}},
  mirage:{avion:'Mirage 2000',moteur:'M53-P2',nEng:1,Fsec:64.3,Fpc:95.1,center:new T.Vector3(-4.65,0,0),
    engine:{hp:5,single:true,sL:5.07/3.54,sR:0.53/0.345}}
};
const SC=0.4; // les avions de ligne sont réduits pour tenir dans la même scène que les chasseurs
const COMMON={
  pc:{n:'Post-combustion',c:'Canal de réchauffe',t:'Après le mélange des deux flux, on réinjecte du kérosène et on le brûle une seconde fois. Grosse poussée, grosse consommation : on la réserve au décollage, au supersonique et au combat.'},
  tuyere:{n:'Tuyère à section variable',c:'Éjection',t:'Ses volets s’ouvrent en post-combustion pour laisser passer des gaz plus chauds et plus volumineux. La régulation règle leur position en permanence.'},
  chambre:{n:'Chambre de combustion annulaire',c:'Cœur',t:'Le kérosène y brûle. Les aubes de turbine qui suivent reçoivent des gaz plus chauds que leur propre température de fusion : elles sont refroidies par de l’air prélevé au compresseur.'},
  secondaire:{n:'Canal secondaire',c:'Double flux',t:'Une petite partie de l’air contourne le cœur. Il refroidit le moteur et rejoint les gaz chauds avant la post-combustion.'}
};
const INFO={
  rafale:Object.assign({},COMMON,{
    soufflante:{n:'Soufflante (compresseur BP)',c:'Corps basse pression',t:'Trois étages qui aspirent tout l’air. Environ 23 % contourne ensuite le cœur : taux de dilution 0,3. Elle est entraînée par la turbine BP.'},
    hp:{n:'Compresseur HP',c:'Corps haute pression',t:'Six étages, sur un autre arbre que la soufflante. Ils tournent plus vite qu’elle. Avec la soufflante, l’air est comprimé environ 24 fois.'},
    thp:{n:'Turbine HP',c:'Corps haute pression',t:'Un étage, la pièce la plus sollicitée du moteur. Elle entraîne le compresseur HP par un arbre creux.'},
    tbp:{n:'Turbine BP',c:'Corps basse pression',t:'Un étage. Elle entraîne la soufflante par un arbre qui passe à l’intérieur de l’arbre HP : c’est le « double corps ».'},
    fadec:{n:'FADEC',c:'Régulation numérique',t:'Calculateur à pleine autorité, en deux voies redondantes. Le pilote demande une poussée ; le FADEC dose le carburant, règle les géométries variables et protège le moteur de ses limites.'},
    entrees:{n:'Entrées d’air',c:'Rafale',t:'Sous le cockpit, de chaque côté. Des conduits en S mènent l’air aux moteurs en cachant les soufflantes, ce qui réduit l’écho radar.'},
    moteurs:{n:'Deux M88-2',c:'Rafale',t:'Côte à côte au fond du fuselage. Deux moteurs, c’est une sécurité : on rentre sur un seul. Environ 150 kN de poussée au total avec la post-combustion.'},
    aile:{n:'Aile delta et canards',c:'Rafale',t:'Aile en triangle et petits plans avant (canards). L’ensemble, instable par construction, est piloté par des commandes de vol électriques : très manœuvrant.'},
    tuyeres:{n:'Tuyères',c:'Rafale',t:'Les deux sorties des M88. En post-combustion, on voit les diamants de choc dans les jets.'}}),
  mirage:Object.assign({},COMMON,{
    soufflante:{n:'Compresseur BP (3 étages)',c:'Corps unique',t:'Les trois premiers étages jouent le rôle de soufflante : après eux, une partie de l’air contourne le cœur. Sur le M53, ils sont sur le même arbre que le compresseur HP : un seul corps.'},
    hp:{n:'Compresseur HP (5 étages)',c:'Corps unique',t:'Cinq étages sur le même arbre que les trois premiers. Taux de compression d’environ 10 : beaucoup moins que le M88, mais une architecture plus simple.'},
    thp:{n:'Turbine (2 étages)',c:'Corps unique',t:'Deux étages de turbine entraînent tous les compresseurs par un seul arbre. Plus simple et robuste, mais chaque étage ne tourne pas à sa vitesse idéale.'},
    tbp:{n:'Turbine (2 étages)',c:'Corps unique',t:'Le M53 n’a qu’un arbre : ces deux étages de turbine entraînent les huit étages de compresseur.'},
    fadec:{n:'Régulation électronique',c:'Régulation',t:'Le M53 a été l’un des premiers moteurs militaires français à régulation électronique : un calculateur gère le carburant et la tuyère selon la demande du pilote.'},
    entrees:{n:'Entrées d’air et « souris »',c:'Mirage 2000',t:'De chaque côté du fuselage. Le cône mobile, surnommé la « souris », règle l’entrée de l’air en supersonique pour ralentir l’écoulement sans pertes excessives.'},
    moteurs:{n:'Un M53-P2',c:'Mirage 2000',t:'Un seul moteur, au centre du fuselage arrière, long d’environ 5 m. Environ 95 kN avec la post-combustion.'},
    aile:{n:'Aile delta',c:'Mirage 2000',t:'Grande aile en triangle, sans empennage horizontal. Les commandes de vol électriques rendent maniable cet avion légèrement instable.'},
    tuyeres:{n:'Tuyère',c:'Mirage 2000',t:'Une seule tuyère, à volets, qui s’ouvre en post-combustion.'}})
};
const TP={
  rafale:{soufflante:[['Sortie','≈ 150 à 200 °C, pression × 4'],['Matériaux','alliages de titane']],hp:[['Sortie','≈ 500 °C, pression totale × 24'],['Matériaux','titane puis superalliages base nickel']],
    chambre:[['Sortie','≈ 1 850 K, près de 1 580 °C'],['Matériaux','superalliages, barrière thermique céramique']],thp:[['Entrée','≈ 1 850 K'],['Matériaux','aubes monocristallines en superalliage AM1, refroidies']],
    tbp:[['Entrée','≈ 1 300 à 1 500 K'],['Matériaux','superalliages base nickel']],pc:[['Température','jusqu’à ≈ 2 000 K'],['Effet','≈ 50 → 75 kN par moteur']],
    tuyere:[['Matériaux','superalliages, certains volets en composite céramique (CMC)']],fadec:[['Architecture','deux voies redondantes']]},
  mirage:{hp:[['Compression','≈ 10 au total']],pc:[['Effet','≈ 64 → 95 kN']],thp:[['Architecture','2 étages, un seul arbre']]}
};
/* Duos civils : données servies par assets/premium/cpl/hangar-civil.js (grade CPL quand les grades sont ouverts) */
const CIV=window.CPS_HANGAR_CIVIL||null;
if(CIV){Object.assign(DUOS,CIV.DUOS);Object.assign(INFO,CIV.INFO);Object.assign(TP,CIV.TP);}
const CIVIL_KEYS=Object.keys(DUOS).filter(k=>DUOS[k].civil);
const LBL_AIR={
  rafale:[['entrees',[2.6,-0.75,1.35]],['moteurs',[-5.5,0.55,0]],['aile',[-4.5,-0.3,4.2]],['tuyeres',[-7.6,-0.4,-0.9]]],
  mirage:[['entrees',[1.6,-0.4,1.2]],['moteurs',[-4.6,0.65,0]],['aile',[-4.3,-0.3,3.4]],['tuyeres',[-7.4,-0.4,0]]]
};

/* ---------- Scène ---------- */
const scene=new T.Scene();
const camera=new T.PerspectiveCamera(32,1,0.05,400);
scene.add(new T.HemisphereLight(0xe6edf5,0x2a323b,0.95));
const dl=new T.DirectionalLight(0xffffff,0.85);dl.position.set(4,9,10);scene.add(dl);
const dl2=new T.DirectionalLight(0xa9c2de,0.35);dl2.position.set(-6,-4,-8);scene.add(dl2);
const pivot=new T.Group();scene.add(pivot);
const pickables=[];const allMats={};
function M(part,o){const m=new T.MeshStandardMaterial(Object.assign({color:0xa8b3bf,metalness:0.55,roughness:0.42,side:T.DoubleSide},o||{}));
  m.userData.base=m.emissive.clone();m.userData.baseI=m.emissiveIntensity;(allMats[part]=allMats[part]||[]).push(m);return m;}
function add(parent,part,geo,mat){const me=new T.Mesh(geo,mat);me.userData.part=part;parent.add(me);pickables.push(me);return me;}
const CUT=Math.PI*1.5;
function lathe(pts,full,seg){return new T.LatheGeometry(pts.map(p=>new T.Vector2(p[0],p[1])),seg||64,0,full?Math.PI*2:CUT);}
const bladeGeo=new T.BoxGeometry(1,1,1);

/* ---------- Moteur paramétrable (M88 ou M53) ---------- */
function buildEngine(spec,opt){
  const g=new T.Group(),spools={lp:[],hp:[]};const cut=opt.cut;
  const part=p=>opt.cutParts?p:'moteurs', mk=(p,o)=>M(part(p),o);
  const casing=mk('soufflante',{color:0xbac4ce,metalness:0.6,roughness:0.36});
  add(g,part('soufflante'),lathe([[0.36,0],[0.345,0.08],[0.345,0.65]],!cut),casing);
  add(g,part('secondaire'),lathe([[0.345,0.65],[0.345,2.55]],!cut),mk('secondaire',{color:0xbac4ce,metalness:0.6,roughness:0.36}));
  add(g,part('pc'),lathe([[0.345,2.55],[0.335,3.25]],!cut),mk('pc',{color:0xa9b2bb,metalness:0.6,roughness:0.4}));
  add(g,part('soufflante'),lathe([[0,0.0],[0.06,0.05],[0.12,0.16],[0.17,0.62]],true,40),mk('soufflante',{color:0x6f7a86}));
  add(g,part('secondaire'),lathe([[0.255,0.66],[0.262,0.75],[0.262,2.4],[0.25,2.5]],!cut),mk('secondaire',{color:0x8b98a6,metalness:0.5,roughness:0.45}));
  add(g,part('hp'),lathe([[0.17,0.62],[0.168,1.4]],true,40),mk('hp',{color:0x6f7a86}));
  add(g,part('chambre'),lathe([[0.168,1.4],[0.168,1.8]],true,40),mk('chambre',{color:0x6f7a86}));
  const liner=mk('chambre',{color:0x7d6a58,metalness:0.4,roughness:0.55});
  add(g,part('chambre'),lathe([[0.21,1.4],[0.18,1.47],[0.18,1.8],[0.25,1.8],[0.25,1.47],[0.23,1.4]],!cut),liner);
  const flameMat=new T.MeshBasicMaterial({color:0xff7a2a,transparent:true,opacity:0.5,side:T.DoubleSide,depthWrite:false});
  g.add(new T.Mesh(lathe([[0.19,1.5],[0.24,1.5],[0.24,1.78],[0.19,1.78],[0.19,1.5]],!cut),flameMat));
  add(g,part('tbp'),lathe([[0.168,1.8],[0.16,2.12],[0.12,2.3],[0,2.55]],true,40),mk('tbp',{color:0x6f7a86}));
  const fh=mk('pc',{color:0x6f7a86});
  [0.14,0.25].forEach(rr=>{const t=add(g,part('pc'),new T.TorusGeometry(rr,0.01,6,48),fh);t.rotation.x=Math.PI/2;t.position.y=2.66;});
  const abMat=new T.MeshBasicMaterial({color:0xff9a3c,transparent:true,opacity:0,side:T.DoubleSide,depthWrite:false});
  g.add(new T.Mesh(lathe([[0.1,2.7],[0.3,3.0],[0.31,3.25],[0.27,3.54]],true,40),abMat));
  const nozMat=mk('tuyere',{color:0x8d8579,metalness:0.6,roughness:0.4});
  let noz=null;
  function nozzle(open){if(noz){g.remove(noz);noz.geometry.dispose();const k=pickables.indexOf(noz);if(k>=0)pickables.splice(k,1);}
    noz=add(g,part('tuyere'),lathe([[0.335,3.25],[0.24+0.07*open,3.42],[0.27+0.07*open,3.54]],!cut),nozMat);}
  nozzle(0);
  if(opt.cutParts){const fb=add(g,'fadec',new T.BoxGeometry(0.1,0.32,0.16),M('fadec',{color:0x33424f,metalness:0.3,roughness:0.6}));fb.position.set(-0.4,1.2,0);}
  function ring(p0,mat,n,y,r0,r1,chord,twist,spool){const rg=new T.Group();g.add(rg);
    for(let b=0;b<n;b++){const a=b/n*Math.PI*2;const m=new T.Mesh(bladeGeo,mat);m.userData.part=p0;m.scale.set(r1-r0,chord,0.012);const rm=(r0+r1)/2;
      m.position.set(rm*Math.cos(a),y,rm*Math.sin(a));m.rotation.set(twist,-a,0,'YXZ');rg.add(m);pickables.push(m);}
    if(spool)spools[spool].push(rg);}
  const lpMat=mk('soufflante',{color:0xa9c3da,metalness:0.75,roughness:0.28});
  const hpMat=spec.single?lpMat:mk('hp',{color:0xdcc79e,metalness:0.75,roughness:0.3});
  const stMat=mk('hp',{color:0x7f8b98});
  const tHP=mk('thp',{color:0xb08f6f}),tLP=mk('tbp',{color:0x9a8775});
  const hpSpool=spec.single?'lp':'hp';
  for(let i=0;i<3;i++){const y=0.16+i*0.16,h=0.12+0.05*(y/0.62);ring(part('soufflante'),lpMat,18,y,h+0.005,0.337,0.07,0.6,'lp');ring(part('soufflante'),stMat,22,y+0.08,h+0.005,0.337,0.05,-0.45,null);}
  const nh=spec.hp,dy=0.63/nh;
  for(let i=0;i<nh;i++){const y=0.78+i*dy,tip=0.25-0.05*(i/(nh-1));ring(part('hp'),hpMat,24,y,0.172,tip,Math.min(0.05,dy*0.4),0.55,hpSpool);ring(part('hp'),stMat,28,y+dy*0.48,0.172,tip,Math.min(0.035,dy*0.3),-0.45,null);}
  ring(part('thp'),stMat,20,1.84,0.172,0.245,0.04,-0.6,null);ring(part('thp'),tHP,30,1.9,0.172,0.245,0.045,0.65,hpSpool);
  ring(part('tbp'),stMat,20,1.98,0.168,0.25,0.04,-0.6,null);ring(part('tbp'),tLP,30,2.05,0.165,0.25,0.05,0.65,'lp');
  const plumeMat=new T.MeshBasicMaterial({color:0xffb060,transparent:true,opacity:0.12,side:T.DoubleSide,depthWrite:false});
  const plume=new T.Mesh(new T.ConeGeometry(1,1,32,1,true),plumeMat);g.add(plume);
  const diaMat=new T.MeshBasicMaterial({color:0xfff1c8,transparent:true,opacity:0,depthWrite:false});
  const dias=[];for(let i=0;i<4;i++){const d=new T.Mesh(new T.SphereGeometry(1,16,10),diaMat);g.add(d);dias.push(d);}
  g.scale.set(spec.sR,spec.sL,spec.sR);
  return {g,spools,flameMat,abMat,plumeMat,diaMat,dias,plume,liner,tHP,tLP,nozzle,open:0,spec};
}

/* ---------- Turbofan civil paramétrable (LEAP-1A, LEAP-1B, CFM56-5B) ----------
   Axe du moteur = +y (entrée d'air vers y négatif), unités en mètres, proportions internes schématiques. */
function tfGeom(sp){const R=sp.D/2,L=sp.L;return {R,L,y0:-0.5*R,yFan:0.06*L,yNac:0.62*L,yEnd:L,yPlug:L+0.32*R,rCore:0.5*R};}
function buildTurbofan(sp,opt){
  const g=new T.Group(),spools={lp:[],hp:[]},cut=opt.cut,lite=opt.lite;const G=tfGeom(sp),R=G.R,L=G.L;
  const part=p=>opt.cutParts?p:(p==='nacelle'?'nacelle':'moteurs'),mk=(p,o)=>M(part(p),o);
  // nacelle : capot extérieur + paroi intérieure du canal froid
  const nacMat=mk('nacelle',{color:0xd4dbe2,metalness:0.35,roughness:0.45});
  add(g,part('nacelle'),lathe([[1.06*R,G.y0],[1.15*R,G.y0+0.12*R],[1.18*R,0.15*L],[1.15*R,0.42*L],[1.0*R,G.yNac]],!cut),nacMat);
  add(g,part('secondaire'),lathe([[1.0*R,G.y0+0.05*R],[1.0*R,0.12*L],[0.98*R,0.3*L],[0.84*R,G.yNac]],!cut),mk('secondaire',{color:0x9aa7b4,metalness:0.5,roughness:0.45}));
  // carter du cœur (sépare les flux) puis tuyère chaude et cône
  const coreMat=mk('secondaire',{color:0xb8c2cc,metalness:0.6,roughness:0.35});
  add(g,part('secondaire'),lathe([[0.42*R,0.13*L],[0.5*R,0.2*L],[0.56*R,0.42*L],[0.54*R,0.62*L],[0.46*R,0.86*L]],!cut),coreMat);
  add(g,part('tuyere'),lathe([[0.46*R,0.86*L],[0.36*R,L]],!cut),mk('tuyere',{color:0x8d8579,metalness:0.6,roughness:0.4}));
  add(g,part('tuyere'),lathe([[0.22*R,0.86*L],[0.2*R,L],[0.0,G.yPlug]],true,32),mk('tuyere',{color:0x7f7468}));
  // cône d'entrée (spinner) et moyeu
  add(g,part('soufflante'),lathe([[0,G.y0+0.42*R],[0.12*R,G.y0+0.62*R],[0.25*R,G.yFan+0.04*L],[0.3*R,0.13*L]],true,36),mk('soufflante',{color:0x4b5561,metalness:0.4,roughness:0.5}));
  const hubMat=mk('hp',{color:0x6f7a86});
  add(g,part('hp'),lathe([[0.3*R,0.13*L],[0.26*R,0.28*L],[0.22*R,0.52*L]],true,32),hubMat);
  add(g,part('tbp'),lathe([[0.22*R,0.62*L],[0.24*R,0.86*L],[0.22*R,0.86*L]],true,32),mk('tbp',{color:0x6f7a86}));
  const flameMat=new T.MeshBasicMaterial({color:0xff7a2a,transparent:true,opacity:0.5,side:T.DoubleSide,depthWrite:false});
  const liner=mk('chambre',{color:0x7d6a58,metalness:0.4,roughness:0.55});
  add(g,part('chambre'),lathe([[0.3*R,0.52*L],[0.26*R,0.54*L],[0.26*R,0.6*L],[0.4*R,0.6*L],[0.4*R,0.54*L],[0.36*R,0.52*L]],!cut),liner);
  g.add(new T.Mesh(lathe([[0.28*R,0.545*L],[0.38*R,0.545*L],[0.38*R,0.595*L],[0.28*R,0.595*L],[0.28*R,0.545*L]],!cut),flameMat));
  function ring(p0,mat,n,y,r0,r1,chord,twist,spool,th){const rg=new T.Group();g.add(rg);
    for(let b=0;b<n;b++){const a=b/n*Math.PI*2;const m=new T.Mesh(bladeGeo,mat);m.userData.part=p0;m.scale.set(r1-r0,chord,th||0.012);const rm=(r0+r1)/2;
      m.position.set(rm*Math.cos(a),y,rm*Math.sin(a));m.rotation.set(twist,-a,0,'YXZ');rg.add(m);pickables.push(m);}
    if(spool)spools[spool].push(rg);}
  const fanMat=mk('soufflante',{color:sp.nFan>20?0xb9c6d2:0x2c3540,metalness:sp.nFan>20?0.8:0.25,roughness:sp.nFan>20?0.25:0.55});
  ring(part('soufflante'),fanMat,sp.nFan,G.yFan+0.04*L,0.3*R,0.98*R,0.11*L,0.75,'lp',sp.nFan>20?0.012:0.03);
  const stMat=mk('hp',{color:0x7f8b98});
  ring(part('secondaire'),stMat,lite?0:40,0.2*L,0.58*R,0.99*R,0.03*L,-0.35,null);
  if(!lite){
    const bMat=mk('booster',{color:0xa9c3da,metalness:0.75,roughness:0.28});
    for(let i=0;i<sp.nBoost;i++){const y=0.15*L+i*0.022*L;ring(part('booster'),bMat,28,y,0.31*R,0.47*R,0.012*L,0.6,'lp');}
    const hMat=mk('hp',{color:0xdcc79e,metalness:0.75,roughness:0.3});
    for(let i=0;i<sp.nHP;i++){const t=i/(sp.nHP-1),y=0.29*L+t*0.22*L,tip=(0.42-0.12*t)*R;ring(part('hp'),hMat,24,y,(0.26-0.04*t)*R,tip,0.01*L,0.55,'hp');}
    const tH=mk('thp',{color:0xb08f6f});
    for(let i=0;i<sp.nHPT;i++)ring(part('thp'),tH,30,0.615*L+i*0.022*L,0.25*R,0.39*R,0.012*L,-0.65,'hp');
    const tL=mk('tbp',{color:0x9a8775});
    for(let i=0;i<sp.nLPT;i++){const t=sp.nLPT>1?i/(sp.nLPT-1):0;ring(part('tbp'),tL,34,0.67*L+t*0.17*L,0.25*R,(0.4+0.08*t)*R,0.012*L,-0.6,'lp');}
    if(opt.cutParts){const fb=add(g,'fadec',new T.BoxGeometry(0.08*L,0.12*L,0.06*L),M('fadec',{color:0x33424f,metalness:0.3,roughness:0.6}));fb.position.set(-1.21*R,0.3*L,0);}
  }
  const tHP=mk('thp',{color:0xb08f6f}),tLP=mk('tbp',{color:0x9a8775});
  const plumeMat=new T.MeshBasicMaterial({color:0xffb060,transparent:true,opacity:0.08,side:T.DoubleSide,depthWrite:false});
  const plume=new T.Mesh(new T.ConeGeometry(1,1,32,1,true),plumeMat);g.add(plume);
  return {g,spools,flameMat,plumeMat,plume,liner,tHP,tLP,nacMat,civil:true,sp,G,nozzle(){}};
}

/* ---------- Étape C : moteurs seuls ---------- */
const viewIso=new T.Group();pivot.add(viewIso);
const iso={};
Object.entries(DUOS).forEach(([k,d])=>{
  if(d.civil){const e=buildTurbofan(d.tf,{cut:true,cutParts:true});const G=e.G;e.g.rotation.z=-Math.PI/2;e.g.position.x=-(G.y0+G.yPlug)/2;viewIso.add(e.g);iso[k]=e;return;}
  const e=buildEngine(d.engine,{cut:true,cutParts:true});e.g.rotation.z=-Math.PI/2;e.g.position.x=-1.75*d.engine.sL;viewIso.add(e.g);iso[k]=e;});
// particules (rattachées au moteur affiché)
const NP=900,Y0=-0.6;
const pos=new Float32Array(NP*3),col=new Float32Array(NP*3),py=new Float32Array(NP),pf=new Float32Array(NP),pth=new Float32Array(NP),sec=new Uint8Array(NP);
for(let i=0;i<NP;i++){py[i]=Y0+Math.random()*5.6;pf[i]=Math.random();pth[i]=Math.random()*Math.PI*2;sec[i]=Math.random()<0.23?1:0;}
const pgeo=new T.BufferGeometry();pgeo.setAttribute('position',new T.BufferAttribute(pos,3));pgeo.setAttribute('color',new T.BufferAttribute(col,3));
const points=new T.Points(pgeo,new T.PointsMaterial({size:0.018,vertexColors:true,transparent:true,opacity:0.95,depthWrite:false}));
let plumeL=1.2,yEnd=5,curOpen=0;
function radial(y,f,s){
  if(y<0)return f*0.33;
  if(y<0.65){const h=0.12+0.05*Math.max(0,y)/0.62;return s?0.27+f*0.06:h+0.01+f*(0.25-h-0.02);}
  if(s&&y<2.4)return 0.272+f*0.06;
  if(y<1.4){const tip=0.25-0.05*(y-0.65)/0.75;return 0.175+f*(tip-0.18);}
  if(y<1.8)return 0.19+f*0.05; if(y<2.12)return 0.175+f*0.065;
  if(y<2.55){const tc=0.12*Math.max(0,1-(y-2.12)/0.43);return tc+0.01+f*(0.245-tc-0.02);}
  if(y<3.25)return 0.02+f*0.3; if(y<3.54)return f*(0.24+0.07*curOpen);
  const s2=Math.min(1,(y-3.54)/plumeL);return f*(0.27+0.07*curOpen)*(1-0.7*s2);
}
const STOPS=[[200,[0.22,0.48,0.88]],[420,[0.48,0.78,0.96]],[700,[0.96,0.86,0.62]],[1050,[1.0,0.52,0.16]],[1500,[1.0,0.68,0.25]],[2100,[1.0,0.93,0.72]]];
const tmp=new T.Color();
function heat(Tk,out){out=out||tmp;if(Tk<=STOPS[0][0])return out.setRGB(...STOPS[0][1]);
  for(let i=1;i<STOPS.length;i++){if(Tk<=STOPS[i][0]){const a=STOPS[i-1],b=STOPS[i],k=(Tk-a[0])/(b[0]-a[0]);return out.setRGB(a[1][0]+(b[1][0]-a[1][0])*k,a[1][1]+(b[1][1]-a[1][1])*k,a[1][2]+(b[1][2]-a[1][2])*k);}}
  return out.setRGB(...STOPS[STOPS.length-1][1]);}
let st={x:1,pc:false};
function tempAt(y,s){const x=st.x,T4=1100+750*x,T2=288+160*(0.5+0.5*x),T3=500+290*x,T5=T4-260*x-80,T55=T5-200*x-60,Tmix=0.77*T55+0.23*T2,T7=st.pc?2100:Tmix;
  const pts=s?[[Y0,288],[0,288],[0.62,T2],[2.4,T2+20],[2.55,Tmix],[2.7,Tmix],[3.25,T7],[3.54,T7*0.75],[yEnd,400]]
             :[[Y0,288],[0,288],[0.62,T2],[1.4,T3],[1.5,T3],[1.72,T4],[1.84,T4],[1.95,T5],[2.1,T55],[2.55,Tmix],[2.7,Tmix],[3.25,T7],[3.54,T7*0.75],[yEnd,400]];
  for(let i=1;i<pts.length;i++){if(y<=pts[i][0]){const a=pts[i-1],b=pts[i];return a[1]+(b[1]-a[1])*(y-a[0])/Math.max(1e-6,b[0]-a[0]);}}return 400;}
/* écoulement dans un turbofan : flux froid (secondaire) majoritaire, flux chaud dans le cœur */
let TFG=null;
function radialTF(y,f,s){const G=TFG,R=G.R,L=G.L;
  if(y<0.13*L)return y<G.yFan?f*0.95*R:0.3*R+f*0.66*R;
  if(s){if(y<G.yNac){const k=(y-0.13*L)/(G.yNac-0.13*L);const lo=0.5*R+0.06*R*Math.sin(Math.PI*k),hi=(0.98-0.12*k)*R;return lo+0.02*R+f*(hi-lo-0.04*R);}
    const u=Math.min(1,(y-G.yNac)/(1.6*L));return (0.6*R+f*0.22*R)*(1-0.15*u);}
  if(y<0.29*L)return 0.31*R+f*0.15*R; if(y<0.52*L)return 0.27*R+f*0.12*R; if(y<0.6*L)return 0.28*R+f*0.09*R; if(y<0.86*L)return 0.26*R+f*0.18*R;
  if(y<L)return 0.22*R+f*0.13*R; const u=Math.min(1,(y-L)/(1.2*L));return f*0.33*R*(1-0.4*u);}
function tempTF(y,s){const x=st.x,L=TFG.L,T4=1150+650*x,T3=450+380*x,T25=330+60*x,T5=T4-450*x-120,Tx=T5-350*x-60;
  const pts=s?[[TFG.y0,288],[TFG.yFan,288],[0.13*L,300+25*x],[3*L,300+25*x]]
             :[[TFG.y0,288],[0.13*L,300+25*x],[0.27*L,T25],[0.52*L,T3],[0.55*L,T4],[0.62*L,T4],[0.66*L,T5],[0.86*L,Tx],[L,Tx],[2.4*L,420]];
  for(let i=1;i<pts.length;i++){if(y<=pts[i][0]){const a=pts[i-1],b=pts[i];return a[1]+(b[1]-a[1])*(y-a[0])/Math.max(1e-6,b[0]-a[0]);}}return 400;}
function speedTF(y,s){const k=0.4+0.6*st.x,L=TFG.L;if(s)return (y<0.13*L?1.2:y<TFG.yNac?1.6:2.2)*k*L/3.3;
  if(y<0.29*L)return 0.9*k*L/3.3;if(y<0.52*L)return 0.6*k*L/3.3;if(y<0.62*L)return 0.5*k*L/3.3;if(y<L)return 1.2*k*L/3.3;return 2.6*k*L/3.3;}
function speed(y,s){const k=0.4+0.6*st.x;if(y<0.65)return 0.9*k;if(s&&y<2.4)return 1.4*k;if(y<1.4)return 0.8*k;if(y<1.8)return 0.6*k;if(y<2.55)return 1.4*k;if(y<3.25)return (st.pc?2.2:1.6)*k;return (st.pc?4.2:3)*k;}

/* ---------- Étapes A et B : les avions ---------- */
const viewAir=new T.Group();pivot.add(viewAir);
const skin=new T.MeshStandardMaterial({color:0x9aa8b6,metalness:0.45,roughness:0.5,transparent:true,opacity:0.9,side:T.DoubleSide});
const edgeMat=new T.LineBasicMaterial({color:0x06b6d4,transparent:true,opacity:0.2});
const ductMat=new T.MeshStandardMaterial({color:0x06b6d4,transparent:true,opacity:0.25,depthWrite:false,side:T.DoubleSide});
const zoneMat=new T.MeshBasicMaterial({color:0xf59e0b,transparent:true,opacity:0.3,depthWrite:false,depthTest:false});
function skinPart(g,part,geo){const m=new T.Mesh(geo,skin);m.userData.part=part;g.add(m);pickables.push(m);g.add(new T.LineSegments(new T.EdgesGeometry(geo,28),edgeMat));return m;}
function flat(pts,depth){const sh=new T.Shape();sh.moveTo(pts[0][0],pts[0][1]);pts.slice(1).forEach(p=>sh.lineTo(p[0],p[1]));sh.closePath();return new T.ExtrudeGeometry(sh,{depth,bevelEnabled:false});}
function fuselage(prof,sy,sz){const f=new T.LatheGeometry(prof.map(p=>new T.Vector2(p[0],p[1])),48);f.rotateZ(-Math.PI/2);f.scale(1,sy,sz);return f;}
function duct(g,a,b,r){const c=new T.CubicBezierCurve3(a,new T.Vector3(a.x-2.2,a.y,a.z),new T.Vector3(b.x+1.6,b.y,b.z),b);const d=new T.Mesh(new T.TubeGeometry(c,24,r,16,false),ductMat);d.userData.part='entrees';g.add(d);pickables.push(d);}
function zone(g,x0,x1,w,h){const z=new T.Mesh(new T.BoxGeometry(x0-x1,h,w),zoneMat);z.position.set((x0+x1)/2,0,0);g.add(z);return z;}
const air={};
function buildRafale(){
  const g=new T.Group();
  skinPart(g,'moteurs',fuselage([[0,7.7],[0.18,7.0],[0.42,5.8],[0.62,4.6],[0.78,3.4],[0.85,2.0],[0.88,0],[0.9,-2],[0.92,-4],[0.88,-6.2],[0.78,-7.1],[0.7,-7.4]],0.85,1.35));
  [1,-1].forEach(s=>{
    const w=flat([[1.0,0.7],[-6.4,5.45],[-7.1,5.45],[-7.2,0.7]],0.08);w.rotateX(Math.PI/2);if(s<0)w.scale(1,1,-1);w.translate(0,-0.22,0);skinPart(g,'aile',w);
    const c=flat([[3.7,0.72],[2.3,2.0],[1.95,2.0],[2.25,0.72]],0.05);c.rotateX(Math.PI/2);if(s<0)c.scale(1,1,-1);c.translate(0,0.18,0);skinPart(g,'aile',c);
    const it=new T.BoxGeometry(1.7,0.72,0.5);it.translate(2.55,-0.32,s*1.05);skinPart(g,'entrees',it);
    duct(g,new T.Vector3(1.7,-0.32,s*1.05),new T.Vector3(-3.85,-0.05,s*0.55),0.26);
  });
  const fin=flat([[-3.6,0.55],[-6.5,3.9],[-7.0,3.9],[-7.35,0.55]],0.07);fin.translate(0,0,-0.035);skinPart(g,'aile',fin);
  const can=new T.Mesh(new T.SphereGeometry(1,24,14),new T.MeshStandardMaterial({color:0x06b6d4,transparent:true,opacity:0.3,metalness:0.2,roughness:0.1,depthWrite:false}));can.scale.set(1.5,0.42,0.5);can.position.set(4.6,0.62,0);g.add(can);
  const engs=[1,-1].map(s=>{const e=buildEngine(DUOS.rafale.engine,{cut:false});e.g.rotation.z=Math.PI/2;e.g.position.set(-3.9,-0.05,s*0.55);g.add(e.g);return e;});
  const z=zone(g,-3.8,-7.5,1.9,0.9);
  return {g,engs,zone:z};
}
function buildMirage(){
  const g=new T.Group();
  skinPart(g,'moteurs',fuselage([[0,7.2],[0.15,6.5],[0.38,5.4],[0.55,4.2],[0.66,3.0],[0.72,1.5],[0.74,0],[0.75,-2],[0.74,-4],[0.7,-6],[0.64,-7.0],[0.6,-7.2]],0.95,1.15));
  [1,-1].forEach(s=>{
    const w=flat([[1.8,0.7],[-5.9,4.56],[-6.5,4.56],[-6.6,0.7]],0.08);w.rotateX(Math.PI/2);if(s<0)w.scale(1,1,-1);w.translate(0,-0.25,0);skinPart(g,'aile',w);
    const it=new T.CylinderGeometry(0.42,0.42,2.6,20,1,true,0,Math.PI);it.rotateZ(Math.PI/2);it.rotateX(s>0?-Math.PI/2:Math.PI/2);it.translate(1.6,-0.05,s*0.78);skinPart(g,'entrees',it);
    const sou=new T.Mesh(new T.ConeGeometry(0.2,0.7,20),M('entrees',{color:0x5f6b77}));sou.rotation.z=-Math.PI/2;sou.position.set(3.05,-0.05,s*0.85);sou.userData.part='entrees';g.add(sou);pickables.push(sou);
    duct(g,new T.Vector3(1.2,-0.05,s*0.85),new T.Vector3(-2.15,0,0),0.3);
  });
  const fin=flat([[-3.2,0.6],[-6.4,4.0],[-7.0,4.0],[-7.1,0.6]],0.07);fin.translate(0,0,-0.035);skinPart(g,'aile',fin);
  const can=new T.Mesh(new T.SphereGeometry(1,24,14),new T.MeshStandardMaterial({color:0x06b6d4,transparent:true,opacity:0.3,metalness:0.2,roughness:0.1,depthWrite:false}));can.scale.set(1.4,0.4,0.42);can.position.set(4.2,0.55,0);g.add(can);
  const e=buildEngine(DUOS.mirage.engine,{cut:false});e.g.rotation.z=Math.PI/2;e.g.position.set(-2.12,0,0);g.add(e.g);
  const z=zone(g,-2.0,-7.3,1.2,1.1);
  return {g,engs:[e],zone:z};
}
function buildAirliner(key){
  const d=DUOS[key],A=d.al,R=A.R,half=A.L/2,hs=A.span/2,g=new T.Group();
  const prof=[[0,half],[0.45*R,half-0.6],[0.8*R,half-1.6],[0.97*R,half-3.6],[R,half-6],[R,-half+11],[0.92*R,-half+8],[0.65*R,-half+4.5],[0.35*R,-half+1.8],[0.12*R,-half]];
  skinPart(g,'fuselage',fuselage(prof,1.04,1));
  const x0=A.x0,rz=0.9*R,sweep=12.0;
  [1,-1].forEach(s=>{
    const w=flat([[x0,rz],[x0-sweep,hs],[x0-sweep-1.6,hs],[x0-7.0,rz+4.2],[x0-7.6,rz]],0.18);w.rotateX(Math.PI/2);if(s<0)w.scale(1,1,-1);w.translate(0,A.wingY,0);skinPart(g,'aile',w);
    const h=flat([[-half+7.5,0.5],[-half+3.4,A.ht/2],[-half+2.0,A.ht/2],[-half+2.6,0.5]],0.08);h.rotateX(Math.PI/2);if(s<0)h.scale(1,1,-1);h.translate(0,0.35*R,0);skinPart(g,'aile',h);
  });
  const fin=flat([[-half+8.2,0.8*R],[-half+3.4,R+A.fin],[-half+1.6,R+A.fin],[-half+0.6,0.8*R]],0.12);fin.translate(0,0,-0.06);skinPart(g,'aile',fin);
  const G=tfGeom(d.tf),Re=G.R,Le=G.L,zone=new T.Group(),engs=[],flowEng=[];
  const xLE=x0-sweep*(A.engZ-rz)/(hs-rz),xFront=xLE+A.lead,px=xFront+G.y0,axisY=A.wingY-0.4-1.18*Re-A.engDrop;
  const pylMat=M('mat',{color:0xc3cbd3,metalness:0.4,roughness:0.45});
  [1,-1].forEach(s=>{
    const e=buildTurbofan(d.tf,{cut:false,lite:true});e.g.rotation.z=Math.PI/2;e.g.position.set(px,axisY,s*A.engZ);g.add(e.g);engs.push(e);
    const top=axisY+1.1*Re,hgt=A.wingY-top+0.2;
    const py=add(g,'mat',new T.BoxGeometry(0.62*Le+1.2,hgt,0.34),pylMat);py.position.set(px-0.3*Le-0.4,top+hgt/2,s*A.engZ);
    const z=new T.Mesh(new T.BoxGeometry(Le+0.9*Re,2.5*Re,2.5*Re),zoneMat);z.position.set(px-Le/2+0.1,axisY,s*A.engZ);zone.add(z);
    flowEng.push([xFront,axisY,s*A.engZ,xFront-0.7,axisY,s*A.engZ,px-Le]);
  });
  g.add(zone);g.scale.setScalar(SC);
  d.center=new T.Vector3((px-Le/2)*SC,axisY*SC,A.engZ*SC);
  LBL_AIR[key]=[['nacelle',[xFront+0.2,axisY+1.25*Re+0.3,A.engZ],'B'],['mat',[px-0.3*Le-0.4,(A.wingY+axisY+1.1*Re)/2,A.engZ+0.5],'B'],
    ['moteurs',[px-Le/2,axisY-1.3*Re-0.4,-A.engZ],'A'],['aile',[x0-9,A.wingY,13],'A'],['tuyeres',[px-Le-0.6,axisY-0.2,A.engZ],'B']];
  return {g,engs,zone,flowdef:{prof,sy:1.04,sz:1,eng:flowEng,xmax:half+8,xmin:-half-16,spread:2.6,k:2.4,cold:true}};
}
air.rafale=buildRafale();air.mirage=buildMirage();
CIVIL_KEYS.forEach(k=>{air[k]=buildAirliner(k);});
Object.values(air).forEach(a=>viewAir.add(a.g));
// particules d'air : écoulement autour de la cellule + air qui traverse les moteurs
const FLOWDEF={
  rafale:{prof:[[0,7.7],[0.18,7.0],[0.42,5.8],[0.62,4.6],[0.78,3.4],[0.85,2.0],[0.88,0],[0.9,-2],[0.92,-4],[0.88,-6.2],[0.78,-7.1],[0.7,-7.4]],sy:0.85,sz:1.35,
    eng:[[2.55,-0.32,1.05,-3.9,-0.05,0.55,-7.44],[2.55,-0.32,-1.05,-3.9,-0.05,-0.55,-7.44]]},
  mirage:{prof:[[0,7.2],[0.15,6.5],[0.38,5.4],[0.55,4.2],[0.66,3.0],[0.72,1.5],[0.74,0],[0.75,-2],[0.74,-4],[0.7,-6],[0.64,-7.0],[0.6,-7.2]],sy:0.95,sz:1.15,
    eng:[[1.6,-0.05,0.78,-2.12,0,0,-7.19],[1.6,-0.05,-0.78,-2.12,0,0,-7.19]]}};
CIVIL_KEYS.forEach(k=>{FLOWDEF[k]=air[k].flowdef;});
const NA=900,NE=160,XMAX=13,XMIN=-17;
function bodyR(prof,x){if(x>prof[0][1]||x<prof[prof.length-1][1])return 0;for(let i=1;i<prof.length;i++){const a=prof[i-1],b=prof[i];if(x>=b[1]){return a[0]+(b[0]-a[0])*(a[1]-x)/Math.max(1e-6,a[1]-b[1]);}}return 0;}
const COLD=new T.Color(0x7dd3fc),HOT=new T.Color(0xfb923c);

function makeFlow(key){
  const d=FLOWDEF[key],nE=NE*d.eng.length,N=NA+nE;
  // chaque particule = un petit trait orienté dans le sens de l'écoulement (tête claire, queue sombre)
  const pos=new Float32Array(N*6),col=new Float32Array(N*6),geo=new T.BufferGeometry();
  geo.setAttribute('position',new T.BufferAttribute(pos,3));geo.setAttribute('color',new T.BufferAttribute(col,3));
  const mat=new T.LineBasicMaterial({vertexColors:true,transparent:true,opacity:1,depthWrite:false,blending:T.AdditiveBlending});
  const seg=new T.LineSegments(geo,mat);seg.frustumCulled=false;air[key].g.add(seg);
  const px=new Float32Array(N),pr=new Float32Array(N),pt=new Float32Array(N),pv=new Float32Array(N),pj=new Float32Array(N*2);
  d.xmax=d.xmax||XMAX;d.xmin=d.xmin||XMIN;d.spread=d.spread||1;d.k=d.k||1;const SP=d.spread;
  for(let i=0;i<N;i++){px[i]=d.xmin+Math.random()*(d.xmax-d.xmin);pr[i]=(0.15+Math.sqrt(Math.random())*5.5)*SP;pt[i]=Math.random()*Math.PI*2;pv[i]=0.8+0.4*Math.random();pj[i*2]=(Math.random()-0.5);pj[i*2+1]=(Math.random()-0.5);}
  if(nE)for(let i=NA;i<N;i++)px[i]=d.xmin+3*SP+Math.random()*(d.xmax-d.xmin-6*SP);
  return {d,N,nE,pos,col,geo,mat,px,pr,pt,pv,pj};
}
const flow={};Object.keys(FLOWDEF).forEach(k=>{flow[k]=makeFlow(k);});
const fc=new T.Color(),fp=[0,0,0];
// position et couleur d'une particule i à l'abscisse x (repère avion, nez vers +x)
function place(F,i,x,pc,thr,fade){
  const d=F.d,SP=d.spread;
  if(i<NA){const rb=bodyR(d.prof,x),r=F.pr[i],c=Math.cos(F.pt[i]),s=Math.sin(F.pt[i]);
    const ry=Math.sqrt(r*r+Math.pow(rb*d.sy*1.15,2)),rz=Math.sqrt(r*r+Math.pow(rb*d.sz*1.15,2));
    fp[0]=x;fp[1]=ry*c;fp[2]=rz*s;
    const a=Math.max(0,Math.min(1,(d.xmax-x)/(3*SP)))*Math.max(0,Math.min(1,(x-d.xmin)/(3*SP)))*(0.35+0.65/(1+r/SP*0.45))*fade;
    fc.copy(COLD).multiplyScalar(a);return;}
  const k=Math.floor((i-NA)/NE),[xi,yi,zi,xe,ye,ze,xn]=d.eng[k];let y,z,a;
  if(x>=xi){const w=Math.min(1,(x-xi)/(6*SP));y=yi+F.pj[i*2]*0.5*SP*(0.2+w*2);z=zi+F.pj[i*2+1]*0.5*SP*(0.2+w*2);fc.copy(COLD);a=0.7*Math.max(0,Math.min(1,(xi+9*SP-x)/(3*SP)));}
  else if(x>xe){const u=(xi-x)/(xi-xe);y=yi+(ye-yi)*u+F.pj[i*2]*0.3*SP;z=zi+(ze-zi)*u+F.pj[i*2+1]*0.3*SP;fc.copy(COLD);a=0.7;}
  else if(x>xn){const u=(xe-x)/(xe-xn);y=ye+F.pj[i*2]*0.35*SP*(1-u*0.4);z=ze+F.pj[i*2+1]*0.35*SP*(1-u*0.4);fc.copy(COLD).lerp(HOT,Math.min(1,u*(d.cold?0.6:2.2)));a=0.9;}
  else{const u=Math.min(1,(xn-x)/(xn-d.xmin));const sp=(0.25+u*(pc?2.2:1.4))*SP;y=ye+F.pj[i*2]*sp;z=ze+F.pj[i*2+1]*sp;fc.copy(d.cold?COLD:HOT).lerp(COLD,u*0.9);if(d.cold)fc.lerp(HOT,0.25*(1-u));a=(pc?1.2:0.9)*(1-u)*(0.4+0.6*thr);}
  fp[0]=x;fp[1]=y;fp[2]=z;fc.multiplyScalar(a*fade);
}
function updateFlow(F,dt,vAir,thr,pc,fade){
  const d=F.d,SP=d.spread,K=d.k,tail=(0.18+vAir*0.06)*SP;vAir*=K;
  for(let i=0;i<F.N;i++){
    let v,L=tail;
    if(i<NA){v=vAir*F.pv[i];F.px[i]-=v*dt;if(F.px[i]<d.xmin){F.px[i]=d.xmax;F.pt[i]=Math.random()*Math.PI*2;}}
    else{const xn=d.eng[Math.floor((i-NA)/NE)][6],xi=d.eng[Math.floor((i-NA)/NE)][0];
      const jet=F.px[i]<=xn;v=(jet?(pc?16:9)*K*(0.4+0.6*thr)+vAir*0.5:Math.max(2.5*K,vAir*0.9)*(0.6+0.6*thr))*F.pv[i];
      L=jet?(0.35*SP+v*0.05):tail;F.px[i]-=v*dt;if(F.px[i]<d.xmin)F.px[i]=xi+(2+Math.random()*7)*SP;}
    const o=i*6,x=F.px[i];
    place(F,i,x,pc,thr,fade);F.pos[o]=fp[0];F.pos[o+1]=fp[1];F.pos[o+2]=fp[2];F.col[o]=fc.r;F.col[o+1]=fc.g;F.col[o+2]=fc.b;
    place(F,i,x+L,pc,thr,fade);F.pos[o+3]=fp[0];F.pos[o+4]=fp[1];F.pos[o+5]=fp[2];F.col[o+3]=fc.r*0.12;F.col[o+4]=fc.g*0.12;F.col[o+5]=fc.b*0.12;
  }
  F.geo.attributes.position.needsUpdate=true;F.geo.attributes.color.needsUpdate=true;
}

/* ---------- Étiquettes ---------- */
const labelsLayer=$('h-labels');
const LBL_ISO=[['soufflante',0.35,1],['hp',1.05,1],['chambre',1.62,-1],['thp',1.88,1],['tbp',2.06,-1],['secondaire',1.15,-1],['pc',2.9,1],['tuyere',3.45,-1],['fadec',1.2,0]];
function mkLabel(k){const b=document.createElement('button');b.type='button';b.className='h-lbl';b.dataset.part=k;b.addEventListener('click',()=>select(k));labelsLayer.appendChild(b);return b;}
const lblIso=LBL_ISO.map(l=>({k:l[0],y:l[1],s:l[2],el:mkLabel(l[0])}));
// étiquettes des turbofans : [pièce, position axiale (fraction de L), rayon (fraction de R)]
const LBL_TF=[['soufflante',0.08,1.25],['booster',0.2,-0.62],['hp',0.4,0.62],['chambre',0.57,-0.62],['thp',0.63,0.58],['tbp',0.76,-0.68],['secondaire',0.4,1.3],['tuyere',0.98,0.7],['fadec',0.3,-1.4]];
const lblTF=LBL_TF.map(l=>({k:l[0],y:l[1],r:l[2],el:mkLabel(l[0])}));
const lblAir={};Object.entries(LBL_AIR).forEach(([d,arr])=>{lblAir[d]=arr.map(l=>({k:l[0],p:new T.Vector3(...l[1]),only:l[2]||'',el:mkLabel(l[0])}));});

/* ---------- État et sélection ---------- */
let duo='rafale',step='A',selected=null,phase=null,touched=false,zoom=1;
let accent=new T.Color('#06b6d4');
function readAccent(){try{const c=getComputedStyle(document.documentElement).getPropertyValue('--cyan').trim();if(c)accent=new T.Color(c);}catch(e){}}
readAccent();new MutationObserver(readAccent).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
function info(k){return INFO[duo][k];}
function select(k){
  selected=k;const I=k?info(k):null,tp=k&&TP[duo][k];
  $('h-info').innerHTML=I?`<span class="pill next">${I.c}</span><h3>${I.n}</h3><p>${I.t}</p>${tp?`<dl class="h-tp">${tp.map(x=>`<div><dt>${x[0]}</dt><dd>${x[1]}</dd></div>`).join('')}</dl><p class="h-src">Ordres de grandeur publics, à titre pédagogique.</p>`:''}`:defaultInfo();
  document.querySelectorAll('.h-lbl').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.part===k)));
}
const STEPTXT={
  A:(d)=>d.civil?`<span class="pill">Étape A · l’avion</span><h3>L’${d.avion} en entier</h3><p>Les zones ambrées entourent les deux ${d.moteur}, suspendus sous les ailes. Les particules montrent l’air qui contourne l’avion et celui qu’avalent les moteurs. Choisis une phase de vol, puis passe à l’étape B pour te placer sous l’aile.</p>`.replace('L’737','Le 737'):`<span class="pill">Étape A · l’avion</span><h3>Le ${d.avion} en entier</h3><p>La zone ambrée montre où se trouve${d.nEng>1?'nt les deux moteurs':' le moteur'} ; les conduits cyan amènent l’air depuis les entrées. Choisis une phase de vol, puis passe à l’étape B pour entrer dans le fuselage.</p>`,
  B:(d)=>d.civil?`<span class="pill">Étape B · nacelle et mât</span><h3>Le ${d.moteur} sous l’aile</h3><p>La caméra se place sous l’aile : la nacelle devient transparente et laisse voir la soufflante. Le mât d’accrochage transmet la poussée et le poids du moteur à l’aile. Clique sur « Mât d’accrochage » pour voir comment on calcule ses efforts.</p>`:`<span class="pill">Étape B · l’intégration</span><h3>Le compartiment moteur</h3><p>La carlingue devient transparente et la caméra s’approche : on voit ${d.nEng>1?'les deux '+d.moteur+' côte à côte':'le '+d.moteur+' au centre'}, les conduits d’air qui ${d.nEng>1?'les ':'l’'}alimentent et les tuyères. L’étape C isole le moteur.</p>`,
  C:(d)=>d.civil?`<span class="pill">Étape C · le moteur seul</span><h3>Le ${d.moteur} en coupe</h3><p>L’air entre à gauche. Environ ${Math.round(d.tf.bpr/(1+d.tf.bpr)*100)} % des particules passent par le canal froid (taux de dilution ≈ ${String(d.tf.bpr).replace('.',',')}) : c’est le flux secondaire qui fait l’essentiel de la poussée. Le reste traverse le cœur, chauffe dans la chambre et ressort au centre. Aubes bleutées : corps BP ; dorées : corps HP. Clique sur une étiquette pour lire la fiche.</p>`:`<span class="pill">Étape C · le moteur seul</span><h3>Le ${d.moteur} en coupe</h3><p>L’air entre à gauche. Les points qui restent en périphérie forment le flux secondaire, froid. ${d.engine.single?'Toutes les aubes tournent ensemble : le M53 n’a qu’un seul corps.':'Les aubes bleutées (corps BP) et dorées (corps HP) ne tournent pas à la même vitesse : c’est le double corps.'} Clique sur une étiquette pour lire la fiche.</p>`
};
function defaultInfo(){return STEPTXT[step](DUOS[duo]);}

/* ---------- Commandes ---------- */
const thr=$('h-thr'),pcb=$('h-pc');
const PHASES_MIL={sol:{x:0,pc:false,mach:0,alt:0,n:'Ralenti au sol'},decollage:{x:1,pc:true,mach:0.25,alt:0,n:'Décollage'},croisiere:{x:0.85,pc:false,mach:0.9,alt:30000,n:'Croisière'},super:{x:1,pc:true,mach:1.6,alt:36000,n:'Supersonique'}};
const PHASES_CIV={sol:{x:0,pc:false,mach:0,alt:0,n:'Ralenti au sol'},decollage:{x:1,pc:false,mach:0.22,alt:0,n:'Décollage'},montee:{x:0.92,pc:false,mach:0.6,alt:20000,n:'Montée'},croisiere:{x:0.8,pc:false,mach:0.78,alt:35000,n:'Croisière'}};
const PH=()=>DUOS[duo].civil?PHASES_CIV:PHASES_MIL;
function readControls(){let x=(+thr.value)/100,pc=pcb.checked;if(pc&&x<0.95){x=1;thr.value=100;}st={x,pc};$('h-thr-o').textContent=`${Math.round(x*100)} %`;updateHud();}
function updateHud(){if(twin){$('h-hud').innerHTML=twin.hud||'';return;}const d=DUOS[duo],n2=Math.round(65+35*st.x),F=st.pc?d.Fpc:d.Fsec*(0.08+0.92*Math.pow(st.x,2.2)),ph=phase?PHASES[phase]:null,mult=step==='C'?1:d.nEng;
  $('h-hud').innerHTML=`<span>RÉGIME <b>${n2} %</b></span><span>PC <b class="${st.pc?'on':''}">${st.pc?'ALLUMÉE':'ÉTEINTE'}</b></span><span>POUSSÉE SOL ≈ <b>${Math.round(F*mult)} kN</b></span>`+(step!=='C'&&ph?`<span>${ph.n.toUpperCase()} · MACH <b>${ph.mach.toFixed(2).replace('.',',')}</b> · ALT <b>${ph.alt.toLocaleString('fr-FR')} FT</b></span>`:'');}
thr.addEventListener('input',()=>{phase=null;markPhase();readControls();});
pcb.addEventListener('change',()=>{phase=null;markPhase();readControls();});
function markPhase(){document.querySelectorAll('[data-phase]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.phase===phase)));}
document.querySelectorAll('[data-phase]').forEach(b=>b.addEventListener('click',()=>{phase=b.dataset.phase;const p=PH()[phase];if(!p)return;thr.value=Math.round(p.x*100);pcb.checked=p.pc;markPhase();readControls();}));
document.querySelectorAll('[data-duo]').forEach(b=>b.addEventListener('click',()=>{duo=b.dataset.duo;phase=null;markPhase();closeSketch();apply();}));
document.querySelectorAll('[data-step]').forEach(b=>b.addEventListener('click',()=>{step=b.dataset.step;closeSketch();apply();}));
const nextBtn=$('h-next');if(nextBtn)nextBtn.addEventListener('click',()=>{step=step==='A'?'B':step==='B'?'C':'A';closeSketch();apply();});
function apply(){
  document.querySelectorAll('[data-duo]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.duo===duo)));
  document.querySelectorAll('[data-step]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.step===step)));
  if(nextBtn)nextBtn.textContent=step==='A'?(DUOS[duo].civil?'Étape suivante : nacelle et mât →':'Étape suivante : intégration →'):step==='B'?'Étape suivante : moteur seul →':'Revenir à l’avion ↺';
  viewIso.visible=step==='C';viewAir.visible=step!=='C';
  Object.entries(iso).forEach(([k,e])=>e.g.visible=k===duo);
  Object.entries(air).forEach(([k,a])=>a.g.visible=k===duo);
  iso[duo].g.add(points);
  const D=DUOS[duo],civil=!!D.civil;
  if(civil){TFG=iso[duo].G;const fr=D.tf.bpr/(1+D.tf.bpr);for(let i=0;i<NP;i++){sec[i]=Math.random()<fr?1:0;py[i]=TFG.y0+Math.random()*(TFG.yPlug+TFG.L*1.2-TFG.y0);}}
  else{for(let i=0;i<NP;i++){sec[i]=Math.random()<0.23?1:0;py[i]=Y0+Math.random()*5.6;}}
  lblIso.forEach(l=>{l.el.hidden=step!=='C'||civil;l.el.textContent=info(l.k)?info(l.k).n.replace(/ \(.*\)/,''):'';});
  if(duo==='mirage')lblIso.find(l=>l.k==='tbp').el.hidden=true;
  lblTF.forEach(l=>{const I=info(l.k);l.el.hidden=step!=='C'||!civil||!I;l.el.textContent=I?I.n.replace(/ \(.*\)/,''):'';});
  if(pcb){pcb.closest('label').hidden=civil;if(civil&&pcb.checked){pcb.checked=false;readControls();}}
  document.querySelectorAll('[data-phase="super"]').forEach(b=>b.hidden=civil);document.querySelectorAll('[data-phase="montee"]').forEach(b=>b.hidden=!civil);
  const sb=document.querySelector('[data-step="B"]');if(sb)sb.innerHTML=civil?'<b>B</b> Nacelle et mât':'<b>B</b> L’intégration';
  const sc=document.querySelector('[data-step="C"]');if(sc)sc.innerHTML='<b>C</b> Moteur seul (banc)';
  Object.entries(lblAir).forEach(([d,arr])=>arr.forEach(l=>{l.el.hidden=step==='C'||d!==duo||(l.only&&l.only!==step);const I=INFO[d][l.k];l.el.textContent=I?I.n.replace(/ \(.*\)/,''):'';}));
  $('h-phases').hidden=step==='C';
  document.querySelectorAll('[data-fiche]').forEach(f=>f.hidden=f.dataset.fiche!==duo);
  touched=false;zoom=1;pivot.position.set(0,0,0);select(null);updateHud();resize();
}

function closeSketch(){}

/* ---------- Souris / doigt ---------- */
const cv=$('h3d');let drag=null;
cv.addEventListener('contextmenu',e=>e.preventDefault());
cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,rx:pivot.rotation.x,ry:pivot.rotation.y,px:pivot.position.x,py:pivot.position.y,pan:e.button===2||e.shiftKey,moved:false};touched=true;try{cv.setPointerCapture(e.pointerId);}catch(_){}});
cv.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.abs(dx)+Math.abs(dy)>4)drag.moved=true;
  if(drag.pan){const k=camDist*0.6/box.clientWidth;pivot.position.x=drag.px+dx*k;pivot.position.y=drag.py-dy*k;return;}
  pivot.rotation.y=drag.ry+dx*0.008;pivot.rotation.x=Math.max(-1,Math.min(1.2,drag.rx+dy*0.006));});
const ray=new T.Raycaster(),ndc=new T.Vector2();
cv.addEventListener('pointerup',e=>{if(drag&&!drag.moved){const r=cv.getBoundingClientRect();ndc.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);
  ray.setFromCamera(ndc,camera);const hit=ray.intersectObjects(pickables.filter(m=>{let o=m;while(o){if(!o.visible)return false;o=o.parent;}return true;}),false)[0];
  if(hit){let k=hit.object.userData.part;if(!info(k))k=null;select(k);}}drag=null;});
cv.addEventListener('pointercancel',()=>drag=null);
function setZoom(z){zoom=Math.max(0.35,Math.min(2.2,z));}
cv.addEventListener('wheel',e=>{e.preventDefault();touched=true;setZoom(zoom*(e.deltaY>0?1.1:0.9));},{passive:false});
[['h-zin',0.8],['h-zout',1.25]].forEach(([id,f])=>{const b=$(id);if(b)b.addEventListener('click',()=>{touched=true;setZoom(zoom*f);});});
const zr=$('h-reset');if(zr)zr.addEventListener('click',()=>{zoom=1;pivot.position.set(0,0,0);touched=false;});

/* ---------- Caméra : transitions douces entre étapes ---------- */
let camDist=18,camY=5,aspect=1.6;
function targetCam(){const d=DUOS[duo];
  if(d.civil){const G=iso[duo].G;if(step==='C')return {dist:2.05*(G.yPlug-G.y0+1.2*G.R),y:0.5,shift:0};if(step==='B')return {dist:5.2,y:-0.6,shift:1};return {dist:21.5,y:5.4,shift:0};}
  if(step==='C')return {dist:5.2*d.engine.sL,y:0.5,shift:0};
  if(step==='B')return {dist:d.nEng>1?7.5:7,y:2.2,shift:1};
  return {dist:19.5,y:6.2,shift:0};}
// la vue 3D occupe tout le cadre ; quand les panneaux sont en surimpression, on décale le centre de l'image vers la zone libre
function resize(){const w=box.clientWidth,h=box.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;aspect=w/h;
  const side=document.querySelector('.hx-side'),top=document.querySelector('.hx-top');let dx=0,dy=0;
  if(side&&getComputedStyle(side).position==='absolute'){dx=(side.offsetWidth+14)/2;aspect=(w-2*dx)/h;}
  if(top&&getComputedStyle(top).position==='absolute')dy=-top.offsetHeight/2;
  if(dx||dy)camera.setViewOffset(w,h,dx,dy,w,h);else camera.clearViewOffset();
  camera.updateProjectionMatrix();}
try{new ResizeObserver(resize).observe(box);}catch(e){window.addEventListener('resize',resize);}
let shiftCur=0;

/* ---------- Animation ---------- */
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
let visible=true,running=false,last=performance.now(),t0=last,lpA=0,hpA=0,nozCur=0;
function kick(){if(visible&&!running){running=true;last=performance.now();requestAnimationFrame(loop);}}
try{new IntersectionObserver(es=>{visible=es[0].isIntersecting;kick();}).observe(box);}catch(e){}
const v3=new T.Vector3();
function engineFx(e,dt,flick,big){
  const x=st.x;
  if(e.civil){e.spools.lp.forEach(g=>g.rotation.y=lpA*0.7);e.spools.hp.forEach(g=>g.rotation.y=hpA);
    heat(1150+650*x,e.flameMat.color);e.flameMat.opacity=(0.3+0.4*x)*flick;
    const G=e.G,Lp=(big?0.9:1.4)*G.L*(0.5+0.5*x);e.plume.scale.set(0.3*G.R,Lp,0.3*G.R);e.plume.position.y=G.L+Lp/2;heat(900,e.plumeMat.color);e.plumeMat.opacity=(0.04+0.08*x)*flick;
    if(!big){const tgt=step==='B'?0.28:1;e.nacMat.transparent=tgt<1;e.nacMat.opacity+=(tgt-e.nacMat.opacity)*Math.min(1,dt*3);e.nacMat.depthWrite=e.nacMat.opacity>0.6;}
    return;}e.spools.lp.forEach(g=>g.rotation.y=lpA);e.spools.hp.forEach(g=>g.rotation.y=hpA);
  if(e._last===undefined||Math.abs(e._last-nozCur)>0.01){e.nozzle(nozCur);e._last=nozCur;}
  heat(1100+750*x,e.flameMat.color);e.flameMat.opacity=(0.3+0.4*x)*flick;
  heat(1800,e.tHP.userData.base);e.tHP.userData.baseI=0.35*x;heat(1400,e.tLP.userData.base);e.tLP.userData.baseI=0.2*x;
  heat(1100,e.liner.userData.base);e.liner.userData.baseI=0.2+0.6*x;
  const L=(big?1.4:2.4)*(st.pc?1.8:0.6+0.4*x),R=0.27+0.07*nozCur;e.plume.scale.set(R*0.9,L,R*0.9);e.plume.position.y=3.54+L/2;
  heat(st.pc?1900:800,e.plumeMat.color);e.plumeMat.opacity=(st.pc?0.5:0.1+0.08*x)*flick;
  e.abMat.opacity=st.pc?0.4*flick:Math.max(0,e.abMat.opacity-dt*2);heat(2000,e.abMat.color);
  e.dias.forEach((d,i)=>{const rr=R*(0.45-i*0.07);d.position.set(0,3.72+i*L/5,0);d.scale.set(rr,rr*1.9,rr);});
  e.diaMat.opacity=st.pc?0.6*flick:Math.max(0,e.diaMat.opacity-dt*2);
}
function loop(now){
  if(!visible){running=false;return;}
  const dt=Math.min(0.05,(now-last)/1000)*(reduce?0.2:1);last=now;const t=(now-t0)/1000,x=st.x;
  lpA+=(2+5*x)*dt;hpA+=(3.4+8.5*x)*dt;
  nozCur+=((st.pc?1:0)-nozCur)*Math.min(1,dt*3);curOpen=nozCur;
  const flick=0.85+0.15*Math.sin(t*23)*Math.sin(t*7.3);
  // caméra
  const tc=targetCam(),k=reduce?1:Math.min(1,dt*3);
  camDist+=(tc.dist*zoom-camDist)*k;camY+=(tc.y*zoom-camY)*k;shiftCur+=(tc.shift-shiftCur)*k;
  const fit=Math.max(1,1.6/Math.max(aspect,0.6));
  camera.position.set(0,camY*fit,camDist*fit);camera.lookAt(0,step==='C'?0:-0.3,0);
  const a=air[duo];
  if(step==='C'){const e=iso[duo];engineFx(e,dt,flick,true);
    if(!touched&&!reduce){pivot.rotation.y=-0.45+Math.sin(t*0.25)*0.3;pivot.rotation.x=0.3+Math.sin(t*0.17)*0.05;}
    if(e.civil){const G=TFG,yE=G.L*2.2,y0=G.y0-0.4*G.R;
      for(let i=0;i<NP;i++){let y=py[i]+speedTF(py[i],sec[i])*dt;if(y>yE){y=y0-Math.random()*0.2;pf[i]=Math.random();pth[i]=Math.random()*Math.PI*2;}
        py[i]=y;const r=radialTF(y,pf[i],sec[i]);pos[i*3]=r*Math.cos(pth[i]);pos[i*3+1]=y;pos[i*3+2]=r*Math.sin(pth[i]);
        heat(tempTF(y,sec[i]));col[i*3]=tmp.r;col[i*3+1]=tmp.g;col[i*3+2]=tmp.b;}
    }else{
    plumeL=1.4*(st.pc?1.8:0.6+0.4*x);yEnd=3.54+plumeL;
    for(let i=0;i<NP;i++){let y=py[i]+speed(py[i],sec[i])*dt;if(y>yEnd){y=Y0-Math.random()*0.2;pf[i]=Math.random();pth[i]=Math.random()*Math.PI*2;}
      py[i]=y;const r=radial(y,pf[i],sec[i]);pos[i*3]=r*Math.cos(pth[i]);pos[i*3+1]=y;pos[i*3+2]=r*Math.sin(pth[i]);
      heat(tempAt(y,sec[i]));col[i*3]=tmp.r;col[i*3+1]=tmp.g;col[i*3+2]=tmp.b;}}
    pgeo.attributes.position.needsUpdate=true;pgeo.attributes.color.needsUpdate=true;
  }else{
    a.engs.forEach(e=>engineFx(e,dt,flick,false));
    a.g.position.copy(DUOS[duo].center).multiplyScalar(-shiftCur);
    const op=step==='A'?0.9:(DUOS[duo].civil?0.5:0.12);skin.opacity+=(op-skin.opacity)*k;skin.depthWrite=skin.opacity>0.5;edgeMat.opacity=step==='A'?0.2:0.4;
    a.zone.visible=step==='A';zoneMat.opacity=0.2;
    const ph=phase&&PH()[phase]?PH()[phase]:{mach:0.5};
    if(!touched&&!reduce){pivot.rotation.y=(step==='A'?-0.65:-0.9)+Math.sin(t*0.2)*0.22;pivot.rotation.x=0.38+Math.sin(t*0.13)*0.05;a.g.rotation.x=step==='A'?Math.sin(t*0.5)*0.06:0;}
    const vAir=twin?(twin.mach<0.05?1.2:3+twin.mach*9):phase==='sol'?1.2:3+ph.mach*9;
    Object.keys(flow).forEach(kf=>{flow[kf].geo.setDrawRange(0,kf===duo?flow[kf].N*2:0);});
    updateFlow(flow[duo],reduce?dt*0.3:dt,vAir,x,st.pc,step==='A'?0.8:1);
  }
  twinFx();
  // mise en évidence
  const pulse=0.55; // mise en évidence fixe et douce (pas de clignotement)
  Object.entries(allMats).forEach(([kk,ms])=>{const on=selected&&(kk===selected||(selected==='tuyeres'&&kk==='moteurs')||(selected==='tbp'&&duo==='mirage'&&kk==='thp'));
    ms.forEach(m=>{m.emissive.copy(m.userData.base);m.emissiveIntensity=m.userData.baseI;if(on){m.emissive.lerp(accent,0.45);m.emissiveIntensity=m.userData.baseI+0.22;}});});
  skin.emissive.setRGB(0,0,0);if(step!=='C'&&selected&&['aile','entrees'].includes(selected))skin.emissive.copy(accent).multiplyScalar(0.12);
  // étiquettes
  const W=box.clientWidth,H=box.clientHeight;
  if(step==='C'&&DUOS[duo].civil){const e=iso[duo],G=e.G;e.g.updateMatrixWorld();lblTF.forEach(l=>{if(l.el.hidden)return;v3.set(-l.r*G.R,l.y*G.L,0);e.g.localToWorld(v3);v3.project(camera);
      l.el.style.transform=`translate(${(v3.x*0.5+0.5)*W}px,${(-v3.y*0.5+0.5)*H}px) translate(-50%,-50%)`;});}
  else if(step==='C'){const e=iso[duo];e.g.updateMatrixWorld();lblIso.forEach(l=>{if(l.k==='fadec')v3.set(-0.55,l.y,0);else v3.set(-0.42*l.s,l.y,0);e.g.localToWorld(v3);v3.project(camera);
      l.el.style.transform=`translate(${(v3.x*0.5+0.5)*W}px,${(-v3.y*0.5+0.5)*H}px) translate(-50%,-50%)`;});}
  else{a.g.updateMatrixWorld();lblAir[duo].forEach(l=>{v3.copy(l.p);a.g.localToWorld(v3);v3.project(camera);l.el.style.transform=`translate(${(v3.x*0.5+0.5)*W}px,${(-v3.y*0.5+0.5)*H}px) translate(-50%,-50%)`;});}
  renderer.render(scene,camera);requestAnimationFrame(loop);
}
/* ---------- Jumeau numérique : pilotage par la page jumeau.html ----------
   CPS_HANGAR.twin({mach, x, pc, hud}) : vitesse de l'air autour de l'avion, régime réel (après limitation FADEC),
   post-combustion, et cône de Mach (demi-angle μ = arcsin(1/M)) au-delà de Mach 1. */
let twin=null;
const NOSE={rafale:7.7,mirage:7.2};
const coneGeo=new T.ConeGeometry(1,1,48,1,true);coneGeo.translate(0,-0.5,0);coneGeo.rotateZ(-Math.PI/2);
const wireGeo=new T.ConeGeometry(1,1,20,3,true);wireGeo.translate(0,-0.5,0);wireGeo.rotateZ(-Math.PI/2);
const coneMat=new T.MeshBasicMaterial({color:0x9be7f5,transparent:true,opacity:0.06,side:T.DoubleSide,depthWrite:false,blending:T.AdditiveBlending});
const coneWire=new T.MeshBasicMaterial({color:0x67e8f9,wireframe:true,transparent:true,opacity:0.12,depthWrite:false,blending:T.AdditiveBlending});
const cones={};Object.keys(NOSE).forEach(k=>{if(!air[k])return;const c=new T.Group();c.add(new T.Mesh(coneGeo,coneMat));c.add(new T.Mesh(wireGeo,coneWire));
  c.position.set(NOSE[k],0,0);c.visible=false;air[k].g.add(c);cones[k]=c;});
function twinFx(){Object.values(cones).forEach(c=>c.visible=false);const c=cones[duo];
  if(!twin||!c||step==='C'||!(twin.mach>1))return;
  const tm=Math.tan(Math.asin(1/twin.mach));let L=11,R=L*tm;if(R>5.5){R=5.5;L=R/tm;}
  c.scale.set(L,R,R);c.visible=true;coneWire.opacity=0.08+0.1*Math.min(1,(twin.mach-1)*2);coneMat.opacity=0.04+0.05*Math.min(1,(twin.mach-1)*2);}
readControls();apply();kick();
window.CPS_HANGAR={get state(){return {duo,step,selected,zoom,twin:!!twin};},
  twin(t){twin=t?Object.assign({},t):null;
    if(t){thr.value=Math.round(Math.max(0,Math.min(1,t.x))*100);pcb.checked=!!t.pc;phase=null;markPhase();
      $('h-thr-o').textContent=`${thr.value} %`;st={x:Math.max(0,Math.min(1,t.x)),pc:!!t.pc};updateHud();kick();}
    else readControls();},
  setDuo(k){if(DUOS[k]&&k!==duo){duo=k;phase=null;markPhase();apply();}}};
})();
