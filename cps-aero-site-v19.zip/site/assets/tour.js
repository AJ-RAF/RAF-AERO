/* CPSAero — visite guidée (onboarding).
   Accueil : boutons [data-tour-start]. Pages de cours : ?visite=1 lance la suite de la visite.
   Projecteur sur l'élément, carte explicative, Précédent / Suivant / Quitter, clavier (flèches, Échap). */
(function(){
  const LS='cps-tour-seen';
  const vis=el=>{if(!el)return false;const r=el.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(el).visibility!=='hidden';};
  const pick=sel=>{if(!sel)return null;for(const s of sel.split('||')){const all=[...document.querySelectorAll(s.trim())];const v=all.find(vis);if(v)return v;}return null;};
  const HOME=[
    {t:'Bienvenue sur CPSAero',d:'En une minute, voici où trouver chaque outil du site. Tu peux quitter à tout moment avec Échap.'},
    {s:'#moteur',t:'La question de départ',d:'À quoi sert le moteur d’un avion ? Tout le site part de là : l’aile porte, le moteur pousse. Les trois cartes en dessous te mènent de l’aérodynamique aux calculs.'},
    {s:'.links a[href="cours.html"]',t:'Les cours',d:'Aérodynamique, mécanique, thermodynamique, transfert thermique, décarbonation, moteurs et avionique. Chaque cours commence par une fiche express.'},
    {s:'.links a[href="lexique.html"]',t:'Le lexique',d:'Un dictionnaire de A à Z : une définition courte par mot, et un lien direct vers la partie du cours qui l’explique avec un schéma.'},
    {s:'.links a[href="calculs.html"]',t:'Le calculateur',d:'Les grandes formules en boîte transparente : tu règles les valeurs, le calcul se refait sous tes yeux, étape par étape. Une valeur incohérente s’affiche en rouge. Les outils de dimensionnement apparaissent en mode Ingénieur.'},
    {s:'.links a[href="moteurs.html"]',t:'Le hangar 3D',d:'De l’avion au moteur : Rafale et M88, Mirage 2000 et M53. Les particules montrent l’air qui contourne l’avion et traverse les moteurs.'},
    {s:'.links a[href="essais.html"]',t:'Le simulateur d’essais',d:'Deux missions d’essais en vol, expliquées simplement : l’objectif, ce qu’on mesure, la conclusion de l’ingénieur.'},
    {s:'.links a[href="formations.html"]',t:'L’orientation',d:'De la Seconde au métier : choisis ta voie, suis l’organigramme interactif, puis ouvre les fiches métiers sourcées.'},
    {s:'.srch-btn',t:'La recherche',d:'Un cours, un mot, un moteur, un métier ? Clique ici ou appuie sur la touche « / ».'},
    {s:'#lvl',t:'Débutant ou Ingénieur',d:'Le mode Débutant vulgarise avec des analogies et des schémas. Le mode Ingénieur s’ouvre après un test d’habilitation de 5 questions : démonstrations complètes et outils de dimensionnement. Le badge reste sur ton appareil.'},
    {s:'#theme-btn',t:'Mode clair ou sombre',d:'L’ambiance cockpit par défaut, ou une version claire pour lire longtemps.'},
    {s:'.kpis',t:'CPSAero en chiffres',d:'Les cours, outils et questions corrigées disponibles, et le compteur de visites du site.'},
    {s:'.dash',t:'Ta progression',d:'Pages lues, exercices réussis et meilleurs quiz sont gardés sur ton appareil, sans compte.'},
    {t:'Voir un cours en action ?',d:'La suite de la visite ouvre le cours d’aérodynamique pour te montrer les infobulles, les schémas et le sommaire latéral.',next:{label:'Ouvrir un cours',href:'aerodynamique.html?visite=1'}},
  ];
  const COURSE=[
    {s:'#fiche',t:'La fiche express',d:'L’essentiel du chapitre en un bloc : 5 formules, les hypothèses, les ordres de grandeur. Imprimable en un clic pour réviser.'},
    {s:'.fbk .vtip',t:'Les infobulles des variables',d:'Survole (ou touche) une lettre dans une formule : sa définition et son unité apparaissent. Essaie !'},
    {s:'.gl',t:'Les mots techniques',d:'Les termes soulignés en pointillés ouvrent leur définition du lexique.'},
    {s:'.cfig',t:'Les schémas',d:'Chaque notion a son schéma 2D, avec un code couleur constant : portance en bleu, poids en rouge, traînée en orange, poussée en vert.'},
    {s:'.course .toc||.toc-fab',t:'Le sommaire',d:'Il suit ta lecture, surligne la partie en cours et indique ta progression. Clique pour sauter à une section.'},
    {s:'details.deriv',t:'Les démonstrations',d:'Repliées en mode Débutant, ouvertes en mode Ingénieur. Clique pour les déplier quand tu veux.'},
    {s:'#reviser',t:'Valider tes acquis',d:'En fin de cours : exercices corrigés et quiz de 3 questions. Puis direction les problèmes résolus.'},
    {t:'C’est parti !',d:'Tu sais tout. Bonne exploration, et souviens-toi : on peut y arriver.'},
  ];
  let steps=[],i=0,ov,spot,card,tgt=null;
  function build(){
    ov=document.createElement('div');ov.className='tour-ov';
    spot=document.createElement('div');spot.className='tour-spot';
    card=document.createElement('div');card.className='tour-card';card.setAttribute('role','dialog');card.setAttribute('aria-modal','true');card.setAttribute('aria-labelledby','tour-t');
    document.body.append(ov,spot,card);
    ov.addEventListener('click',end);
  }
  function place(){
    if(!card)return;
    if(tgt&&vis(tgt)){
      const r=tgt.getBoundingClientRect(),p=8;
      Object.assign(spot.style,{display:'block',left:(r.left-p)+'px',top:(r.top-p)+'px',width:(r.width+2*p)+'px',height:(r.height+2*p)+'px'});
      ov.classList.add('clear');
      const cw=card.offsetWidth,ch=card.offsetHeight;
      let x=Math.min(Math.max(12,r.left+r.width/2-cw/2),innerWidth-cw-12),y=r.bottom+16;
      if(y+ch>innerHeight-12)y=Math.max(12,r.top-ch-16);
      Object.assign(card.style,{left:x+'px',top:y+'px',transform:'none'});
    }else{
      spot.style.display='none';ov.classList.remove('clear');
      Object.assign(card.style,{left:'50%',top:'50%',transform:'translate(-50%,-50%)'});
    }
  }
  function show(k){
    i=k;const st=steps[i];tgt=pick(st.s);
    if(tgt){try{tgt.scrollIntoView({block:'center',inline:'nearest',behavior:'auto'});}catch(e){}}
    const last=i===steps.length-1;
    card.innerHTML=`<div class="tour-top"><span class="tour-n">${i+1} / ${steps.length}</span><button type="button" class="tour-x" aria-label="Quitter la visite">×</button></div>
      <h3 id="tour-t">${st.t}</h3><p>${st.d}</p><div class="tour-dots">${steps.map((_,j)=>`<i class="${j===i?'on':''}"></i>`).join('')}</div>
      <div class="tour-nav">${i>0?'<button type="button" class="btn small" data-a="prev">Précédent</button>':'<span></span>'}
      ${st.next?`<a class="btn small primary" href="${st.next.href}" data-a="go">${st.next.label} →</a>`:`<button type="button" class="btn small primary" data-a="next">${last?'Terminer':'Suivant'}</button>`}</div>
      ${st.next?'<button type="button" class="tour-skip" data-a="end">Terminer ici</button>':''}`;
    card.querySelector('.tour-x').onclick=end;
    card.querySelectorAll('[data-a]').forEach(b=>b.addEventListener('click',e=>{const a=b.dataset.a;if(a==='go'){try{localStorage.setItem(LS,'1')}catch(err){}return;}e.preventDefault();a==='prev'?show(i-1):a==='next'?(last?end():show(i+1)):end();}));
    requestAnimationFrame(place);
    const f=card.querySelector('[data-a="next"],[data-a="go"]');if(f)f.focus({preventScroll:true});
  }
  function start(list){
    steps=list.filter(st=>!st.s||pick(st.s));if(!steps.length)return;
    try{localStorage.setItem(LS,'1')}catch(e){}
    const t=document.querySelector('.tour-toast');if(t)t.remove();
    if(!card)build();document.documentElement.classList.add('touring');show(0);
  }
  function end(){
    [ov,spot,card].forEach(n=>n&&n.remove());ov=spot=card=null;tgt=null;document.documentElement.classList.remove('touring');
    if(/[?&]visite=1/.test(location.search)){try{history.replaceState(null,'',location.pathname+location.hash)}catch(e){}}
  }
  addEventListener('resize',()=>requestAnimationFrame(place));addEventListener('scroll',()=>requestAnimationFrame(place),{passive:true});
  document.addEventListener('keydown',e=>{if(!card)return;if(e.key==='Escape')end();else if(e.key==='ArrowRight'&&i<steps.length-1&&!steps[i].next)show(i+1);else if(e.key==='ArrowLeft'&&i>0)show(i-1);});
  document.querySelectorAll('[data-tour-start]').forEach(b=>b.addEventListener('click',()=>start(HOME)));
  const go=()=>{
    if(/[?&]visite=1/.test(location.search)&&document.querySelector('.course'))start(COURSE);
    else if(document.querySelector('[data-tour-start]')){let seen=false;try{seen=!!localStorage.getItem(LS)}catch(e){}
      if(!seen){const t=document.createElement('div');t.className='tour-toast';t.setAttribute('role','status');
        t.innerHTML='<span>Nouveau sur CPSAero ?</span><button type="button" class="btn small primary">Visite guidée · 1 min</button><button type="button" class="tour-x" aria-label="Fermer">×</button>';
        t.querySelector('.primary').onclick=()=>start(HOME);t.querySelector('.tour-x').onclick=()=>{t.remove();try{localStorage.setItem(LS,'1')}catch(e){}};document.body.appendChild(t);}}
  };
  if(document.readyState==='complete')setTimeout(go,300);else addEventListener('load',()=>setTimeout(go,300));
  window.CPS_TOUR={start:()=>start(HOME),course:()=>start(COURSE),end};
})();
