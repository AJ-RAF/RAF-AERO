/* CPSAero — compteur « en ligne maintenant » (v19).
   Chaque onglet visible envoie un signal toutes les 2 minutes à /api/presence avec un identifiant tiré au hasard,
   gardé dans le stockage local du navigateur : pas de cookie, pas de compte, pas d'adresse IP enregistrée.
   Si le site est déployé sans fonctions (glisser-déposer), l'adresse répond 404 : le script s'arrête et rien ne s'affiche. */
(function(){
  if(!window.fetch||!window.crypto||!crypto.getRandomValues)return;
  var id=null;
  try{id=localStorage.getItem('cps-pid');if(!/^[a-f0-9]{24}$/.test(id||'')){id=Array.prototype.map.call(crypto.getRandomValues(new Uint8Array(12)),function(b){return ('0'+b.toString(16)).slice(-2);}).join('');localStorage.setItem('cps-pid',id);}}catch(e){id=null;}
  if(!id)return;
  var stop=false;
  function beat(){
    if(stop||document.hidden)return;
    fetch('/api/presence',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id:id}),credentials:'omit'})
      .then(function(r){if(!r.ok){if(r.status===404||r.status===405)stop=true;throw 0;}return r.json();})
      .then(function(j){if(j&&typeof j.enLigne==='number'){window.CPS_PRESENCE=j;document.dispatchEvent(new CustomEvent('cps:presence',{detail:j}));}})
      .catch(function(){});
  }
  beat();setInterval(beat,120000);
  document.addEventListener('visibilitychange',function(){if(!document.hidden)beat();});
})();
