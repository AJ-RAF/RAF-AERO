/* CPS Aero — révisions et progression
   Une page déclare window.CPS_PAGE = {id, titre, exos:[], quiz:[], fiches:[]} avant ce script.
   Tout est gardé dans le navigateur de l'élève (localStorage), sans compte. */
(function(){
  const KEY='cps-aero-v1';
  function load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{};}catch(e){return {};}}
  function save(d){try{localStorage.setItem(KEY,JSON.stringify(d));}catch(e){}}
  function pageData(id){const d=load();d.pages=d.pages||{};d.pages[id]=d.pages[id]||{};return d;}
  const Progress={
    get(){const d=load();return d.pages||{};},
    mark(id,field,value){const d=pageData(id);d.pages[id][field]=value;save(d);},
    markIn(id,field,key){const d=pageData(id);const o=d.pages[id][field]||{};o[key]=1;d.pages[id][field]=o;save(d);},
    reset(){save({});}
  };
  window.CPS=window.CPS||{};window.CPS.progress=Progress;

  const P=window.CPS_PAGE;
  const $=s=>document.querySelector(s);
  const num=s=>{const v=parseFloat(String(s).replace(/\s/g,'').replace(',','.'));return isFinite(v)?v:null;};
  const fr=(x,d)=>x.toLocaleString('fr-FR',{maximumFractionDigits:d});
  if(!P)return;
  Progress.mark(P.id,'visited',Date.now());

  /* Lu jusqu'au bout */
  const end=document.getElementById('fin');
  if(end&&'IntersectionObserver' in window){
    new IntersectionObserver((es,o)=>{if(es[0].isIntersecting){Progress.mark(P.id,'read',true);o.disconnect();}}).observe(end);
  }

  /* Exercices « à toi de calculer » */
  const exBox=$('#exos');
  if(exBox&&P.exos){
    const done=(Progress.get()[P.id]||{}).exos||{};
    exBox.innerHTML=P.exos.map((x,i)=>`
      <div class="panel exo" data-i="${i}">
        <div class="top"><h3>${x.titre}</h3><span class="pill ${done[x.id]?'ok':'goal'}" data-st>${done[x.id]?'Réussi':'À faire'}</span></div>
        <p>${x.q}</p>
        <form class="ans" novalidate>
          <label class="sr" for="ex-${x.id}" style="position:absolute;left:-9999px">Ta réponse</label>
          <input id="ex-${x.id}" inputmode="decimal" autocomplete="off" placeholder="Ta réponse">
          <span class="unit">${x.unite||''}</span>
          <button class="btn small primary" type="submit">Vérifier</button>
          <button class="btn small" type="button" data-sol>Voir la correction</button>
        </form>
        <div class="fb" aria-live="polite"></div>
        <div class="eq" data-steps hidden>${x.correction}</div>
      </div>`).join('');
    exBox.querySelectorAll('.exo').forEach(el=>{
      const x=P.exos[+el.dataset.i], fb=el.querySelector('.fb'), st=el.querySelector('[data-steps]');
      el.querySelector('form').addEventListener('submit',e=>{
        e.preventDefault();
        const v=num(el.querySelector('input').value);
        if(v===null){fb.className='fb bad';fb.textContent='Entre un nombre, avec une virgule ou un point.';return;}
        const tol=(x.tol||0.02)*Math.abs(x.reponse);
        if(Math.abs(v-x.reponse)<=tol){
          fb.className='fb good';fb.innerHTML='Exact. '+(x.bravo||'');st.hidden=false;
          Progress.markIn(P.id,'exos',x.id);const p=el.querySelector('[data-st]');p.className='pill ok';p.textContent='Réussi';
        }else{
          const ratio=v/x.reponse, units=Math.abs(ratio/1000-1)<0.03||Math.abs(ratio*1000-1)<0.03||Math.abs(ratio/100-1)<0.03||Math.abs(ratio*100-1)<0.03;
          fb.className='fb bad';fb.innerHTML=units?'Presque : le chiffre est bon mais pas l’unité. Vérifie N ou kN, % ou fraction.':(x.indice?'Pas encore. Indice : '+x.indice:'Pas encore, réessaie.');
        }
      });
      el.querySelector('[data-sol]').addEventListener('click',()=>{st.hidden=!st.hidden;});
    });
  }

  /* Quiz : une question à la fois */
  const qBox=$('#quiz');
  if(qBox&&P.quiz){
    let i=0,score=0;
    function show(){
      if(i>=P.quiz.length){
        const prev=((Progress.get()[P.id]||{}).quiz||{}).best||0;
        if(score>prev)Progress.mark(P.id,'quiz',{best:score,total:P.quiz.length});
        qBox.innerHTML=`<div class="bar"><span>Terminé</span><span>${score} / ${P.quiz.length}</span></div>
          <p class="q">${score===P.quiz.length?'Sans faute. Tu peux passer à la suite.':score>=P.quiz.length/2?'Bien joué. Relis les parties où tu as hésité.':'Relis la page, puis retente : ça rentre vite.'}</p>
          <div><button class="btn small" type="button" data-again>Recommencer</button></div>`;
        qBox.querySelector('[data-again]').addEventListener('click',()=>{i=0;score=0;show();});
        return;
      }
      const q=P.quiz[i];
      qBox.innerHTML=`<div class="bar"><span>Question ${i+1} / ${P.quiz.length}</span><span>Score ${score}</span></div>
        <p class="q">${q.q}</p><div class="opts">${q.choix.map((c,k)=>`<button type="button" class="opt" data-k="${k}">${c}</button>`).join('')}</div>
        <p class="why" hidden></p><div hidden data-next><button class="btn small primary" type="button">${i+1<P.quiz.length?'Question suivante':'Voir mon score'}</button></div>`;
      qBox.querySelectorAll('.opt').forEach(b=>b.addEventListener('click',()=>{
        const k=+b.dataset.k;
        qBox.querySelectorAll('.opt').forEach(o=>{o.disabled=true;if(+o.dataset.k===q.bonne)o.classList.add('right');});
        if(k===q.bonne)score++;else b.classList.add('wrong');
        const w=qBox.querySelector('.why');w.hidden=false;w.innerHTML=(k===q.bonne?'Bonne réponse. ':'Pas tout à fait. ')+q.pourquoi;
        const n=qBox.querySelector('[data-next]');n.hidden=false;n.querySelector('button').addEventListener('click',()=>{i++;show();});
        n.querySelector('button').focus();
      }));
    }
    show();
  }

  /* Fiches à retourner */
  const cBox=$('#fiches');
  if(cBox&&P.fiches){
    cBox.innerHTML=P.fiches.map(f=>`<button type="button" class="card" aria-label="Fiche : ${f.recto.replace(/<[^>]+>/g,'')}. Clique pour retourner."><span class="inner">
      <span class="face front"><small>${f.tag||'Fiche'}</small><b>${f.recto}</b><small>Clique pour retourner</small></span>
      <span class="face back"><small>${f.tag||'Fiche'}</small><span>${f.verso}</span><small></small></span></span></button>`).join('');
    cBox.querySelectorAll('.card').forEach(c=>c.addEventListener('click',()=>c.classList.toggle('flip')));
  }

  /* Sommaire de page : met en évidence la section en cours */
  const toc=[...document.querySelectorAll('.toc a[href^="#"]')];
  if(toc.length&&'IntersectionObserver' in window){
    const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){toc.forEach(a=>a.classList.toggle('on',a.getAttribute('href')==='#'+e.target.id));}}),{rootMargin:'-80px 0px -70% 0px'});
    toc.forEach(a=>{const t=document.getElementById(a.getAttribute('href').slice(1));if(t)io.observe(t);});
  }
})();
